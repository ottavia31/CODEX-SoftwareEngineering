package it.polimi.ingsw.controller;
import it.polimi.ingsw.model.PawnColor;
import it.polimi.ingsw.model.Player;
import it.polimi.ingsw.model.exceptions.DeckFinishedException;
import org.junit.jupiter.api.Test;
import java.rmi.RemoteException;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

/**
 * This class tests the functionality of the LobbyController class.
 */
class LobbyControllerTest {
    /**
     * This test checks if the right exception is thrown when trying to set an invalid number of player,
     * and that the number of players is not changed.
     */
    @Test
    public void SetNumWrongPlayers(){
        Controller controller = new Controller();
        LobbyController lController = new LobbyController(controller);
        int old = controller.getGame().getNumPlayers();
        try{
            assertThrows(IllegalArgumentException.class, () -> lController.setNumPlayers(1));
            assertThrows(IllegalArgumentException.class, () -> lController.setNumPlayers(5));
        }catch(IllegalArgumentException e){
            e.printStackTrace();
        }

        assertEquals(old, controller.getGame().getNumPlayers());
    }

    /**
     * This test checks if players are added correctly to the game.
     * It verifies if the number of players is updated correctly
     * and if an exception is thrown when trying to add a player with an existing name.
     */
    @Test
    public void addPlayertest(){
        Controller controller = new Controller();
        LobbyController lController = new LobbyController(controller);

        lController.addPlayer("pippo");
        lController.addPlayer("Pluto");
        lController.addPlayer("paperino");

        assertEquals(3, controller.getGame().getPlayers().size());
        assertThrows(IllegalArgumentException.class, () -> lController.addPlayer("pippo"));
    }
    /**
     * This test checks if the number of players is set correctly in the game.
     */
    @Test
    public void setNumPlayersTest() throws RemoteException {
        Controller controller = new Controller();
        LobbyController lController = new LobbyController(controller);
        lController.setNumPlayers(2);
        assertEquals(2, controller.getGame().getNumPlayers());
        lController.setNumPlayers(3);
        assertEquals(3, controller.getGame().getNumPlayers());
        lController.setNumPlayers(4);
        assertEquals(4, controller.getGame().getNumPlayers());
        assertThrows(IllegalArgumentException.class, () -> lController.setNumPlayers(1));
        assertThrows(IllegalArgumentException.class, () -> lController.setNumPlayers(5));
    }

    /**
     * This test checks if the secret goal cards of the players are set correctly.
     * @throws DeckFinishedException if there was an error in setting up the game
     */
    @Test
    public void setSecretGoalCardsTest() throws DeckFinishedException {
        Controller controller = new Controller();
        LobbyController lController = new LobbyController(controller);
        lController.setNumPlayers(2);
        lController.addPlayer("pippo");
        lController.addPlayer("Pluto");
        lController.setupGame();
        lController.setSecretGoalCard(1, "pippo");
        lController.setSecretGoalCard(2, "Pluto");

        ArrayList<Player> players = controller.getGame().getPlayers();
        for (Player player : players) {
            assertNotNull(player.getSecretGoalCard());
        }
    }
    /**
     * This test checks if the first player corresponds to the player who first joined the game.
     * @throws DeckFinishedException if there was an error in setting up the game
     */
    @Test
    void chooseFirstPlayerTest() throws RemoteException, DeckFinishedException {
        Controller controller = new Controller();
        LobbyController lController = new LobbyController(controller);
        lController.setNumPlayers(2);
        lController.addPlayer("pippo");
        lController.addPlayer("Pluto");
        lController.setupGame();
        lController.chooseFirstPlayer();
        assertEquals("pippo", controller.getGame().getCurrentPlayer().getNickname());
        assertTrue(controller.getGame().getCurrentPlayer().getIsFirst());
        assertEquals("pippo", controller.getGame().getFirstPlayer().getNickname());
    }

    /**
     * This test checks if the pawn color is set correctly for each player.
     * @throws DeckFinishedException if there was an error in setting up the game
     */
    @Test
    public void setPawnColorTest() throws RemoteException, DeckFinishedException {
        Controller controller = new Controller();
        LobbyController lController = new LobbyController(controller);
        lController.setNumPlayers(2);
        lController.addPlayer("pippo");
        lController.addPlayer("Pluto");
        lController.setupGame();
        lController.setPawn( PawnColor.BLUE, "pippo");
        lController.setPawn(PawnColor.RED, "Pluto");
        assertEquals(PawnColor.BLUE, controller.getGame().getPlayers().get(0).getPawnColor());
        assertEquals(PawnColor.RED, controller.getGame().getPlayers().get(1).getPawnColor());
    }

}
