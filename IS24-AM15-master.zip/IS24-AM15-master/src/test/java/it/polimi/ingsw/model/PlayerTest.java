package it.polimi.ingsw.model;
import it.polimi.ingsw.model.*;
import it.polimi.ingsw.model.cards.*;
import it.polimi.ingsw.model.exceptions.*;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import static org.junit.jupiter.api.Assertions.*;
/**
 * This class contains unit tests for the Player class.
 */
class PlayerTest {
    /**
     * Test the playPlayCard method of the Player class.
     * This test checks if a card is correctly added to the PersonalBoard and if the symbols are updated correctly.
     * @throws InvalidCardPositionException if a card is placed in an invalid position on the personal board
     */
    @Test
    void playPlayCard() throws InvalidCardPositionException{// Unique identifiers for each card
        int starterCardId = 1;
        int resourceCardId = 2;

        Map<String, Symbol> frontcorners = Map.of("UL", Symbol.EMPTY, "UR", Symbol.GREEN, "DL", Symbol.PURPLE, "DR", Symbol.EMPTY);
        Map<String, Symbol> backcorners = Map.of("UL", Symbol.RED, "UR", Symbol.GREEN, "DL", Symbol.PURPLE, "DR", Symbol.BLUE);
        ArrayList<Symbol> frontSymbols = new ArrayList<>();
        frontSymbols.add(Symbol.PURPLE);
        StarterCard starterCard = new StarterCard(starterCardId, frontcorners, backcorners, frontSymbols);
        starterCard.flip();
        PersonalBoard personalBoard = new PersonalBoard(starterCard, true);

        // Creation of a Card instance
        Map<String, Symbol> corners = Map.of("UL", Symbol.PURPLE, "UR", Symbol.PURPLE, "DL", Symbol.EMPTY);
        ResourceCard card1 = new ResourceCard(resourceCardId, Symbol.PURPLE, corners, 0);

        // Creation of a Coordinates instance
        Coordinates coordinates = new Coordinates(1,-1);

        // Creation of a Player instance
        Player player = new Player("player1");
        player.setPersonalBoard(personalBoard);

        assertEquals(1,personalBoard.getNumOfSymbols().get(Symbol.RED));
        assertEquals(1,personalBoard.getNumOfSymbols().get(Symbol.GREEN));
        assertEquals(1,personalBoard.getNumOfSymbols().get(Symbol.PURPLE));
        assertEquals(1,personalBoard.getNumOfSymbols().get(Symbol.BLUE));

        // Save the old number of blue
        int oldBlueValue = player.getPersonalBoard().getNumOfSymbols().get(Symbol.BLUE);
        // Save the old number of purples
        int oldPurpleValue = player.getPersonalBoard().getNumOfSymbols().get(Symbol.PURPLE);

        // Add the card to the PersonalBoard
        player.playPlayCard(card1, coordinates);

        // Verify that the card has been added
        assertEquals(card1, player.getPersonalBoard().getConfiguration().get(coordinates));

        // Verify that the value of the RED symbol has been decremented
        assertEquals(oldBlueValue -1, player.getPersonalBoard().getNumOfSymbols().get(Symbol.BLUE));

        // Verify that the value of the GREEN symbol has been incremented
        assertEquals(3, player.getPersonalBoard().getNumOfSymbols().get(Symbol.PURPLE));
    }

    /**
     * Test the playPlayCard method of the Player class with an invalid card.
     * This test checks if an InvalidCardPositionException is thrown when trying to add a card in an invalid position.
     * @throws InvalidCardPositionException if a card is placed in an invalid position on the personal board
     * @throws HiddenCornerException if a card is placed in a position that hides a corner of another card
     */
    @Test
    void playWrongPlayCard() throws InvalidCardPositionException, HiddenCornerException{
        // Unique identifiers for each card
        int starterCardId = 1;
        int resourceCardId1 = 2;
        int resourceCardId2 = 3;

        Map<String, Symbol> frontcorners = Map.of("UL", Symbol.EMPTY, "UR", Symbol.GREEN, "DL", Symbol.PURPLE, "DR", Symbol.EMPTY);
        Map<String, Symbol> backcorners = Map.of("UL", Symbol.RED, "UR", Symbol.GREEN, "DL", Symbol.PURPLE, "DR", Symbol.BLUE);
        ArrayList<Symbol> frontSymbols = new ArrayList<>();
        frontSymbols.add(Symbol.PURPLE);
        StarterCard starterCard = new StarterCard(starterCardId, frontcorners, backcorners, frontSymbols);
        starterCard.flip();
        PersonalBoard personalBoard = new PersonalBoard(starterCard, true);

        // Creation of a Card instance
        Map<String, Symbol> corners = Map.of("UL", Symbol.PURPLE, "UR", Symbol.PURPLE, "DL", Symbol.EMPTY);
        ResourceCard card1 = new ResourceCard(resourceCardId1, Symbol.PURPLE, corners, 0);

        // Creation of a Coordinates instance
        Coordinates coordinates = new Coordinates(1,-1);

        // Creation of a Player instance
        Player player = new Player("player1");
        player.setPersonalBoard(personalBoard);

        // Add the card to the PersonalBoard
        player.playPlayCard(card1, coordinates);

        // Creation of a Card instance
        Map<String, Symbol> corners2 = Map.of("UL", Symbol.EMPTY, "UR", Symbol.GREEN, "DL", Symbol.EMPTY, "DR", Symbol.EMPTY);
        ResourceCard card2 = new ResourceCard(resourceCardId2, Symbol.PURPLE, corners, 0);

        //Creation of coordinates instance
        Coordinates coordinates2 = new Coordinates(2,-2);

        // Verify that the card has not been added
        assertThrows(InvalidCardPositionException.class, () -> player.playPlayCard(card2, coordinates2));

        // Verify that the card has been added
        assertEquals(card1,player.getPersonalBoard().getConfiguration().get(coordinates));

        //Verify that the value of the GREEN symbol has not been incremented
        assertEquals(1, player.getPersonalBoard().getNumOfSymbols().get(Symbol.GREEN));
    }
    /**
     * Test the playPlayCard method of the Player class with the back of a card.
     * This test checks if a card is correctly added to the PersonalBoard and if the symbols are updated correctly when the card is flipped to the back.
     * @throws InvalidCardPositionException if a card is placed in an invalid position on the personal board
     */
    @Test
    void playBackPlayCard() throws InvalidCardPositionException{
        // Identifiers for each card
        int starterCardId = 1;
        int resourceCardId = 2;

        Map<String, Symbol> frontcorners = Map.of("UL", Symbol.EMPTY, "UR", Symbol.GREEN, "DL", Symbol.PURPLE, "DR", Symbol.EMPTY);
        Map<String, Symbol> backcorners = Map.of("UL", Symbol.RED, "UR", Symbol.GREEN, "DL", Symbol.PURPLE, "DR", Symbol.BLUE);
        ArrayList<Symbol> frontSymbols = new ArrayList<>();
        frontSymbols.add(Symbol.PURPLE);
        StarterCard starterCard = new StarterCard(starterCardId, frontcorners, backcorners, frontSymbols);
        starterCard.flip();
        PersonalBoard personalBoard = new PersonalBoard(starterCard, false);

        // Creation of a Card instance
        Map<String, Symbol> corners = Map.of("UL", Symbol.PURPLE, "UR", Symbol.PURPLE, "DL", Symbol.EMPTY);
        ResourceCard card1 = new ResourceCard(resourceCardId, Symbol.PURPLE, corners, 0);
        card1.flip();

        // Creation of a Coordinates instance
        Coordinates coordinates = new Coordinates(1,-1);

        // Creation of a Player instance
        Player player = new Player("player1");
        player.setPersonalBoard(personalBoard);

        // Save the old number of purples
        int oldPurpleValue = player.getPersonalBoard().getNumOfSymbols().get(Symbol.PURPLE);

        // Add the card to the PersonalBoard
        player.playPlayCard(card1, coordinates);

        // Verify that the card has been added
        assertEquals(card1, player.getPersonalBoard().getConfiguration().get(coordinates));


        // Verify that the value of the PURPLE symbol has been incremented
        assertEquals(oldPurpleValue + 1, player.getPersonalBoard().getNumOfSymbols().get(Symbol.PURPLE));
    }
    /**
     * Test the drawGoldCard method of the Player class.
     * This test checks if a GoldCard is correctly drawn from the deck and added to the player's hand.
     */
    @Test
    void drawGoldCard() {
        // Unique identifier for the GoldCard
        int goldCardId = 1;

        GameBoard g = new GameBoard();
        Player p = new Player("pippo");
        p.setGameBoard(g);
        //Try to draw four cards
        for(int i =0; i<3; i++ ){
            try{
                p.drawCard(g.getGoldDeck());
            }catch(MoreThanThreeCardsException e){
                e.printStackTrace();
            } catch (DeckFinishedException e) {
                throw new RuntimeException(e);
            }
        }

        assertEquals(3, p.getPlayCards().size());
    }
    /**
     * Test the playPlayCard method of the Player class with a GoldCard.
     * This test checks if a GoldCard is correctly added to the PersonalBoard and if the player's score is updated correctly.
     * @throws InvalidCardPositionException if a card is placed in an invalid position on the personal board
     */
    @Test
    void testPlayPlayCardGoalPoints() throws InvalidCardPositionException {
        // Unique identifiers for each card
        int starterCardId = 1;
        int goldCardId = 2;

        // Create a StarterCard and a PersonalBoard
        Map<String, Symbol> frontcorners = Map.of("UL", Symbol.EMPTY, "UR", Symbol.GREEN, "DL", Symbol.PURPLE, "DR", Symbol.EMPTY);
        Map<String, Symbol> backcorners = Map.of("UL", Symbol.RED, "UR", Symbol.GREEN, "DL", Symbol.PURPLE, "DR", Symbol.BLUE);
        ArrayList<Symbol> frontSymbols = new ArrayList<>();
        frontSymbols.add(Symbol.PURPLE);
        StarterCard starterCard = new StarterCard(starterCardId, frontcorners, backcorners, frontSymbols);
        starterCard.flip();
        PersonalBoard personalBoard = new PersonalBoard(starterCard, false);

        // Create a GoldCard
        Map<String, Symbol> corners = Map.of("UL", Symbol.PURPLE, "UR", Symbol.PURPLE, "DL", Symbol.EMPTY);
        ArrayList<Symbol> conditionsToUse = new ArrayList<>();
        conditionsToUse.add(Symbol.PURPLE);
        GoldCard goldCard = new GoldCard(goldCardId, Symbol.PURPLE, corners, 5, conditionsToUse, Symbol.PURPLE);
        goldCard.setBackSide(false);
        // Create a Player and set the PersonalBoard
        Player player = new Player("player1");
        player.setPersonalBoard(personalBoard);
        PersonalBoard oldPersonalBoard = player.getPersonalBoard();
        GameBoard gameBoard = new GameBoard();
        player.setGameBoard(gameBoard);

        // Calculate the expected score before the GoldCard is played
        int expectedScore = 5 * oldPersonalBoard.getNumOfSymbols().get(Symbol.PURPLE);
        // Play the GoldCard
        Coordinates coordinates = new Coordinates(1, -1);
        player.playPlayCard(goldCard, coordinates);

        // Verify that the GoldCard has been added to the PersonalBoard
        assertEquals(goldCard, player.getPersonalBoard().getConfiguration().get(coordinates));
        assertEquals(expectedScore, player.getScore());
    }
    /**
     * Test the playPlayCard method of the Player class with the back of a GoldCard.
     * This test checks if a GoldCard is correctly added to the PersonalBoard when the card is flipped to the back.
     * @throws InvalidCardPositionException if a card is placed in an invalid position on the personal board
     */
    @Test
    void testPlayPlayCardWithBackOfGoldCard() throws InvalidCardPositionException{
        // Unique identifiers for each card
        int starterCardId = 1;
        int goldCardId = 2;

        // Initialize the game board, player, and personal board
        GameBoard gameBoard = new GameBoard();
        Player player = new Player("player1");
        Map<String, Symbol> frontcorners = Map.of("UL", Symbol.EMPTY, "UR", Symbol.GREEN, "DL", Symbol.PURPLE, "DR", Symbol.EMPTY);
        Map<String, Symbol> backcorners = Map.of("UL", Symbol.RED, "UR", Symbol.GREEN, "DL", Symbol.PURPLE, "DR", Symbol.BLUE);
        ArrayList<Symbol> frontSymbols = new ArrayList<>();
        frontSymbols.add(Symbol.PURPLE);
        StarterCard starterCard = new StarterCard(starterCardId, frontcorners, backcorners, frontSymbols);
        starterCard.flip();
        PersonalBoard personalBoard = new PersonalBoard(starterCard, false);
        player.setPersonalBoard(personalBoard);
        player.setGameBoard(gameBoard);

        // Create a GoldCard and flip it to the back
        GoldCard goldCard = new GoldCard(goldCardId, Symbol.RED, new HashMap<>(), 1, new ArrayList<>(), Symbol.POTION);
        goldCard.flip();

        // Play the GoldCard
        player.playPlayCard(goldCard, new Coordinates(1, -1));

        // Check that the card has been added to the personal board
        assertEquals(goldCard, player.getPersonalBoard().getConfiguration().get(new Coordinates(1, -1)));
    }
    /**
     * Test the drawCard method of the Player class with an empty GoldDeck.
     * This test checks if a DeckFinishedException is thrown when trying to draw a card from an empty deck.
     * @throws MoreThanThreeCardsException if the player tries to draw a card when they already have three cards in their hand
     * @throws DeckFinishedException if a deck is empty and a player tries to draw a card from it
     */
    @Test
    void testDrawGoldCardWithEmptyDeck() throws MoreThanThreeCardsException, DeckFinishedException {
        // Initialize the game board and player
        GameBoard gameBoard = new GameBoard();
        Player player = new Player("player1");
        player.setGameBoard(gameBoard);

        // Empty the Gold deck
        gameBoard.getGoldDeck().getCards().clear();
        // Empty the Resource deck
        gameBoard.getResourceDeck().getCards().clear();


        int resourceCardId1 = 2;
        Map<String, Symbol> corners1 = Map.of("UL", Symbol.PURPLE, "UR", Symbol.PURPLE, "DL", Symbol.EMPTY);
        PlayCard card1 = new ResourceCard(resourceCardId1, Symbol.PURPLE, corners1, 0);
        int resourceCardId2 = 3;
        Map<String, Symbol> corners2 = Map.of("UL", Symbol.PURPLE, "UR", Symbol.PURPLE, "DL", Symbol.EMPTY);
        PlayCard card2 = new ResourceCard(resourceCardId2, Symbol.PURPLE, corners2, 0);
        player.getPlayCards().add(card1);
        player.getPlayCards().add(card2);
        // Get the initial size of the player's hand
        int initialHandSize = player.getPlayCards().size();

        // Try to draw a GoldCard
        try {
            player.drawCard(gameBoard.getGoldDeck());
        } catch (MoreThanThreeCardsException|DeckFinishedException e) {
            // don't do anything
        }

        // Check that the player's hand size did not increase
        assertEquals(initialHandSize, player.getPlayCards().size());
    }
    /**
     * Test the drawfaceupCards method of the Player class with an empty GoldDeck.
     * This test checks if a NoCardException is thrown when trying to draw a face-up card from an empty deck.
     */
    @Test
    void testDrawFaceUpGoldCardWithEmptyGoldDeck() {
        // Unique identifiers for each card
        int goldCardId = 1;
        int resourceCardId = 2;

        // Initialize the game board, player, and face-up cards
        GameBoard gameBoard = new GameBoard();
        Player player = new Player("player1");
        player.setGameBoard(gameBoard);

    }

}
