package it.polimi.ingsw.view.CLI.utils;

import it.polimi.ingsw.localModel.CardView;
import it.polimi.ingsw.localModel.PersonalBoardView;
import it.polimi.ingsw.model.Coordinates;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;


class ASCIIStringsTest {

    @Test
    void testPrintGoalCards() {
        for (int i = 87; i < 103; i++) {
            ASCIIStrings.printGoalCard(i);
        }
    }
    @Test
    void testPrintStarterCards() {
        for (int i = 81; i < 87; i++) {
            ASCIIStrings.printStarterCard(i, false);
            ASCIIStrings.printStarterCard(i, true);
        }
    }

    @Test
    void testPrintResourceCard() {
        for (int i = 1; i < 41; i++) {
            ASCIIStrings.printResourceCard(i, false);
        }
    }
    @Test
    void testPrintResourceCardBack() {
        for (int i = 1; i < 41; i++) {
            ASCIIStrings.printResourceCard(i, true);
        }
    }


    @Test
    void testPrintGoldCard() {
        for (int i = 41; i < 81; i++) {
            ASCIIStrings.printGoldCard(i, false);
        }
    }
    @Test
    void testPrintGoldCardBack() {
        for (int i = 41; i < 81; i++) {
            ASCIIStrings.printGoldCard(i, true);
        }
    }

    @Test
    void testPrintPersonalBoard(){
        PersonalBoardView personalBoard = new PersonalBoardView();
        personalBoard.getMap().put(new Coordinates(0,0), new CardView(86));
        personalBoard.getMap().put(new Coordinates(1,1), new CardView(22));
        personalBoard.getMap().put(new Coordinates(-1,-1), new CardView(57));
        personalBoard.getMap().put(new Coordinates(2,2), new CardView(40));
        personalBoard.getMap().put(new Coordinates(1,-1), new CardView(51));
        personalBoard.getMap().put(new Coordinates(-1,1), new CardView(60));
        personalBoard.getMap().put(new Coordinates(2,-2), new CardView(20));
        personalBoard.getMap().put(new Coordinates(2,0), new CardView(80));
        personalBoard.getMap().put(new Coordinates(3,3), new CardView(30));
        personalBoard.getMap().put(new Coordinates(4,0), new CardView(70));
        personalBoard.getMap().put(new Coordinates(0,4), new CardView(10));
        personalBoard.getMap().put(new Coordinates(0,2), new CardView(50));
        personalBoard.getMap().put(new Coordinates(1,3), new CardView(60));
        personalBoard.getMap().put(new Coordinates(3,1), new CardView(70));
        personalBoard.getMap().put(new Coordinates(4,4), new CardView(80));
        ASCIIStrings.printPersonalBoard(personalBoard);
    }
}