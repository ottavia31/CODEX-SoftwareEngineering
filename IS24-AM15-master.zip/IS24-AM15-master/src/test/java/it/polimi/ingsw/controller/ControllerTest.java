package it.polimi.ingsw.controller;

import it.polimi.ingsw.model.Coordinates;
import it.polimi.ingsw.model.GameBoard;
import it.polimi.ingsw.model.Player;
import it.polimi.ingsw.model.Symbol;
import it.polimi.ingsw.model.cards.*;
import it.polimi.ingsw.model.exceptions.*;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

/** This class tests the functionality of the Controller class.
 * It tests the methods playCard, getWinner and drawCard.
 */

class ControllerTest {

    /** This test checks if the method playCard works correctly.
     * It verifies if the card is played in the correct position
     * and if an exception is thrown when trying to play a card in an invalid position.
     * @throws DeckFinishedException if the deck is empty
     * @throws InvalidCardPositionException if the card is played in an invalid position
     */
    @Test
    void testPlayCard() throws DeckFinishedException, InvalidCardPositionException {
        Controller controller = new Controller();
        LobbyController lobbyController = new LobbyController(controller);
        GameBoard gameBoard = controller.getGame();

        gameBoard.setNumPlayers(3);
        assertEquals(3, controller.getNumPlayers());
        Player player1 = new Player("player1");
        Player player2 = new Player("player2");
        Player player3 = new Player("player3");

        gameBoard.getPlayers().add(player1);
        gameBoard.getPlayers().add(player2);
        gameBoard.getPlayers().add(player3);

        ResourceDeck resourceDeck = gameBoard.getResourceDeck();
        GoalDeck goalDeck = gameBoard.getGoalDeck();
        assertEquals(3, controller.getPlayersSize());


        lobbyController.setupGame();

        gameBoard.setCurrentPlayer(player1);
        lobbyController.playStarterCard(false);
        controller.nextPlayer();
        lobbyController.playStarterCard(false);
        controller.nextPlayer();
        lobbyController.playStarterCard(false);


        gameBoard.addResourceCard(1,Symbol.RED, Symbol.RED, Symbol.RED, Symbol.EMPTY, null, 0);
        gameBoard.addResourceCard(2, Symbol.RED, Symbol.RED, null, Symbol.RED, Symbol.EMPTY, 0);
        gameBoard.addResourceCard(3, Symbol.RED, Symbol.EMPTY, Symbol.RED, null, Symbol.RED, 0);
        gameBoard.addResourceCard(4, Symbol.RED, null, Symbol.EMPTY, Symbol.RED, Symbol.RED, 0);
        gameBoard.addResourceCard(8, Symbol.RED, Symbol.EMPTY, Symbol.EMPTY, Symbol.RED, null, 1);
        gameBoard.addResourceCard(10,Symbol.RED, null, Symbol.RED, Symbol.EMPTY, Symbol.EMPTY, 1);

        ResourceCard resourceCard1 = resourceDeck.getResourceCardById(1);
        resourceCard1.flip();
        ResourceCard resourceCard2 = resourceDeck.getResourceCardById(2);
        resourceCard2.flip();
        ResourceCard resourceCard3 = resourceDeck.getResourceCardById(3);
        resourceCard3.flip();
        ResourceCard resourceCard4 = resourceDeck.getResourceCardById(4);
        resourceCard4.flip();
        ResourceCard resourceCard8 = resourceDeck.getResourceCardById(8);
        ResourceCard resourceCard10 = resourceDeck.getResourceCardById(10);

        gameBoard.setCurrentPlayer(player1);
        controller.playCard(resourceCard8, new Coordinates(1, 1));
        controller.nextPlayer();
        controller.playCard(resourceCard1, new Coordinates(1, 1));
        controller.nextPlayer();
        controller.playCard(resourceCard1, new Coordinates(1, 1));

        assertEquals(resourceCard8, player1.getPersonalBoard().getConfiguration().get(new Coordinates(1, 1)));
        assertEquals(resourceCard1, player2.getPersonalBoard().getConfiguration().get(new Coordinates(1, 1)));
        assertEquals(resourceCard1, player3.getPersonalBoard().getConfiguration().get(new Coordinates(1, 1)));

        assertThrows(InvalidCardPositionException.class, () -> player3.playPlayCard(resourceCard1, new Coordinates(1, 1)));
        assertThrows(InvalidCardPositionException.class, () -> player1.playPlayCard(resourceCard1, new Coordinates(2, 0)));
    }

    /** This test checks if the method getWinner works correctly.
     * It verifies if the winner is correctly identified in normal circumstances and
     * in case there is more than one player with the max points.
     * @throws DeckFinishedException if the deck is empty
     * @throws InvalidCardPositionException if the card is played in an invalid position
     */
    @Test
    void getWinner() throws DeckFinishedException, InvalidCardPositionException {
        Controller controller = new Controller();
        LobbyController lobbyController = new LobbyController(controller);
        GameBoard gameBoard = controller.getGame();

        gameBoard.setNumPlayers(3);

        Player player1 = new Player("player1");
        Player player2 = new Player("player2");
        Player player3 = new Player("player3");

        gameBoard.getPlayers().add(player1);
        gameBoard.getPlayers().add(player2);
        gameBoard.getPlayers().add(player3);

        ResourceDeck resourceDeck = gameBoard.getResourceDeck();
        GoldDeck goldDeck = gameBoard.getGoldDeck();
        GoalDeck goalDeck = gameBoard.getGoalDeck();


        lobbyController.setupGame();

        GoalCard goalCard1 = goalDeck.getGoalCardById(87);
        GoalCard goalCard2 = goalDeck.getGoalCardById(88);
        if (goalCard1 == null)
            goalCard1= new ArrangementGoalCard(87, 2, true, Symbol.RED);
        if (goalCard2==null)
            goalCard2= new ArrangementGoalCard(88, 2, true, Symbol.GREEN);

        gameBoard.getCommonGoals().clear();
        gameBoard.getCommonGoals().add(goalCard1);
        gameBoard.getCommonGoals().add(goalCard2);

        player1.getInitialGoalCards().add(goalCard2);
        player2.getInitialGoalCards().add(goalCard2);
        player3.getInitialGoalCards().add(goalCard2);

        player1.setSecretGoalCard(1);
        if (player1.getSecretGoalCard() == null)
            fail("Secret goal card not found");
        player2.setSecretGoalCard(1);
        if (player2.getSecretGoalCard() == null)
            fail("Secret goal card not found");
        player3.setSecretGoalCard(1);
        if (player3.getSecretGoalCard() == null)
            fail("Secret goal card not found");

        gameBoard.setCurrentPlayer(player1);
        lobbyController.playStarterCard(false);
        controller.nextPlayer();
        lobbyController.playStarterCard(false);
        controller.nextPlayer();
        lobbyController.playStarterCard(false);


        gameBoard.addResourceCard(1,Symbol.RED, Symbol.RED, Symbol.RED, Symbol.EMPTY, null, 0);
        gameBoard.addResourceCard(2, Symbol.RED, Symbol.RED, null, Symbol.RED, Symbol.EMPTY, 0);
        gameBoard.addResourceCard(3, Symbol.RED, Symbol.EMPTY, Symbol.RED, null, Symbol.RED, 0);
        gameBoard.addResourceCard(4, Symbol.RED, null, Symbol.EMPTY, Symbol.RED, Symbol.RED, 0);
        gameBoard.addResourceCard(8, Symbol.RED, Symbol.EMPTY, Symbol.EMPTY, Symbol.RED, null, 1);
        gameBoard.addResourceCard(10,Symbol.RED, null, Symbol.RED, Symbol.EMPTY, Symbol.EMPTY, 1);

        ResourceCard resourceCard1 = resourceDeck.getResourceCardById(1);
        ResourceCard resourceCard2 = resourceDeck.getResourceCardById(2);
        ResourceCard resourceCard3 = resourceDeck.getResourceCardById(3);
        ResourceCard resourceCard4 = resourceDeck.getResourceCardById(4);
        ResourceCard resourceCard8 = resourceDeck.getResourceCardById(8);
        ResourceCard resourceCard10 = resourceDeck.getResourceCardById(10);

        resourceCard1.flip();
        resourceCard2.flip();
        resourceCard3.flip();
        resourceCard4.flip();






        player1.playPlayCard(resourceCard8, new Coordinates(1, 1));

        player2.playPlayCard(resourceCard1, new Coordinates(1, 1));

        player3.playPlayCard(resourceCard1, new Coordinates(1, 1));

        ArrayList<String> winners = controller.getWinners();

        assertTrue(winners.contains("player1"));
        assertFalse(winners.contains("player2"));
        assertFalse(winners.contains("player3"));

        player1.playPlayCard(resourceCard10, new Coordinates(2, 2));

        player2.playPlayCard(resourceCard2, new Coordinates(2, 2));

        player3.playPlayCard(resourceCard2, new Coordinates(2, 2));
        player3.playPlayCard(resourceCard3, new Coordinates(3, 3));

        controller.startLastTurn();
        assertTrue(gameBoard.getIsLastTurn());

        winners = controller.getWinners();

        assertFalse(winners.contains("player1"));
        assertFalse(winners.contains("player2"));
        assertTrue(winners.contains("player3"));
    }

    /** This test checks if the method drawCard works correctly.
     * It verifies if an exception is thrown
     * when trying to draw a card from an empty deck.
     * @throws DeckFinishedException if the deck is empty
     */
    @Test
    void deckFinishedExceptionTest() throws DeckFinishedException {
        Controller controller = new Controller();
        LobbyController lobbyController = new LobbyController(controller);
        GameBoard gameBoard = controller.getGame();

        ResourceDeck resourceDeck = gameBoard.getResourceDeck();
        GoldDeck goldDeck = gameBoard.getGoldDeck();

        gameBoard.setNumPlayers(3);

        Player player1 = new Player("player1");
        Player player2 = new Player("player2");
        Player player3 = new Player("player3");

        gameBoard.getPlayers().add(player1);
        gameBoard.getPlayers().add(player2);
        gameBoard.getPlayers().add(player3);

        lobbyController.setupGame();

        gameBoard.setCurrentPlayer(player1);


        resourceDeck.getCards().clear();
        goldDeck.getCards().clear();

        assertThrows(DeckFinishedException.class, () -> controller.drawCard(resourceDeck));
        assertThrows(DeckFinishedException.class, () -> controller.drawCard(goldDeck));
    }

    /** This test checks if the method drawCard works correctly.
     * It verifies if an exception is thrown
     * when trying to draw a fourth card.
     * @throws DeckFinishedException if the deck is empty
     * @throws MoreThanThreeCardsException if the player tries to draw more than three cards
     * @throws NoCardException if there are no more faceup cards
     * @throws BothDeckFinishedException if both decks are empty
     */
    @Test
    void moreThanThreeCardsExceptionTest() throws DeckFinishedException, MoreThanThreeCardsException, NoCardException, BothDeckFinishedException {
        Controller controller = new Controller();
        LobbyController lobbyController = new LobbyController(controller);
        GameBoard gameBoard = controller.getGame();

        ResourceDeck resourceDeck = gameBoard.getResourceDeck();
        GoldDeck goldDeck = gameBoard.getGoldDeck();

        gameBoard.setNumPlayers(3);

        Player player1 = new Player("player1");
        Player player2 = new Player("player2");
        Player player3 = new Player("player3");

        gameBoard.getPlayers().add(player1);
        gameBoard.getPlayers().add(player2);
        gameBoard.getPlayers().add(player3);

        lobbyController.setupGame();

        gameBoard.setCurrentPlayer(player1);
    controller.drawCard(resourceDeck);
    gameBoard.setCurrentPlayer(player1);
    controller.drawCard(goldDeck);
    gameBoard.setCurrentPlayer(player1);
    controller.drawCard(1);
    gameBoard.setCurrentPlayer(player1);


        assertThrows(MoreThanThreeCardsException.class, () -> controller.drawCard(resourceDeck));
    }

    /** This test checks if all the methods to draw a card (from the resource deck, gold deck and faced up cards) work correctly.
     * It also verifies if an exception is thrown when trying to draw the fourth card.
     * @throws DeckFinishedException if the deck is empty
     * @throws MoreThanThreeCardsException if the player tries to draw more than three cards
     * @throws NoCardException if there are no more faceup cards
     * @throws BothDeckFinishedException if both decks are empty
     */
    @Test
    void testDrawCard() throws DeckFinishedException, MoreThanThreeCardsException, NoCardException, BothDeckFinishedException {
        Controller controller = new Controller();
        LobbyController lobbyController = new LobbyController(controller);
        GameBoard gameBoard = controller.getGame();

        ResourceDeck resourceDeck = gameBoard.getResourceDeck();
        GoldDeck goldDeck = gameBoard.getGoldDeck();

        Player player = new Player("player");
        gameBoard.getPlayers().add(player);
        Player player2 = new Player("player2");
        gameBoard.getPlayers().add(player2);

        gameBoard.setCurrentPlayer(player);
        lobbyController.setupGame();

        player.getPlayCards().clear();
        player2.getPlayCards().clear();

        controller.drawCard(resourceDeck);
        controller.drawCard(resourceDeck);

        controller.drawCard(goldDeck);
        controller.drawCard(goldDeck);

        controller.drawCard(1);
        controller.drawCard(1);

        assertEquals(3, player.getPlayCards().size());
        assertEquals(3, player2.getPlayCards().size());

        assertThrows(MoreThanThreeCardsException.class, () -> controller.drawCard(resourceDeck));
        assertThrows(MoreThanThreeCardsException.class, () -> controller.drawCard(resourceDeck));
        assertThrows(MoreThanThreeCardsException.class, () -> controller.drawCard(goldDeck));
        assertThrows(MoreThanThreeCardsException.class, () -> controller.drawCard(goldDeck));
        assertThrows(MoreThanThreeCardsException.class, () -> controller.drawCard(2));
        assertThrows(MoreThanThreeCardsException.class, () -> controller.drawCard(2));
    }

    @Test
    void testAddPublicMessage(){
        Controller controller = new Controller();
        LobbyController lobbyController = new LobbyController(controller);
        GameBoard gameBoard = controller.getGame();
        Player p1 = new Player("pippo");
        Player p2 = new Player("pluto");
        controller.getPlayers().add(p1);
        controller.getPlayers().add(p2);
        controller.addPublicMessage("pippo", "ciao");
        assertEquals("pippo: ciao", controller.getPublicChat().getMessages().get(0));

    }

    @Test
    void addPrivateMessage(){
        Controller controller = new Controller();
        LobbyController lobbyController = new LobbyController(controller);
        GameBoard gameBoard = controller.getGame();
        Player p1 = new Player("pippo");
        Player p2 = new Player("pluto");
        controller.getPlayers().add(p1);
        controller.getPlayers().add(p2);
        controller.addPrivateMessage("Ciao come va", "pippo", "pluto");
        assertEquals("pippo: Ciao come va", controller.getPrivateChats("pippo", "pluto").get(0));
        assertEquals("pippo: Ciao come va", controller.getPrivateChats("pluto", "pippo").get(0));
    }
}