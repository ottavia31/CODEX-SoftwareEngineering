package it.polimi.ingsw.model;

import org.junit.jupiter.api.Test;

import static junit.framework.Assert.assertEquals;

public class CoordinatesTest {
    @Test
    public void equalsTest(){
        Coordinates c1 = new Coordinates(0,0);
        assertEquals(c1, new Coordinates(0,0));
    }

}
