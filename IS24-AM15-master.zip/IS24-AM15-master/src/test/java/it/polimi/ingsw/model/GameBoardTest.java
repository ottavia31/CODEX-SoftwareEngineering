package it.polimi.ingsw.model;
import it.polimi.ingsw.model.*;
import it.polimi.ingsw.model.cards.*;
import it.polimi.ingsw.model.exceptions.*;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;
/**
 * This class contains unit tests for the GameBoard class.
 * It tests the functionality of drawing face up cards, handling null face up cards,
 * handling situations where both decks are finished, and getting the winner of the game.
 */
class GameBoardTest {
    /**
     * This test checks the basic functionality of the drawFaceUpCard method.
     * It creates a GameBoard and adds some cards to the faced up cards list.
     * Then it draws a card and checks that the drawn card is the expected one.
     * @throws DeckFinishedException if a deck is empty and a player tries to draw a card from it
     * @throws BothDeckFinishedException if both decks are empty and a player tries to draw a card
     * @throws NoCardException if there is no card at the specified index in the faced up cards list
     */
    @Test
    void drawFaceUpCardBasic() throws MoreThanThreeCardsException, NoCardException {
        GameBoard gameboard = new GameBoard();

        // Create some cards
        GoldCard c0 = new GoldCard(1,Symbol.RED, new HashMap<>(), 1, new ArrayList<>(), Symbol.POTION);
        GoldCard c1 = new GoldCard(2,Symbol.RED, new HashMap<>(), 1, new ArrayList<>(), Symbol.FEATHER);
        ResourceCard c2 = new ResourceCard(3,Symbol.RED, new HashMap<>(), 0);
        ResourceCard c3 = new ResourceCard(4,Symbol.RED, new HashMap<>(), 0);

        // Add the cards to the faced up cards list
        ArrayList<PlayCard> facedUpCards = new ArrayList<>();
        facedUpCards.add(c0);
        facedUpCards.add(c1);
        facedUpCards.add(c2);
        facedUpCards.add(c3);
        gameboard.setFacedUpCards(facedUpCards);

        Player player = new Player("player1");
        player.setGameBoard(gameboard);
        gameboard.getPlayers().add(player);
        gameboard.setCurrentPlayer(player);

        // Draw a card
        gameboard.drawFaceUpCard(0);
        gameboard.drawFaceUpCard(1);
        gameboard.drawFaceUpCard(2);
        // Check that the drawn card is the expected one
        assertEquals(c0, gameboard.getCurrentPlayer().getPlayCards().get(0));
        assertEquals(c1, gameboard.getCurrentPlayer().getPlayCards().get(1));
        assertEquals(c2, gameboard.getCurrentPlayer().getPlayCards().get(2));

    }
    /**
     * This test checks the drawFaceUpCard method when there are null cards in the faced up cards list.
     * It creates a GameBoard and adds some cards (including null cards) to the faced up cards list.
     * Then it tries to draw a null card and expects a NoCardException.
     * It also checks that the drawn card is replaced in the faced up cards list.
     * @throws DeckFinishedException if a deck is empty and a player tries to draw a card from it
     * @throws BothDeckFinishedException if both decks are empty and a player tries to draw a card
     * @throws NoCardException if there is no card at the specified index in the faced up cards list
     */

    @Test
    void allCardsPresent(){
        GameBoard gameBoard = new GameBoard();
        for(int i = 1; i < 41; i++){
            if(gameBoard.getResourceDeck().getResourceCardById(i) == null)
                System.out.println(i);
            assertNotNull(gameBoard.getResourceDeck().getResourceCardById(i));
        }
        gameBoard = new GameBoard();
        for(int i = 1; i < 41; i++){
            if(gameBoard.getResourceDeck().getResourceCardById(i) == null)
                System.out.println(i);
            assertNotNull(gameBoard.getResourceDeck().getResourceCardById(i));
        }
        gameBoard = new GameBoard();
        for(int i = 1; i < 41; i++){
            if(gameBoard.getResourceDeck().getResourceCardById(i) == null)
                System.out.println(i);
            assertNotNull(gameBoard.getResourceDeck().getResourceCardById(i));
        }

    }
    @Test
    void drawFaceUpCardNull() throws DeckFinishedException, BothDeckFinishedException, NoCardException {
        GameBoard gameboard = new GameBoard();

        // setting the cards
        // Card 0
        Map<String, Symbol> corners0 = new HashMap<>();
        corners0.put("UL", Symbol.EMPTY);
        corners0.put("DL", null);
        corners0.put("UR", Symbol.POTION);
        corners0.put("DR", Symbol.EMPTY);
        ArrayList<Symbol> ConditionsToUse0 = new ArrayList<>();
        ConditionsToUse0.add(Symbol.RED);
        ConditionsToUse0.add(Symbol.RED);
        ConditionsToUse0.add(Symbol.GREEN);
        GoldCard c0 = new GoldCard(1,Symbol.RED, corners0, 1, ConditionsToUse0, Symbol.POTION);
        // Card 1
        Map<String, Symbol> corners1 = new HashMap<>();
        corners1.put("UL", null);
        corners1.put("DL", Symbol.EMPTY);
        corners1.put("UR", Symbol.EMPTY);
        corners1.put("DR", Symbol.FEATHER);
        ArrayList<Symbol> ConditionsToUse1 = new ArrayList<>();
        ConditionsToUse1.add(Symbol.RED);
        ConditionsToUse1.add(Symbol.RED);
        ConditionsToUse1.add(Symbol.BLUE);
        GoldCard c1 = new GoldCard(1,Symbol.RED, corners1, 1, ConditionsToUse1, Symbol.FEATHER);
        // Card 2
        Map<String, Symbol> corners2 = new HashMap<>();
        corners2.put("UL", Symbol.RED);
        corners2.put("DL", Symbol.RED);
        corners2.put("UR", Symbol.EMPTY);
        corners2.put("DR", null);
        ResourceCard c2 = new ResourceCard(2,Symbol.RED, corners2, 0);
        //Card 3
        Map<String, Symbol> corners3 = new HashMap<>();
        corners3.put("UL", Symbol.RED);
        corners3.put("DL", null);
        corners3.put("UR", Symbol.RED);
        corners3.put("DR", Symbol.EMPTY);
        ResourceCard c3 = new ResourceCard(3,Symbol.RED, corners3, 0);
        // Setting the facedupcard arraylist
        ArrayList<PlayCard> facedUpCards = new ArrayList<>();
        facedUpCards.add(c0);
        facedUpCards.add(c1);
        facedUpCards.add(c2);
        facedUpCards.add(null);
        gameboard.setFacedUpCards(facedUpCards);
        // Set up the decks
        GoldDeck goldDeck = new GoldDeck();
        ResourceDeck resourceDeck = new ResourceDeck();
        // Add some cards to the decks

        resourceDeck.getCards().add(c2); // Add the ResourceCard to the deck first
        goldDeck.getCards().add(c0); // Then add the GoldCard
        gameboard.setGoldDeck(goldDeck);
        gameboard.setResourceDeck(resourceDeck);

        // testing the drawFaceUpCard Method
        assertThrows(NoCardException.class, () -> gameboard.drawFaceUpCard(3)); // Expect a NoCardException when trying to draw a null card

        // Draw a card and check that it's the expected one
        //PlayCard drawnCard = gameboard.drawFaceUpCard(2);
        //assertEquals(c2, drawnCard);

        // Check that the drawn card has been replaced in the faced up cards list
        PlayCard newCard = gameboard.getFacedUpCards().get(2);
        assertEquals(c2, newCard); // Expect the new card to be the one from the resource deck
    }
    /**
     * This test checks the drawFaceUpCard method when both decks are finished.
     * It creates a GameBoard and sets up the decks without adding any cards to them.
     * Then it tries to draw a card and expects a BothDeckFinishedException.
     */
    @Test
    void testBothDecksFinishedException() throws MoreThanThreeCardsException, NoCardException {
        GameBoard gameboard = new GameBoard();

        // Set up the decks
        GoldDeck goldDeck = new GoldDeck();
        ResourceDeck resourceDeck = new ResourceDeck();

        // Set the decks in the gameboard
        gameboard.setGoldDeck(goldDeck);
        gameboard.setResourceDeck(resourceDeck);

        Player player = new Player("player1");
        player.setGameBoard(gameboard);
        gameboard.getPlayers().add(player);
        gameboard.setCurrentPlayer(player);

        // setting the cards
        // Card 0
        Map<String, Symbol> corners0 = new HashMap<>();
        corners0.put("UL", Symbol.EMPTY);
        corners0.put("DL", null);
        corners0.put("UR", Symbol.POTION);
        corners0.put("DR", Symbol.EMPTY);
        ArrayList<Symbol> ConditionsToUse0 = new ArrayList<>();
        ConditionsToUse0.add(Symbol.RED);
        ConditionsToUse0.add(Symbol.RED);
        ConditionsToUse0.add(Symbol.GREEN);
        GoldCard c0 = new GoldCard(1,Symbol.RED, corners0, 1, ConditionsToUse0, Symbol.POTION);
        // Setting the facedupcard arraylist
        ArrayList<PlayCard> facedUpCards = new ArrayList<>();
        facedUpCards.add(c0);
        facedUpCards.add(null);
        facedUpCards.add(null);
        facedUpCards.add(null);
        gameboard.setFacedUpCards(facedUpCards);

        assertEquals(c0, facedUpCards.get(0));

        // Try to draw a card and expect a BothDeckFinishedException
        assertThrows(NoCardException.class, () -> gameboard.drawFaceUpCard(0));
    }

    @Nested
    class GameBoardTestGetWinner {
        /**
         * This test checks the getWinner method.
         * It creates a GameBoard and adds some players with different scores to it.
         * Then it gets the winner and checks that the winner is the expected one.
         */
        @Test
        void testGetWinner() throws RemoteException {
            GameBoard gameBoard = new GameBoard();

            // TODO : devo inizializzare le GoalCard di ognuno e poi i loro calcoli. per questo non riesco a tesattrlo
            // Create players with different scores
            Player player1 = new Player("player1");
            player1.updateScore(10);
            Player player2 = new Player("player2");
            player2.updateScore(10);
            Player player3 = new Player("player3");
            player3.updateScore(9);

            // Add players to the game board
            gameBoard.getPlayers().add(player1);
            gameBoard.getPlayers().add(player2);
            gameBoard.getPlayers().add(player3);

            // create PersonalBoard1
            Map<String, Symbol> frontcorners1 = Map.of("UL", Symbol.EMPTY, "UR", Symbol.GREEN, "DL", Symbol.PURPLE, "DR", Symbol.EMPTY);
            Map<String, Symbol> backcorners1 = Map.of("UL", Symbol.RED, "UR", Symbol.RED, "DL", Symbol.RED, "DR", Symbol.RED);
            ArrayList<Symbol> frontSymbols1 = new ArrayList<>();
            frontSymbols1.add(Symbol.PURPLE);
            StarterCard starterCard1 = new StarterCard(1, frontcorners1,backcorners1, frontSymbols1);
            PersonalBoard personalBoard1 = new PersonalBoard(starterCard1,false);
            // create PersonalBoard2
            Map<String, Symbol> frontcorners2 = Map.of("UL", Symbol.EMPTY, "UR", Symbol.GREEN, "DL", Symbol.PURPLE, "DR", Symbol.EMPTY);
            Map<String, Symbol> backcorners2 = Map.of("UL", Symbol.RED, "UR", Symbol.RED, "DL", Symbol.RED, "DR", Symbol.RED);
            ArrayList<Symbol> frontSymbols2 = new ArrayList<>();
            frontSymbols2.add(Symbol.PURPLE);
            frontSymbols2.add(Symbol.PURPLE);
            StarterCard starterCard2 = new StarterCard(2, frontcorners2,backcorners2, frontSymbols2);
            PersonalBoard personalBoard2 = new PersonalBoard(starterCard2, false);
            // create PersonalBoard3
            Map<String, Symbol> frontcorners3 = Map.of("UL", Symbol.EMPTY, "UR", Symbol.GREEN, "DL", Symbol.PURPLE, "DR", Symbol.EMPTY);
            Map<String, Symbol> backcorners3 = Map.of("UL", Symbol.RED, "UR", Symbol.RED, "DL", Symbol.RED, "DR", Symbol.RED);
            ArrayList<Symbol> frontSymbols3 = new ArrayList<>();
            frontSymbols3.add(Symbol.RED);
            frontSymbols3.add(Symbol.PURPLE);
            StarterCard starterCard3 = new StarterCard(3,frontcorners3,backcorners3, frontSymbols3);
            PersonalBoard personalBoard3 = new PersonalBoard(starterCard3, false);
            // Create some cards
            GoldCard c0 = new GoldCard(1,Symbol.RED, new HashMap<>(), 1, new ArrayList<>(), Symbol.POTION);
            GoldCard c1 = new GoldCard(2,Symbol.RED, new HashMap<>(), 1, new ArrayList<>(), Symbol.FEATHER);
            ResourceCard c2 = new ResourceCard(3,Symbol.RED, new HashMap<>(), 0);
            // Add the cards to the faced up cards list
            ArrayList<PlayCard> facedUpCards = new ArrayList<>();
            facedUpCards.add(c0);
            facedUpCards.add(c1);
            facedUpCards.add(c2);
            // Creating Coordinates for new cards:
            Coordinates coordinates1 = new Coordinates(1,-1);
            Coordinates coordinates2 = new Coordinates(1,-1);
            Coordinates coordinates3 = new Coordinates(1,-1);

            // Creation of a Card instance
            Map<String, Symbol> corners = Map.of("UL", Symbol.PURPLE, "UR", Symbol.PURPLE, "DL", Symbol.EMPTY);
            ResourceCard card1 = new ResourceCard(1,Symbol.PURPLE, corners, 0);

            // Add the card to the PersonalBoard
            try {
                personalBoard1.addCard(coordinates1, card1);
            } catch (HiddenCornerException | NoAdjacentCardException | TwoCornersException | CardsOverlapException | GoldCardException e ) {
                e.printStackTrace();
            }

            // Add the card to the PersonalBoard
            try {
                personalBoard2.addCard(coordinates2, card1);
            } catch (HiddenCornerException | NoAdjacentCardException | TwoCornersException | CardsOverlapException | GoldCardException e ) {
                e.printStackTrace();
            }

            // Add the card to the PersonalBoard
            try {
                personalBoard3.addCard(coordinates3, card1);
            } catch (HiddenCornerException | NoAdjacentCardException | TwoCornersException | CardsOverlapException | GoldCardException e ) {
                e.printStackTrace();
            }

            // calculating secretGoalard points
            player1.setPersonalBoard(personalBoard1);
            Symbol color1 = Symbol.BLUE;
            player1.getInitialGoalCards().add(new ArrangementGoalCard(1,2,true, color1));
            player1.setSecretGoalCard(1);

            player2.setPersonalBoard(personalBoard2);
            player2.getInitialGoalCards().add(new ArrangementGoalCard(2,2,true, Symbol.PURPLE));
            player2.setSecretGoalCard(1);

            player3.setPersonalBoard(personalBoard3);
            player3.getInitialGoalCards().add(new ArrangementGoalCard(3,2,true, Symbol.PURPLE));
            player3.setSecretGoalCard(1);


            // Create some common goal cards
            GoalCard commonGoalCard1 = new ArrangementGoalCard(4,2, true, Symbol.BLUE);
            GoalCard commonGoalCard2 = new ArrangementGoalCard(5,2, true, Symbol.PURPLE);
            ArrayList<GoalCard> commongoals = new ArrayList<>();
            commongoals.add(commonGoalCard1);
            commongoals.add(commonGoalCard2);
            gameBoard.setCommonGoals(commongoals);

            // Get the winner
            List<Player> winners = gameBoard.getWinner();

            // Check that the winner is player2 (same score as player1 but higher common goal score)

            // Check that the winners are player1 and player2 (same total score and highest common goal score)
            assertEquals(2, winners.size());
            assertTrue(winners.contains(player1));
            assertTrue(winners.contains(player2));
        }
    }

    @Nested
    class GameBoardTestGetFaceUpCards {

        /**
         * This test checks the getFacedUpCards method.
         * It creates a GameBoard and adds some cards to the faced up cards list.
         * Then it gets the faced up cards and checks that they are the expected ones.
         */
        @Test
        void getFacedUpCards() {

            GameBoard game = new GameBoard();
            // setting the 1st facedupcard
            Map<String, Symbol> corners1 = Map.of("UL", Symbol.RED, "UR", Symbol.RED, "DL", Symbol.EMPTY, "DR", Symbol.EMPTY);
            ArrayList<Symbol> conditionToUse1 = new ArrayList<Symbol>();
            conditionToUse1.add(Symbol.RED);
            conditionToUse1.add(Symbol.RED);
            PlayCard card1 = new GoldCard(1,Symbol.RED, corners1, 2, conditionToUse1, Symbol.POTION);
            // setting the 2nd facedupcard
            Map<String, Symbol> corners2 = Map.of("UL", Symbol.BLUE, "UR", Symbol.EMPTY, "DL", Symbol.EMPTY, "DR", Symbol.EMPTY);
            ArrayList<Symbol> conditionToUse2 = new ArrayList<Symbol>();
            conditionToUse2.add(Symbol.BLUE);
            conditionToUse2.add(Symbol.BLUE);
            PlayCard card2 = new GoldCard(2,Symbol.BLUE, corners2, 2, conditionToUse2, Symbol.FEATHER);
            // setting the 3th facedupcard
            Map<String, Symbol> corners3 = Map.of("UL", Symbol.PURPLE, "UR", Symbol.PURPLE, "DL", Symbol.EMPTY, "DR", Symbol.EMPTY);
            PlayCard card3 = new ResourceCard(1,Symbol.PURPLE, corners3, 0);
            // setting the 4th facedupcard
            Map<String, Symbol> corners4 = Map.of("UL", Symbol.RED, "UR", Symbol.RED, "DL", Symbol.EMPTY, "DR", Symbol.EMPTY);
            PlayCard card4 = new ResourceCard(2,Symbol.RED, corners4, 0);
            // Setting the facedupcard arraylist
            ArrayList<PlayCard> facedUpCards = new ArrayList<>();
            facedUpCards.add(card1);
            facedUpCards.add(card2);
            facedUpCards.add(card3);
            facedUpCards.add(card4);
            game.setFacedUpCards(facedUpCards);

            // testing the getFaceUpCard method

            assertEquals(card3, game.getFacedUpCards().get(2));
            assertEquals(card4, game.getFacedUpCards().get(3));

        }
        /**
         * This test checks the getFacedUpCards method when there are null cards in the faced up cards list.
         * It creates a GameBoard and adds some cards (including null cards) to the faced up cards list.
         * Then it gets the faced up cards and checks that they are the expected ones.
         */
        @Test
        void getFacedUpCardsNull2() {

            GameBoard game = new GameBoard();
            // setting the 1st facedupcard
            Map<String, Symbol> corners1 = Map.of("UL", Symbol.RED, "UR", Symbol.RED, "DL", Symbol.EMPTY, "DR", Symbol.EMPTY);
            ArrayList<Symbol> conditionToUse1 = new ArrayList<Symbol>();
            conditionToUse1.add(Symbol.RED);
            conditionToUse1.add(Symbol.RED);
            PlayCard card1 = new GoldCard(1,Symbol.RED, corners1, 2, conditionToUse1, Symbol.POTION);
            // setting the 2nd facedupcard
            Map<String, Symbol> corners2 = Map.of("UL", Symbol.BLUE, "UR", Symbol.EMPTY, "DL", Symbol.EMPTY, "DR", Symbol.EMPTY);
            ArrayList<Symbol> conditionToUse2 = new ArrayList<Symbol>();
            conditionToUse2.add(Symbol.BLUE);
            conditionToUse2.add(Symbol.BLUE);
            PlayCard card2 = new GoldCard(2,Symbol.BLUE, corners2, 2, conditionToUse2, Symbol.FEATHER);
            // setting the 3th facedupcard
            Map<String, Symbol> corners3 = Map.of("UL", Symbol.PURPLE, "UR", Symbol.PURPLE, "DL", Symbol.EMPTY, "DR", Symbol.EMPTY);
            PlayCard card3 = new ResourceCard(3,Symbol.PURPLE, corners3, 0);
            ArrayList<PlayCard> facedUpCards = new ArrayList<>();
            facedUpCards.add(card1);
            facedUpCards.add(card2);
            facedUpCards.add(card3);
            facedUpCards.add(null);
            game.setFacedUpCards(facedUpCards);

            // testing the getFaceUpCard method

            assertEquals(card1, game.getFacedUpCards().get(0));
            assertEquals(card2, game.getFacedUpCards().get(1));
            assertEquals(card3, game.getFacedUpCards().get(2));
            assertNull(game.getFacedUpCards().get(3));
        }
        /**
         * This test checks the getFacedUpCards method when there are null cards in the faced up cards list.
         * It creates a GameBoard and adds some cards (including null cards) to the faced up cards list.
         * Then it gets the faced up cards and checks that they are the expected ones.
         */
        @Test
        void getFacedUpCardsNull() {

            GameBoard game = new GameBoard();
            // setting the 1st facedupcard
            Map<String, Symbol> corners1 = Map.of("UL", Symbol.RED, "UR", Symbol.RED, "DL", Symbol.EMPTY, "DR", Symbol.EMPTY);
            ArrayList<Symbol> conditionToUse1 = new ArrayList<Symbol>();
            conditionToUse1.add(Symbol.RED);
            conditionToUse1.add(Symbol.RED);
            PlayCard card1 = new GoldCard(1,Symbol.RED, corners1, 2, conditionToUse1, Symbol.POTION);
            // setting the 3th facedupcard
            Map<String, Symbol> corners3 = Map.of("UL", Symbol.PURPLE, "UR", Symbol.PURPLE, "DL", Symbol.EMPTY, "DR", Symbol.EMPTY);
            PlayCard card3 = new ResourceCard(2,Symbol.PURPLE, corners3, 0);
            ArrayList<PlayCard> facedUpCards = new ArrayList<>();
            facedUpCards.add(card1);
            facedUpCards.add(null);
            facedUpCards.add(card3);
            facedUpCards.add(null);

            game.setFacedUpCards(facedUpCards);

            // testing the getFaceUpCard method

            assertEquals(card1, game.getFacedUpCards().get(0));
            assertNull(game.getFacedUpCards().get(1));
            assertEquals(card3, game.getFacedUpCards().get(2));
            assertNull(game.getFacedUpCards().get(3));
        }

        /**
         * This test checks the getFacedUpCards method when there are null cards in the faced up cards list.
         * It creates a GameBoard and adds some cards (including null cards) to the faced up cards list.
         * Then it gets the faced up cards and checks that they are the expected ones.
         */
        @Test
        void drawFaceupCardTest(){
            GameBoard game = new GameBoard();

            // setting the 1st facedupcard
            Map<String, Symbol> corners1 = Map.of("UL", Symbol.RED, "UR", Symbol.RED, "DL", Symbol.EMPTY, "DR", Symbol.EMPTY);
            ArrayList<Symbol> conditionToUse1 = new ArrayList<Symbol>();
            conditionToUse1.add(Symbol.RED);
            conditionToUse1.add(Symbol.RED);
            PlayCard card1 = new GoldCard(1,Symbol.RED, corners1, 2, conditionToUse1, Symbol.POTION);

            // setting the 2nd facedupcard
            Map<String, Symbol> corners2 = Map.of("UL", Symbol.BLUE, "UR", Symbol.EMPTY, "DL", Symbol.EMPTY, "DR", Symbol.EMPTY);
            ArrayList<Symbol> conditionToUse2 = new ArrayList<Symbol>();
            conditionToUse2.add(Symbol.BLUE);
            conditionToUse2.add(Symbol.BLUE);
            PlayCard card2 = new GoldCard(2,Symbol.BLUE, corners2, 2, conditionToUse2, Symbol.FEATHER);

            // setting the 3th facedupcard
            Map<String, Symbol> corners3 = Map.of("UL", Symbol.PURPLE, "UR", Symbol.PURPLE, "DL", Symbol.EMPTY, "DR", Symbol.EMPTY);
            PlayCard card3 = new ResourceCard(3,Symbol.PURPLE, corners3, 0);

            // setting the 4th facedupcard
            Map<String, Symbol> corners4 = Map.of("UL", Symbol.RED, "UR", Symbol.RED, "DL", Symbol.EMPTY, "DR", Symbol.EMPTY);
            PlayCard card4 = new ResourceCard(4,Symbol.RED, corners4, 0);

            // Setting the facedupcard arraylist
            ArrayList<PlayCard> facedUpCards = new ArrayList<>();
            facedUpCards.add(card1);
            facedUpCards.add(card2);
            facedUpCards.add(card3);
            facedUpCards.add(card4);
            game.setFacedUpCards(facedUpCards);

            //new current player
            Player player = new Player("player1");
            player.setGameBoard(game);
            game.getPlayers().add(player);
            game.setCurrentPlayer(player);


            // testing the drawFaceUpCard method
            try {
                game.drawFaceUpCard(0);
            } catch (NoCardException | MoreThanThreeCardsException e) {
                e.printStackTrace();
            }
            assertEquals(card1, game.getCurrentPlayer().getPlayCards().get(0));
            try {
                game.drawFaceUpCard(1);
            } catch (NoCardException | MoreThanThreeCardsException e) {
                e.printStackTrace();
            }
            assertEquals(card2, game.getCurrentPlayer().getPlayCards().get(1));
            try {
                game.drawFaceUpCard(2);
            } catch (NoCardException | MoreThanThreeCardsException e) {
                e.printStackTrace();
            }
            assertEquals(card3, game.getCurrentPlayer().getPlayCards().get(2));

            assertThrows(MoreThanThreeCardsException.class, () -> game.drawFaceUpCard(3));
            assertThrows(IllegalArgumentException.class, () -> game.drawFaceUpCard(4));

        }
    }
}
