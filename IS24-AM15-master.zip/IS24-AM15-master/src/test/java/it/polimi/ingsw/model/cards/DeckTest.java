package it.polimi.ingsw.model.cards;

import it.polimi.ingsw.controller.Controller;
import it.polimi.ingsw.controller.LobbyController;
import it.polimi.ingsw.model.GameBoard;
import org.junit.jupiter.api.Test;

import java.util.Collections;

import static junit.framework.Assert.assertNotNull;

/**
 * This class tests the functionality of the Deck subclasses.
 * It checks if the decks are correctly initialized and if all the cards are present.
 */
public class DeckTest {
    /**
     * This test checks if the resource deck is correctly initialized and if all the cards are present.
     */
    @Test
    void resourceDeckTest() {
        Controller controller = new Controller();
        GameBoard gameBoard = controller.getGame();
        ResourceDeck resourceDeck = gameBoard.getResourceDeck();
        for(int i = 1; i < 41; i++){
            if(resourceDeck.getResourceCardById(i) == null)
                System.out.println(i);
            assertNotNull(resourceDeck.getResourceCardById(i));
        }

    }
/**
     * This test checks if the gold deck is correctly initialized and if all the cards are present.
     */
    @Test
    void goldDeckTest() {
        GameBoard gameBoard = new GameBoard();
        GoldDeck goldDeck = gameBoard.getGoldDeck();
        Collections.shuffle(goldDeck.getCards());
        for(int i = 41; i < 81; i++){
            if(goldDeck.getGoldCardById(i) == null)
                System.out.println(i);
            assertNotNull(goldDeck.getGoldCardById(i));
        }
    }
/**
     * This test checks if the starter deck is correctly initialized and if all the cards are present.
     */
    @Test
    void starterDeckTest() {
        GameBoard gameBoard = new GameBoard();
        StarterDeck starterDeck = gameBoard.getStarterDeck();
        Collections.shuffle(starterDeck.getCards());
        for(int i = 81; i < 87; i++){
            if(starterDeck.getStarterCardById(i) == null)
                System.out.println(i);
            assertNotNull(starterDeck.getStarterCardById(i));
        }
    }

    @Test
    void goalDeckTest() {
        GameBoard gameBoard = new GameBoard();
        GoalDeck goalDeck = gameBoard.getGoalDeck();
        Collections.shuffle(goalDeck.getCards());
        for(int i = 87; i < 103; i++){
            if(goalDeck.getGoalCardById(i) == null)
                System.out.println(i);
            assertNotNull(goalDeck.getGoalCardById(i));
        }
    }
}
