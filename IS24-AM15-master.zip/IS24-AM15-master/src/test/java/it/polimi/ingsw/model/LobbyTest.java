package it.polimi.ingsw.model;
import it.polimi.ingsw.controller.LobbyController;
import it.polimi.ingsw.controller.Controller;
import org.junit.jupiter.api.Test;

import java.rmi.RemoteException;

import static org.junit.jupiter.api.Assertions.*;

/**
 * This class tests the functionality of the Lobby class.
 * It checks if the game starts correctly and if the number of players is set correctly.
 * It also checks if a player is added correctly to the game.
 */
class LobbyTest {
    /**
     * This test checks if the game starts correctly with the controller.
     * It verifies if the game status is updated to started and if the first player is set correctly.
     */
    @Test
    public void startGameController() {
        Controller controller = new Controller();
        LobbyController lController = new LobbyController(controller);
        Player p1 = new Player("pippo");
        Player p2 = new Player("Pluto");
        Player p3 = new Player("paperino");
        controller.getGame().getPlayers().add(p1); //add all players to the gameBoard
        controller.getGame().getPlayers().add(p2);
        controller.getGame().getPlayers().add(p3);

        controller.getGame().setFirstPlayer(p1); //set the first player

        assertEquals(p1, controller.getGame().getFirstPlayer());

    }
    /**
     * This test checks if the number of players is set correctly in the game.
     * It verifies if an exception is thrown when trying to set an invalid number of players.
     */
    @Test
    public void SetNumWrongPlayers(){
        Controller controller = new Controller();
        LobbyController lController = new LobbyController(controller);
        int old = controller.getGame().getNumPlayers();
        try{
            assertThrows(IllegalArgumentException.class, () -> lController.setNumPlayers(1));
            assertThrows(IllegalArgumentException.class, () -> lController.setNumPlayers(5));
        }catch(IllegalArgumentException e){
            e.printStackTrace();
        }

        assertEquals(old, controller.getGame().getNumPlayers());
    }

    /**
     * This test checks if a player is added correctly to the game.
     * It verifies if the number of players is updated correctly and if an exception is thrown when trying to add a player with an existing name.
     */
    @Test
    public void addPlayertest() throws RemoteException {
        Controller controller = new Controller();
        GameBoard gameBoard = controller.getGame();
        LobbyController lController = new LobbyController(controller);

        lController.setNumPlayers(2);
        assertEquals(2, gameBoard.getNumPlayers());
        assertEquals(0, gameBoard.getPlayers().size());
        assertNotNull(gameBoard);
        assertEquals(2, controller.getGame().getNumPlayers());

        try{
            lController.addPlayer("pippo");
        }catch (IllegalStateException | IllegalArgumentException e){
            e.printStackTrace();
        }
        assertEquals(1, controller.getGame().getPlayers().size());

        try{
            assertThrows(IllegalArgumentException.class, () -> lController.addPlayer("pippo"));
        }catch (IllegalStateException | IllegalArgumentException e){
            e.printStackTrace();
        }
        assertEquals(1, controller.getGame().getPlayers().size());
    }
}