package it.polimi.ingsw.model.cards;

import it.polimi.ingsw.model.*;
import it.polimi.ingsw.model.exceptions.DeckFinishedException;
import it.polimi.ingsw.model.exceptions.InvalidCardPositionException;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * This class tests the functionality of the ArrangementGoalCard class.
 * It checks if the finalGoalPoints method works correctly.
 */
class GoalCardTest {
    /**
     * This test checks if the finalGoalPoints method of the ArrangementGoalCard class works correctly.
     * It verifies if the points are correctly calculated if a goal is reached more than once.
     * @throws InvalidCardPositionException if a card is placed in an invalid position
     */
    @Test
    void finalDiagonalGoalPoints() throws InvalidCardPositionException {
        //Crearion of a StarterCard
        Map<String, Symbol> frontCorners81 = new HashMap<>();
        Map<String, Symbol> backCorners81 = new HashMap<>();

        frontCorners81.put("UL", Symbol.EMPTY);
        frontCorners81.put("DL", Symbol.PURPLE);
        frontCorners81.put("UR", Symbol.GREEN);
        frontCorners81.put("DR", Symbol.EMPTY);
        backCorners81.put("UL", Symbol.RED);
        backCorners81.put("DL", Symbol.PURPLE);
        backCorners81.put("UR", Symbol.GREEN);
        backCorners81.put("DR", Symbol.BLUE);

        ArrayList<Symbol> frontSymbols81 = new ArrayList<>();
        frontSymbols81.add(Symbol.PURPLE);
        StarterCard c81 = new StarterCard(81,frontCorners81, backCorners81, frontSymbols81);
        c81.flip();

        //Creation of a Player
        Player player = new Player("pippo");
        player.setPersonalBoard(new PersonalBoard(c81, true));


        //Adding cards to the board
        //Card 29
        Map<String, Symbol> corners29 = new HashMap<>();
        corners29.put("UL", Symbol.EMPTY);
        corners29.put("DL", Symbol.EMPTY);
        corners29.put("UR", null);
        corners29.put("DR", Symbol.BLUE);
        ResourceCard c29 = new ResourceCard(29,Symbol.BLUE, corners29, 1);
        Coordinates coord29 = new Coordinates(-1,-1);
        player.playPlayCard(c29, coord29);

        //Card 28
        Map<String, Symbol> corners28 = new HashMap<>();
        corners28.put("UL", Symbol.EMPTY);
        corners28.put("DL", Symbol.EMPTY);
        corners28.put("UR", null);
        corners28.put("DR", Symbol.BLUE);
        ResourceCard c28 = new ResourceCard(28,Symbol.BLUE, corners28, 1);
        Coordinates coord28 = new Coordinates(-2,-2);
        player.playPlayCard(c28, coord28);

        //Card 27
        Map<String, Symbol> corners27 = new HashMap<>();
        corners27.put("UL", Symbol.EMPTY);
        corners27.put("DL", Symbol.EMPTY);
        corners27.put("UR", null);
        corners27.put("DR", Symbol.BLUE);
        ResourceCard c27 = new ResourceCard(27,Symbol.BLUE, corners27, 1);
        Coordinates coord27 = new Coordinates(-3,-3);
        player.playPlayCard(c27, coord27);

        //Card 10
        Map<String, Symbol> corners10 = new HashMap<>();
        corners10.put("UL", null);
        corners10.put("DL", Symbol.RED);
        corners10.put("UR", Symbol.EMPTY);
        corners10.put("DR", Symbol.EMPTY);
        ResourceCard c10 = new ResourceCard(10,Symbol.BLUE, corners10, 1);
        Coordinates coord10 = new Coordinates(1,1);
        player.playPlayCard(c10, coord10);

        //Card 11
        Map<String, Symbol> corners11 = new HashMap<>();
        corners11.put("UL", Symbol.GREEN);
        corners11.put("DL", Symbol.GREEN);
        corners11.put("UR", Symbol.EMPTY);
        corners11.put("DR", null);
        ResourceCard c11 = new ResourceCard(11,Symbol.BLUE, corners11, 0);
        Coordinates coord11 = new Coordinates(2,2);
        player.playPlayCard(c11, coord11);

        //Card 12
        Map<String, Symbol> corners12 = new HashMap<>();
        corners12.put("UL", Symbol.GREEN);
        corners12.put("DL", null);
        corners12.put("UR", Symbol.GREEN);
        corners12.put("DR", Symbol.EMPTY);
        Coordinates coord12 = new Coordinates(3,3);
        ResourceCard c12 = new ResourceCard(12,Symbol.BLUE, corners12, 0);
        player.playPlayCard(c12, coord12);



        Symbol color = Symbol.BLUE;
        GoalCard goalCard = new ArrangementGoalCard(2,2,true, color);

        int points = goalCard.finalGoalPoints(player);

        assertEquals(4, points);


    }
    /**
     * This test checks if the finalGoalPoints method of the ArrangementGoalCard class works correctly.
     * It verifies if the points are correctly calculated if a goal is reached.
     * @throws InvalidCardPositionException if a card is placed in an invalid position
     */
    @Test
    void finalGoalPoints() throws DeckFinishedException, InvalidCardPositionException {
        //Creation of a new GameBoard
        GameBoard game = new GameBoard();

        StarterCard starter = game.getStarterDeck().getTopCard();
        ResourceCard card1 = game.getResourceDeck().getTopCard();
        card1.flip();
        ResourceCard card2 = game.getResourceDeck().getTopCard();
        card2.flip();
        ResourceCard card3 = game.getResourceDeck().getTopCard();
        card3.flip();
        ResourceCard card4 = game.getResourceDeck().getTopCard();
        card4.flip();

        //Creation of a new Player
        Player player = new Player("player1");
        player.setPersonalBoard(new PersonalBoard(starter, true));

        //Adding cards to the board
        player.playPlayCard(card1, new Coordinates(-1,1));
        player.playPlayCard(card2, new Coordinates(-2,2));
        player.playPlayCard(card3, new Coordinates(-3,3));

        Symbol color = Symbol.PURPLE;
        GoalCard goalCard = new ArrangementGoalCard(2,2,true, color);

        int points = goalCard.finalGoalPoints(player);

        assertEquals(2, points);
    }

    @Test
    void symbolGoalCardTest() throws InvalidCardPositionException {
        //Crearion of a StarterCard
        Map<String, Symbol> frontCorners81 = new HashMap<>();
        Map<String, Symbol> backCorners81 = new HashMap<>();

        frontCorners81.put("UL", Symbol.EMPTY);
        frontCorners81.put("DL", Symbol.PURPLE);
        frontCorners81.put("UR", Symbol.GREEN);
        frontCorners81.put("DR", Symbol.EMPTY);
        backCorners81.put("UL", Symbol.RED);
        backCorners81.put("DL", Symbol.PURPLE);
        backCorners81.put("UR", Symbol.GREEN);
        backCorners81.put("DR", Symbol.BLUE);

        ArrayList<Symbol> frontSymbols81 = new ArrayList<>();
        frontSymbols81.add(Symbol.PURPLE);
        StarterCard c81 = new StarterCard(81,frontCorners81, backCorners81, frontSymbols81);
        c81.flip();

        //Creation of a Player
        Player player = new Player("pippo");
        player.setPersonalBoard(new PersonalBoard(c81, true));


        //Adding cards to the board
        //Card 29
        Map<String, Symbol> corners29 = new HashMap<>();
        corners29.put("UL", Symbol.BLUE);
        corners29.put("DL", Symbol.BLUE);
        corners29.put("UR", null);
        corners29.put("DR", Symbol.BLUE);
        ResourceCard c29 = new ResourceCard(29,Symbol.BLUE, corners29, 1);
        Coordinates coord29 = new Coordinates(-1,-1);
        player.playPlayCard(c29, coord29);

        //Card 28
        Map<String, Symbol> corners28 = new HashMap<>();
        corners28.put("UL", Symbol.EMPTY);
        corners28.put("DL", Symbol.EMPTY);
        corners28.put("UR", null);
        corners28.put("DR", Symbol.BLUE);
        ResourceCard c28 = new ResourceCard(28,Symbol.BLUE, corners28, 1);
        Coordinates coord28 = new Coordinates(-2,-2);
        player.playPlayCard(c28, coord28);

        //Card 27
        Map<String, Symbol> corners27 = new HashMap<>();
        corners27.put("UL", Symbol.EMPTY);
        corners27.put("DL", Symbol.EMPTY);
        corners27.put("UR", null);
        corners27.put("DR", Symbol.BLUE);
        ResourceCard c27 = new ResourceCard(27,Symbol.BLUE, corners27, 1);
        Coordinates coord27 = new Coordinates(-3,-3);
        player.playPlayCard(c27, coord27);

        //Card 10
        Map<String, Symbol> corners10 = new HashMap<>();
        corners10.put("UL", null);
        corners10.put("DL", Symbol.RED);
        corners10.put("UR", Symbol.EMPTY);
        corners10.put("DR", Symbol.EMPTY);
        ResourceCard c10 = new ResourceCard(10,Symbol.BLUE, corners10, 1);
        Coordinates coord10 = new Coordinates(1,1);
        player.playPlayCard(c10, coord10);

        //Card 11
        Map<String, Symbol> corners11 = new HashMap<>();
        corners11.put("UL", Symbol.GREEN);
        corners11.put("DL", Symbol.BLUE);
        corners11.put("UR", Symbol.BLUE);
        corners11.put("DR", null);
        ResourceCard c11 = new ResourceCard(11,Symbol.BLUE, corners11, 0);
        Coordinates coord11 = new Coordinates(2,2);
        player.playPlayCard(c11, coord11);

        //Card 12
        Map<String, Symbol> corners12 = new HashMap<>();
        corners12.put("UL", Symbol.BLUE);
        corners12.put("DL", null);
        corners12.put("UR", Symbol.BLUE);
        corners12.put("DR", Symbol.EMPTY);
        Coordinates coord12 = new Coordinates(3,3);
        ResourceCard c12 = new ResourceCard(12,Symbol.BLUE, corners12, 0);
        player.playPlayCard(c12, coord12);

        ArrayList<Symbol> symbols = new ArrayList<>();
        symbols.add(Symbol.BLUE);
        symbols.add(Symbol.BLUE);
        symbols.add(Symbol.BLUE);
        GoalCard goalCard = new SymbolsGoalCard(2,2, symbols);

        player.getInitialGoalCards().add(goalCard);
        player.setSecretGoalCard(1);

        int points = goalCard.finalGoalPoints(player);

        assertEquals(8, points);
    }

}