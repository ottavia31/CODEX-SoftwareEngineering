package it.polimi.ingsw.model;
import it.polimi.ingsw.model.cards.GoldCard;
import it.polimi.ingsw.model.cards.ResourceCard;
import it.polimi.ingsw.model.cards.StarterCard;
import it.polimi.ingsw.model.exceptions.*;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;
/**
 * This class contains unit tests for the PersonalBoard class.
 * It tests the addition of cards to the personal board under various conditions,
 * such as when the starter card is flipped, when a gold card is added, and when a card is positioned on a hidden corner.
 */
class PersonalBoardTest {
    /**
     * Tests that a resource card is added correctly to the personal board.
     * The test involves a specific starter card (number 81) and a specific resource card (number 31).
     */
    @Test
    void testAddCard() {
        // Unique identifiers for each card
        int starterCardId = 81;
        int resourceCardId = 31;

        // Creation of a PersonalBoard instance
        Map<String, Symbol> frontcorners = Map.of("UL", Symbol.EMPTY, "UR", Symbol.GREEN, "DL", Symbol.PURPLE, "DR", Symbol.EMPTY);
        Map<String, Symbol> backcorners = Map.of("UL", Symbol.RED, "UR", Symbol.RED, "DL", Symbol.RED, "DR", Symbol.RED);
        ArrayList<Symbol> frontSymbols = new ArrayList<>();
        frontSymbols.add(Symbol.PURPLE);
        StarterCard starterCard = new StarterCard(starterCardId, frontcorners,backcorners, frontSymbols);
        PersonalBoard personalBoard = new PersonalBoard(starterCard, false);

        // Creation of a Card instance
        Map<String, Symbol> corners = Map.of("UL", Symbol.PURPLE, "UR", Symbol.PURPLE, "DL", Symbol.EMPTY);
        ResourceCard card1 = new ResourceCard(resourceCardId, Symbol.PURPLE, corners, 0);

        // Creation of a Coordinates instance
        Coordinates coordinates = new Coordinates(1,1);

        // Save the old number of greens and purples
        int oldGreenValue = personalBoard.getNumOfSymbols().get(Symbol.GREEN);
        int oldPurpleValue = personalBoard.getNumOfSymbols().get(Symbol.PURPLE);

        // Add the card to the PersonalBoard
        try {
            personalBoard.addCard(coordinates, card1);
        } catch (HiddenCornerException | NoAdjacentCardException | TwoCornersException | CardsOverlapException | GoldCardException e ) {
            e.printStackTrace();
        }

        // Verify that the card has been added
        assertEquals(card1, personalBoard.getConfiguration().get(coordinates));

        // Verify that the value of the GREEN symbol has been decremented and the value of the PURPLE symbol stayed the same
        assertEquals(oldGreenValue -1, personalBoard.getNumOfSymbols().get(Symbol.GREEN));
        assertEquals(oldPurpleValue, personalBoard.getNumOfSymbols().get(Symbol.PURPLE));
    }

    /**
     * Tests if a card is added correctly to the personal board when the starter card is flipped.
     * The test involves a specific starter card (number 81) and a specific resource card (number 31).
     */
    @Test
    void testBackSideCard() {
        // Unique identifiers for each card
        int starterCardId = 1;
        int resourceCardId = 2;

        // Creation of a PersonalBoard instance
        Map<String, Symbol> frontcorners = Map.of("UL", Symbol.EMPTY, "UR", Symbol.GREEN, "DL", Symbol.PURPLE, "DR", Symbol.EMPTY);
        Map<String, Symbol> backcorners = Map.of("UL", Symbol.RED, "UR", Symbol.GREEN, "DL", Symbol.PURPLE, "DR", Symbol.BLUE);
        ArrayList<Symbol> frontSymbols = new ArrayList<>();
        Symbol symbol = Symbol.PURPLE;
        assertEquals("PURPLE", symbol.toString());
        frontSymbols.add(symbol);
        StarterCard starterCard = new StarterCard(starterCardId, frontcorners, backcorners, frontSymbols);
        PersonalBoard personalBoard = new PersonalBoard(starterCard, true);

        // Creation of a Card instance
        Map<String, Symbol> corners = Map.of("UL", Symbol.PURPLE, "UR", Symbol.PURPLE, "DL", Symbol.EMPTY);
        ResourceCard card1 = new ResourceCard(resourceCardId, Symbol.PURPLE, corners, 0);
        card1.flip();
        // Creation of a Coordinates instance
        Coordinates coordinates = new Coordinates(1,-1);

        // Add the card to the PersonalBoard
        try {
            personalBoard.addCard(coordinates, card1);
        } catch (HiddenCornerException | NoAdjacentCardException | TwoCornersException | CardsOverlapException | GoldCardException e ) {
            e.printStackTrace();
        }

        // Verify that the card has been added
        assertEquals(card1, personalBoard.getConfiguration().get(coordinates));
        assertEquals(true, personalBoard.getConfiguration().get(new Coordinates(0,0)).isBackSide());
        assertEquals(true, personalBoard.getConfiguration().get(coordinates).isBackSide());
    }

    /**
     * Tests that a card is not added to the personal board if it is positioned on a hidden corner.
     */
    @Test
    void testAddGoldCard() {
        // Unique identifiers for each card
        int starterCardId = 81;
        int resourceCardId = 77;
        int goldCardId = 3;

        // Creation of a PersonalBoard instance
        Map<String, Symbol> frontcorners = Map.of("UL", Symbol.EMPTY, "UR", Symbol.GREEN, "DL", Symbol.PURPLE, "DR", Symbol.EMPTY);
        Map<String, Symbol> backcorners = Map.of("UL", Symbol.RED, "UR", Symbol.RED, "DL", Symbol.RED, "DR", Symbol.RED);
        ArrayList<Symbol> frontSymbols = new ArrayList<>();
        frontSymbols.add(Symbol.PURPLE);
        StarterCard starterCard = new StarterCard(starterCardId, frontcorners, backcorners, frontSymbols);
        PersonalBoard personalBoard = new PersonalBoard(starterCard, false);

        // Creation of a Card instance
        Map<String, Symbol> corners = Map.of("UL", Symbol.PURPLE, "UR", Symbol.PURPLE, "DL", Symbol.EMPTY);
        ResourceCard card1 = new ResourceCard(resourceCardId, Symbol.PURPLE, corners, 0);

        // Creation of a Coordinates instance
        Coordinates coordinates = new Coordinates(1,1);

        // Add the card to the PersonalBoard
        try {
            personalBoard.addCard(coordinates, card1);
        } catch (HiddenCornerException | NoAdjacentCardException | TwoCornersException | CardsOverlapException | GoldCardException e ) {
            e.printStackTrace();
        }

        // Creation of a Card instance
        Map<String, Symbol> corners2 = Map.of("UL", Symbol.POTION,  "DL", Symbol.EMPTY);
        ArrayList<Symbol> conditions = new ArrayList<>();
        conditions.add(Symbol.PURPLE);
        conditions.add(Symbol.PURPLE);
        conditions.add(Symbol.GREEN);
        GoldCard card2 = new GoldCard(goldCardId, Symbol.PURPLE, corners2, 3, conditions, Symbol.EMPTY);

        // Creation of a Coordinates instance
        Coordinates coordinates2 = new Coordinates(0,2);

        // Save the old number of purples
        int oldPurpleValue = personalBoard.getNumOfSymbols().get(Symbol.PURPLE);

        // Add the card to the PersonalBoard
        assertThrows(GoldCardException.class, () -> personalBoard.addCard(coordinates2, card2));


        // Verify that the card has been added
        assertNull(personalBoard.getConfiguration().get(coordinates2));

        // Verify that the value of the PURPLE symbol has not been decremented
        assertEquals(oldPurpleValue , personalBoard.getNumOfSymbols().get(Symbol.PURPLE));
    }

    /**
     * Tests that a card is not added to the personal board if it is positioned on a hidden corner.
     */
    @Test
    void testHiddenCornerexception() {
        // Unique identifiers for each card
        int starterCardId = 81;
        int resourceCardId = 77;

        // Creation of a PersonalBoard instance
        Map<String, Symbol> frontcorners = Map.of("UL", Symbol.EMPTY, "DL", Symbol.PURPLE, "DR", Symbol.EMPTY);
        Map<String, Symbol> backcorners = Map.of("UL", Symbol.RED, "UR", Symbol.RED, "DL", Symbol.RED, "DR", Symbol.RED);
        ArrayList<Symbol> frontSymbols = new ArrayList<>();
        frontSymbols.add(Symbol.PURPLE);
        StarterCard starterCard = new StarterCard(starterCardId, frontcorners, backcorners, frontSymbols);
        PersonalBoard personalBoard = new PersonalBoard(starterCard, false);

        // Creation of a Card instance
        Map<String, Symbol> corners = Map.of("UL", Symbol.PURPLE, "UR", Symbol.PURPLE, "DL", Symbol.EMPTY);
        ResourceCard card1 = new ResourceCard(resourceCardId, Symbol.PURPLE, corners, 0);

        // Creation of a Coordinates instance
        Coordinates coordinates = new Coordinates(1,1);

        // Save the old number of greens and purples
        int oldGreenValue = personalBoard.getNumOfSymbols().get(Symbol.GREEN);
        int oldPurpleValue = personalBoard.getNumOfSymbols().get(Symbol.PURPLE);

        // Add the card to the PersonalBoard
        assertThrows(HiddenCornerException.class, () -> personalBoard.addCard(coordinates, card1));


        // Verify that the card has been added
        assertNull(personalBoard.getConfiguration().get(coordinates));

        // Verify that the value of the GREEN symbol has been decremented and the value of the PURPLE symbol stayed the same
        assertEquals(oldGreenValue, personalBoard.getNumOfSymbols().get(Symbol.GREEN));
        assertEquals(oldPurpleValue, personalBoard.getNumOfSymbols().get(Symbol.PURPLE));
    }
    @Test
    public void testCornerPoints() throws TwoCornersException, HiddenCornerException, CardsOverlapException, GoldCardException, NoAdjacentCardException {
        // Unique identifiers for each card
        int starterCardId = 81;
        int resourceCardId = 77;
        int goldCardId = 3;

        // Creation of a PersonalBoard instance
        Map<String, Symbol> frontcorners = Map.of("UL", Symbol.EMPTY, "UR", Symbol.GREEN, "DL", Symbol.PURPLE, "DR", Symbol.EMPTY);
        Map<String, Symbol> backcorners = Map.of("UL", Symbol.RED, "UR", Symbol.RED, "DL", Symbol.RED, "DR", Symbol.RED);
        ArrayList<Symbol> frontSymbols = new ArrayList<>();
        frontSymbols.add(Symbol.PURPLE);
        StarterCard starterCard = new StarterCard(starterCardId, frontcorners, backcorners, frontSymbols);
        PersonalBoard personalBoard = new PersonalBoard(starterCard, false);

        // Creation of a Card instance
        Map<String, Symbol> corners = Map.of("UL", Symbol.PURPLE, "UR", Symbol.PURPLE, "DL", Symbol.BLUE, "DR", Symbol.PURPLE);
        ResourceCard card1 = new ResourceCard(resourceCardId, Symbol.PURPLE, corners, 0);
        card1.flip();

        // Add the card to the PersonalBoard
        try {
            personalBoard.addCard(new Coordinates(1,1), card1);
            personalBoard.addCard(new Coordinates(1,-1), card1);
            personalBoard.addCard(new Coordinates(2,2), card1);
            personalBoard.addCard(new Coordinates(3,1), card1);
        } catch (HiddenCornerException | NoAdjacentCardException | TwoCornersException | CardsOverlapException | GoldCardException e ) {
            e.printStackTrace();
        }


        // Creation of a Card instance
        Map<String, Symbol> corners2 = Map.of("UL", Symbol.POTION,  "DL", Symbol.EMPTY);
        ArrayList<Symbol> conditions = new ArrayList<>();
        conditions.add(Symbol.PURPLE);
        GoldCard card2 = new GoldCard(goldCardId, Symbol.PURPLE, corners2, 3, conditions, Symbol.CORNER);

        // Add the card to the PersonalBoard
        personalBoard.addCard(new Coordinates(2,0), card2);
        assertEquals(3, personalBoard.cornersCovered(new Coordinates(2,0)) );

    }

}