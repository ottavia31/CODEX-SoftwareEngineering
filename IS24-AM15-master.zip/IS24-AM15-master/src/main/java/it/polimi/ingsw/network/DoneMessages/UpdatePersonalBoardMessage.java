package it.polimi.ingsw.network.DoneMessages;

import it.polimi.ingsw.controller.State;
import it.polimi.ingsw.model.Coordinates;

/**
 * Represents a message confirming the playing of a card on the personal board.
 * Extends {@link DoneMessage}.
 */
public class UpdatePersonalBoardMessage extends DoneMessage {

    private final Integer card;
    private final Coordinates coordinates;
    private final String nickname;
    private final int points;
    private final Boolean isback;

    /**
     * Constructs an UpdatePersonalBoardMessage object.
     *
     * @param state the state associated with this message
     * @param card the card played on the personal board
     * @param isback indicates if the card is played face-up or face-down
     * @param coordinates the coordinates on the personal board where the card is placed
     * @param nickname the nickname of the player
     * @param points the points associated with this action
     */
    public UpdatePersonalBoardMessage(State state, Integer card, Boolean isback, Coordinates coordinates, String nickname, int points) {
        super(ConfirmAction.PLAY_CARD_CONFIRM, state);
        this.card = card;
        this.coordinates = coordinates;
        this.nickname = nickname;
        this.points = points;
        this.isback = isback;
    }

    /**
     * Retrieves the card played on the personal board.
     *
     * @return the card played
     */
    public Integer getCard() {
        return this.card;
    }

    /**
     * Retrieves the coordinates on the personal board where the card is placed.
     *
     * @return the coordinates of the card placement
     */
    public Coordinates getCoordinates() {
        return this.coordinates;
    }

    /**
     * Retrieves the nickname of the player associated with this message.
     *
     * @return the nickname of the player
     */
    public String getNickname() {
        return this.nickname;
    }

    /**
     * Retrieves the points associated with this action.
     *
     * @return the points gained or lost
     */
    public int getPoints() {
        return this.points;
    }

    /**
     * Checks if the card is played face-up or face-down.
     *
     * @return {@code true} if the card is played face-down, {@code false} if face-up
     */
    public Boolean getIsback() {
        return this.isback;
    }
}

