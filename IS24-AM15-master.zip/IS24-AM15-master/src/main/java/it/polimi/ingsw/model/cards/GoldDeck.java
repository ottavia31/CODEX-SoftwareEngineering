package it.polimi.ingsw.model.cards;

import it.polimi.ingsw.model.Symbol;
import it.polimi.ingsw.model.exceptions.DeckFinishedException;

import java.util.ArrayList;
/**
 * This class represents a deck of GoldCards in the game.
 * It implements the Deck interface.
 */
public class GoldDeck implements Deck {
    private final ArrayList<GoldCard> cards;
    /**
     * Constructs a new GoldDeck.
     * Initializes an empty list of GoldCard objects.
     */
    public GoldDeck() {
        super();
        this.cards = new ArrayList<>(); // Initialize the cards field
    }
    /**
     * Returns the top card of the deck (the last card in the list) and removes it from the deck.
     * If the deck is empty, it throws a DeckFinishedException.
     *
     * @return the top card of the deck
     * @throws DeckFinishedException if the deck is empty
     */
    @Override
    public GoldCard getTopCard() throws DeckFinishedException {
        if (cards.isEmpty() || cards.get(cards.size()-1) == null) {
            throw new DeckFinishedException("Deck is empty");
        }
        else {
            GoldCard curr = cards.get(cards.size() - 1);
            cards.remove(cards.size() - 1);
            return curr;
        }
    }
    /**
     * Returns the color of the top card of the deck.
     *
     * @return the color of the top card of the deck
     */
    @Override
    public Symbol getTopCardColor() {
        return cards.get(cards.size() - 1).getColor();
    }

    /**
     * Returns the list of GoldCards in the deck.
     *
     * @return the list of GoldCards in the deck
     */
    public ArrayList<GoldCard> getCards() {
        return cards;
    }
    /**
     * Adds a GoldCard to the deck.
     *
     * @param goldCardId the Id of the GoldCard that has to be added to the deck
     */
    public GoldCard getGoldCardById(int goldCardId) {
        for (GoldCard card : cards) {
            if (card.getId() == goldCardId) {
                return card;
            }
        }
        return null;
    }
}