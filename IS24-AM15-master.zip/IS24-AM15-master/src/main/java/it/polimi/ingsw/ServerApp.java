package it.polimi.ingsw;

import it.polimi.ingsw.controller.Controller;
import it.polimi.ingsw.controller.LobbyController;
import it.polimi.ingsw.network.VirtualServer;
import it.polimi.ingsw.network.rmi.RmiServer;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

import static java.lang.Integer.parseInt;
/**
 * Main class for the server application.
 * Configures and starts the RMI server to handle client connections.
 */
public class ServerApp {
    /**
     * Main method that starts the server application.
     * Configures the RMI hostname, creates necessary controllers, and starts the RMI server.
     *
     * @param args Command line arguments: port for the RMI registry.
     */
    public static void main(String[] args) {
        //192.168.118.7
        System.setProperty("java.rmi.server.hostname", args[1]);
        String name = "VirtualServer";
        Controller controller = new Controller();
        LobbyController lobbyController = new LobbyController(controller);
        VirtualServer engine = new RmiServer(controller, lobbyController);
        VirtualServer stub;
        try {
            stub = (VirtualServer) UnicastRemoteObject.exportObject(engine, 0);
            Registry registry = LocateRegistry.createRegistry(parseInt(args[0]));
            registry.rebind(name, stub);
            engine.run();
        } catch (RemoteException e) {
            System.out.println("Error in establishing a connection, closing...");
            System.exit(0);
        }
    }
}
