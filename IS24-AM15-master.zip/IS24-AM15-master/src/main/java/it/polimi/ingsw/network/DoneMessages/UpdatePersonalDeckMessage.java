package it.polimi.ingsw.network.DoneMessages;

import it.polimi.ingsw.controller.State;

/**
 * Represents a message indicating an update to the personal deck of a player.
 * Extends {@link DoneMessage}.
 */
public class UpdatePersonalDeckMessage extends DoneMessage {

    private final int id;

    /**
     * Constructs an UpdatePersonalDeckMessage object.
     *
     * @param state the state associated with this message
     * @param id the identifier related to the update of the personal deck
     */
    public UpdatePersonalDeckMessage(State state, int id) {
        super(ConfirmAction.UPDATE_PERSONAL_DECK, state);
        this.id = id;
    }

    /**
     * Retrieves the identifier related to the update of the personal deck.
     *
     * @return the identifier of the updated personal deck
     */
    public int getId() {
        return id;
    }
}
