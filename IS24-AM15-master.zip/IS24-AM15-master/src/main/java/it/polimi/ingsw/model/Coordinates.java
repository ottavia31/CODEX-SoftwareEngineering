package it.polimi.ingsw.model;

import java.io.Serializable;

/**
 * This class represents a pair of coordinates in a 2D space.
 */
public class Coordinates implements Serializable {
    int x;
    int y;
    /**
     * Constructs a new pair of coordinates with the given x and y values.
     *
     * @param x the x-coordinate
     * @param y the y-coordinate
     */
    public Coordinates(int x, int y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Returns the x-coordinate.
     *
     * @return the x-coordinate
     */
    public int getX() {
        return x;
    }

    /**
     * Returns the y-coordinate.
     *
     * @return the y-coordinate
     */
    public int getY() {
        return y;
    }


    /**
     * Checks if this pair of coordinates is equal to the given object.
     * The result is true if and only if the argument is not null and is a Coordinates object that represents the same pair of coordinates as this object.
     *
     * @param obj the object to compare this Coordinates against
     * @return true if the given object represents a Coordinates equivalent to this pair of coordinates, false otherwise
     */
    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Coordinates c)) {
            return false;
        }
        return c.x == x && c.y == y;
    }

    /**
     * Returns a hash code for this pair of coordinates.
     *
     * @return a hash code for this pair of coordinates
     */
    @Override
    public int hashCode() {
        int result = Integer.hashCode(x);
        result = 31 * result + Integer.hashCode(y);
        return result;
    }

}


