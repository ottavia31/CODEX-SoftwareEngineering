package it.polimi.ingsw.model;

import it.polimi.ingsw.model.cards.*;
import it.polimi.ingsw.model.exceptions.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
/**
 * The PersonalBoard class represents the personal board of a player in the game.
 * It contains a configuration map that associates each card with its coordinates on the board,
 * and a numOfSymbols map that counts the number of each symbol present on the board.
 */
public class PersonalBoard {
    private final Map<Coordinates, Card> configuration;
    private final Map<Symbol, Integer> numOfSymbols;

    /**
     * The personal board is constructed with a starter card placed in the center
     *
     * @param starterCard the starter card to be placed in the center
     * @param isBack      true if the starter card is placed back side up
     */
    public PersonalBoard(StarterCard starterCard, Boolean isBack) {
        this.configuration = new HashMap<>();
        this.numOfSymbols = new HashMap<>();
        //initialize numOfSymbols with 0
        for (Symbol s : Symbol.values()) {
            this.numOfSymbols.put(s, 0);
        }

        //position the starter card in the center
        Coordinates coordinates = new Coordinates(0, 0);
        starterCard.setBackSide(isBack);
        this.configuration.put(coordinates, starterCard);

        //update the number of symbols
        starterCard.getCorners().forEach((String pos, Symbol s) ->
                this.numOfSymbols.put(s, this.numOfSymbols.getOrDefault(s, 0) + 1));

        if (!starterCard.isBackSide()) {
            //add the symbols in the center of the starter card
            starterCard.getFrontSymbols().forEach(s ->
                    this.numOfSymbols.put(s, this.numOfSymbols.getOrDefault(s, 0) + 1));
        }
    }

    /**
     * Adds a GoldCard to the personal board, checking if it can be placed in the given coordinates
     * and updating the number of symbols accordingly (only the symbols covered by the card)
     *
     * @param coordinates the coordinates where the card should be placed
     * @param card        the GoldCard to be placed
     * @throws HiddenCornerException   if the card is placed on a hidden corner
     * @throws NoAdjacentCardException if there are no adjacent cards to the one being placed
     * @throws TwoCornersException     if the card is placed on two corners of the same card
     * @throws CardsOverlapException   if there is already a card in the given coordinates
     * @throws GoldCardException       if the card is a gold card and the player doesn't have enough resources to place it
     */
    public void addCard(Coordinates coordinates, GoldCard card) throws HiddenCornerException, NoAdjacentCardException, TwoCornersException, CardsOverlapException, GoldCardException {
        // For GoldCards, if I don't meet the conditions to place it, I throw an exception
        if (!card.isBackSide())
            checkGoldCardConditions(card);
        addPlayCard(coordinates, card);
    }

    /**
     * Adds a ResourceCard to the personal board, checking if it can be placed in the given coordinates
     * and updating the number of symbols accordingly (only the symbols covered by the card)
     *
     * @param coordinates the coordinates where the card should be placed
     * @param card        the ResourceCard to be placed
     * @throws HiddenCornerException   if the card is placed on a hidden corner
     * @throws NoAdjacentCardException if there are no adjacent cards to the one being placed
     * @throws TwoCornersException     if the card is placed on two corners of the same card
     * @throws CardsOverlapException   if there is already a card in the given coordinates
     * @throws GoldCardException       if the card is a gold card and the player doesn't have enough resources to place it
     */
    public void addCard(Coordinates coordinates, ResourceCard card) throws HiddenCornerException, NoAdjacentCardException, TwoCornersException, CardsOverlapException, GoldCardException {
        addPlayCard(coordinates, card);
    }

    /**
     * Checks if the conditions to place a GoldCard are met.
     *
     * @param card the GoldCard to be checked
     * @throws GoldCardException if the player doesn't have enough resources to place the GoldCard
     */
    private void checkGoldCardConditions(GoldCard card) throws GoldCardException {

        ArrayList<Symbol> conditions = (card).getConditionsToUse();
        // I save how many times each symbol appears in conditions
        Map<Symbol, Integer> count = new HashMap<>();
        for (Symbol s : conditions) {
            count.put(s, count.getOrDefault(s, 0) + 1);
        }
        // I check that there are enough symbols to be able to place the card
        for (Symbol s : count.keySet()) {
            if (this.numOfSymbols.get(s) < count.get(s))
                throw new GoldCardException("You don't have enough resources to place this gold card");
        }
    }
    /**
     * Adds a PlayCard to the personal board, checking if it can be placed in the given coordinates
     * and updating the number of symbols accordingly (only the symbols covered by the card)
     *
     * @param coordinates the coordinates where the card should be placed
     * @param card        the PlayCard to be placed
     * @throws HiddenCornerException   if the card is placed on a hidden corner
     * @throws NoAdjacentCardException if there are no adjacent cards to the one being placed
     * @throws TwoCornersException     if the card is placed on two corners of the same card
     * @throws CardsOverlapException   if there is already a card in the given coordinates
     */
    private void addPlayCard(Coordinates coordinates, PlayCard card) throws HiddenCornerException, NoAdjacentCardException, TwoCornersException, CardsOverlapException {
    // It saves the coordinates of the surrounding cards that it could cover
        Coordinates UL = new Coordinates(coordinates.x - 1, coordinates.y + 1),
                UR = new Coordinates(coordinates.x + 1, coordinates.y + 1),
                DL = new Coordinates(coordinates.x - 1, coordinates.y - 1),
                DR = new Coordinates(coordinates.x + 1, coordinates.y - 1);
        // I save the cards at those coordinates
        Card ULcard = this.configuration.get(UL),
                URcard = this.configuration.get(UR),
                DLcard = this.configuration.get(DL),
                DRcard = this.configuration.get(DR);
        // I save the symbols on the corners OF THE OTHER CARDS that I could cover (if they exist)
        Symbol ULCorner = Symbol.EMPTY, URCorner = Symbol.EMPTY, DLCorner = Symbol.EMPTY, DRCorner = Symbol.EMPTY;

        if (ULcard != null) {
            if (ULcard.isBackSide() && !UL.equals(new Coordinates(0,0)))
                ULCorner = Symbol.EMPTY;
            else
                ULCorner = ULcard.getCorners().get("DR"); //could be null
        }
        if (URcard != null) {
            if (URcard.isBackSide() && !UR.equals(new Coordinates(0,0)))
                URCorner = Symbol.EMPTY;
            else
                URCorner = URcard.getCorners().get("DL");
        }
        if (DLcard != null) {
            if (DLcard.isBackSide() && !DL.equals(new Coordinates(0,0)))
                DLCorner = Symbol.EMPTY;
            else
                DLCorner = DLcard.getCorners().get("UR");
        }
        if (DRcard != null) {
            if (DRcard.isBackSide() && !DR.equals(new Coordinates(0,0)))
                DRCorner = Symbol.EMPTY;
            else
                DRCorner = DRcard.getCorners().get("UL");
        }

        // I check that there is not already a card in that position
        if (this.configuration.containsKey(coordinates))
            throw new CardsOverlapException("You can't place a card in a position that is already occupied");

        // I check that the card is placeable (that all covered corners are not null, if the card exists)
        if ((ULCorner == null || URCorner == null || DLCorner == null || DRCorner == null))
            throw new HiddenCornerException("You can't place a card on a hidden corner");

        // I check that I'm not covering two corners of the same card
        // (i.e., I throw an exception if its coordinates are one even and one odd)
        if (coordinates.getX() % 2 == 0 && coordinates.getY() % 2 != 0 || coordinates.getX() % 2 != 0 && coordinates.getY() % 2 == 0)
            throw new TwoCornersException("You can't cover two corners of the same card");

        // I check that there is at least one card in the positions adjacent to where I am attaching it
        if (ULcard == null && URcard == null && DLcard == null && DRcard == null)
            throw new NoAdjacentCardException("You can't place a card without any adjacent card");


        // I add the card to the map
        this.configuration.put(coordinates, card);

        // If I have covered a resource, I decrement num and remove the symbol from the list
        // Upper left corner
        if (ULcard != null)
            this.numOfSymbols.put(ULCorner, this.numOfSymbols.get(ULCorner) - 1);

        // Upper right corner
        if (URcard != null)
            this.numOfSymbols.put(URCorner, this.numOfSymbols.get(URCorner) - 1);

        // Lower left corner
        if (DLcard != null)
            this.numOfSymbols.put(DLCorner, this.numOfSymbols.get(DLCorner) - 1);


        // Lower right corner
        if (DRcard != null)
            this.numOfSymbols.put(DRCorner, this.numOfSymbols.get(DRCorner) - 1);
        }

    /**
     * Returns the configuration of the personal board.
     * The configuration is a map where the keys are the coordinates of the cards and the values are the cards.
     *
     * @return the configuration of the personal board
     */
    public Map<Coordinates, Card> getConfiguration () {
        return configuration;
    }
    /**
     * Returns the number of each symbol on the personal board.
     * The returned map has symbols as keys and their counts as values.
     *
     * @return the map of each the symbols and their quantity on the personal board
     */
    public Map<Symbol, Integer> getNumOfSymbols () {
        return numOfSymbols;
    }

    /**
     * Calculates the number of corners covered by coordinates in the current configuration.
     * Corners are checked diagonally adjacent to the provided coordinates.
     *
     * @param coordinates the coordinates for which corners are checked
     * @return the number of corners covered by the provided coordinates
     */
    public int cornersCovered(Coordinates coordinates) {
            int points = 0;
        Coordinates UL = new Coordinates(coordinates.x - 1, coordinates.y + 1),
                UR = new Coordinates(coordinates.x + 1, coordinates.y + 1),
                DL = new Coordinates(coordinates.x - 1, coordinates.y - 1),
                DR = new Coordinates(coordinates.x + 1, coordinates.y - 1);

        if( this.configuration.get(UL) != null)
            points++;
        if( this.configuration.get(UR) != null)
            points++;
        if( this.configuration.get(DL) != null)
            points++;
        if( this.configuration.get(DR) != null)
            points++;

        return points;
    }
}