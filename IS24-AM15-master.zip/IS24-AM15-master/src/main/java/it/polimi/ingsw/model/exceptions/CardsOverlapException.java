package it.polimi.ingsw.model.exceptions;

/**
 * This class represents an exception that is thrown when there is an attempt to place a card
 * in a position that is already occupied by another card on the game board.
 */
public class CardsOverlapException extends Exception{
    /**
     * Constructs a new CardsOverlapException with the specified detail message.
     * @param message the detail message. The detail message is saved for later retrieval by the Throwable.getMessage() method.
     */
    public CardsOverlapException(String message) {
        super(message);
    }
}