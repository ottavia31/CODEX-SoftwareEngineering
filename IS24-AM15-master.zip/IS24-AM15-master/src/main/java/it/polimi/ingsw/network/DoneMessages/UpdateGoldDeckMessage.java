package it.polimi.ingsw.network.DoneMessages;
import it.polimi.ingsw.controller.State;
import it.polimi.ingsw.model.Symbol;

/**
 * Represents a message indicating an update to the gold deck color.
 * Extends {@link DoneMessage}, specifying the updated gold deck color and its state.
 */
public class UpdateGoldDeckMessage extends DoneMessage {

    private final Symbol color;

    /**
     * Constructs a new UpdateGoldDeckMessage with the specified game state and updated gold deck color.
     *
     * @param state the state associated with the update.
     * @param color the updated gold deck color.
     */
    public UpdateGoldDeckMessage(State state, Symbol color) {
        super(ConfirmAction.GOLD_DECK_UPDATE, state);
        this.color = color;
    }

    /**
     * Retrieves the updated gold deck color.
     *
     * @return the updated gold deck color.
     */
    public Symbol getColor() {
        return color;
    }
}
