/**
 * This class represents a custom exception that is thrown when a card is placed
 * in a position where there are no adjacent cards.
 */
package it.polimi.ingsw.model.exceptions;

/**
 * Exception thrown when there are no adjacent cards found.
 */
public class NoAdjacentCardException extends Exception {
    /**
     * Constructs a new exception with the specified detail message.
     *
     * @param message the detail message. The detail message is saved for 
     *                later retrieval by the {@link #getMessage()} method.
     */
    public NoAdjacentCardException(String message) {
        super(message);
    }
}