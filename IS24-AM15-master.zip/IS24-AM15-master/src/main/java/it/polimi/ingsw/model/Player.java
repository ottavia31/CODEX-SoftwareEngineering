package it.polimi.ingsw.model;

import it.polimi.ingsw.model.cards.*;
import it.polimi.ingsw.model.exceptions.*;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Player class represents a player in the game. It contains all the information about the player, such as the score,
 * the nickname, the pawn color, the personal board, the goal cards, the play cards, the secret goal card, the game board
 * and the starter card.
 */
public class Player implements Serializable {
    private int score;
    private boolean isFirst;
    private PawnColor pawn;
    private final String nickname;
    private final ArrayList<PlayCard> playCards;
    private GoalCard secretGoalCard;
    private final ArrayList<GoalCard> goalCards;
    private GameBoard gameBoard;
    private PersonalBoard personalBoard;
    private StarterCard starterCard;

    /**
     * Constructor for the Player class.
     * @param nickname the nickname of the player
     */
    public Player(String nickname){
        this.nickname = nickname;
        this.personalBoard = null;
        this.score = 0;
        this.secretGoalCard = null;
        this.isFirst = false;
        this.pawn = null;
        this.playCards = new ArrayList<>();
        this.goalCards = new ArrayList<>();
    }

    /**
     * Returns the score of the player.
     * @return the score of the player
     */
    public int getScore(){
        return this.score;
    }
    /**
     * Returns whether the player is the first player.
     * @return true if the player is the first player, false otherwise
     */
    public boolean getIsFirst(){
        return isFirst;
    }
    /**
     * Returns the nickname of the player.
     * @return the nickname of the player
     */
    public String getNickname(){ return this.nickname; }
    /**
     * Returns the personal board of the player.
     * @return the personal board of the player
     */
    public PersonalBoard getPersonalBoard(){
        return this.personalBoard;
    }
    /**
     * Returns the initial goal cards of the player.
     * @return the initial goal cards of the player
     */
    public ArrayList<GoalCard> getInitialGoalCards(){
        return goalCards;
    }
    /**
     * Returns the starter card of the player.
     * @return the starter card of the player
     */
    public StarterCard getStarterCard() {
        return starterCard;
    }
    /**
     * Returns the play cards of the player.
     * @return the play cards of the player
     */
    public ArrayList<PlayCard> getPlayCards(){
        return this.playCards;
    }
    /**
     * Returns the secret goal card of the player.
     * @return the secret goal card of the player
     */
    public GoalCard getSecretGoalCard(){return this.secretGoalCard;}
    /**
     * Returns the pawn color of the player.
     * @return the pawn color of the player
     */
    public PawnColor getPawnColor() {return pawn;}
    /**
     * Updates the score of the player by adding the given points to the current score.
     * @param points the points to be added to the score
     */
    public void updateScore(int points){
        this.score= this.score + points;
    }
    /**
     * Sets the personal board of the player.
     * @param personalBoard the personal board to be set
     */
    public void setPersonalBoard(PersonalBoard personalBoard) {
        this.personalBoard = personalBoard;
    }
    /**
     * Sets the starter card of the player.
     * @param starterCard the starter card to be set
     */
    public void setStarterCard(StarterCard starterCard) {
        this.starterCard = starterCard;
    }
    /**
     * Sets whether the player is the first player.
     * @param first true if the player is the first player, false otherwise
     */
    public void setIsFirst(boolean first) {isFirst = first;}
    /**
     * Sets the pawn color of the player.
     * @param color the pawn color to be set
     */
    public void setPawnColor(PawnColor color) {
        pawn = color;

    }

    /**
     * Sets the game board of the player.
     * @param g the game board to be set
     */
    public void setGameBoard(GameBoard g){gameBoard = g;}

    /**
     * Sets the secret goal card of the player.
     * @param numCard the index of the goal card to be set as the secret goal card
     */
    public void setSecretGoalCard(int numCard){
        this.secretGoalCard = this.goalCards.get(numCard - 1);
    }
    /**
     * Adds a play card to the player's play cards.
     * @param card the play card to be added
     */
    public void setPlayCard(PlayCard card){
        this.playCards.add(card);
    }

    /**
     *  Places a card on the personal board of the player,
     * updates the player's score and the symbols added to the personal board
     *
     * @param card the card to be placedù
     * @param coordinates the coordinates where the card should be placed
     *
     * @throws InvalidCardPositionException if the card cannot be placed in the given coordinates
     */
    public void playPlayCard(GoldCard card, Coordinates coordinates) throws InvalidCardPositionException {
        PersonalBoard oldPersonalBoard = this.personalBoard;

        // Add the card to the PersonalBoard and update the symbols
        try {
            personalBoard.addCard(coordinates, card);
        } catch (HiddenCornerException | NoAdjacentCardException | TwoCornersException | CardsOverlapException |
                 GoldCardException e) {
            throw new InvalidCardPositionException(e.getMessage());
        }

        // Update the score based on the current state of the PersonalBoard
        if (!card.isBackSide()) {
            Symbol goal =  card.getGoal();
            if (goal == null) {
                score += card.getPoints();
                return;
            }
            int goalCount;
            if (goal != null) {
                if(goal.equals(Symbol.CORNER)){
                    goalCount = oldPersonalBoard.cornersCovered(coordinates);
                } else {
                    goalCount = oldPersonalBoard.getNumOfSymbols().get(goal);
                }
                // Update the score based on the number of goal symbols and the points of the GoldCard
                score += goalCount * card.getPoints();
                }
            }
        updateBoard(card);
    }

    /**
     * Places a ResourceCard on the player's personal board, updates the score and the symbols on the personal board.
     *
     * @param card the ResourceCard to be placed on the personal board
     * @param coordinates the coordinates where the card should be placed
     * @throws InvalidCardPositionException if the card cannot be placed in the given coordinates due to various reasons such as hidden corner, no adjacent card, two corners of the same card, cell already occupied, or insufficient resources for a gold card
     */
    public void playPlayCard(ResourceCard card, Coordinates coordinates) throws InvalidCardPositionException {
        // Add the card to the PersonalBoard and update the symbols
        try {
            personalBoard.addCard(coordinates, card);
        } catch (HiddenCornerException e) {
            throw new InvalidCardPositionException("Invalid card position: You can't place a card on a hidden corner");
        } catch (NoAdjacentCardException e) {
            throw new InvalidCardPositionException("Invalid card position: You can only place a card on a corner of another card");
        } catch (TwoCornersException e) {
            throw new InvalidCardPositionException("Invalid card position: You can't place a card on two corners of the same card");
        } catch (CardsOverlapException e) {
            throw new InvalidCardPositionException("Invalid card position: You can't place a card on a cell that is already occupied");
        } catch (GoldCardException e) {
            throw new InvalidCardPositionException("Invalid card position: You don't have enough resources to place this gold card");
        }

        // Update the score based on the current state of the PersonalBoard
        if (!card.isBackSide())
            score = score + card.getPoints();

        updateBoard(card);
    }
    /**
     * Updates the player's personal board after a PlayCard has been placed.
     * It removes the card from the player's deck, updates the score based on the card's symbols,
     * and sets the game to be over if the player's score reaches or exceeds 20.
     *
     * @param card the PlayCard that has been placed on the personal board
     */
    public void updateBoard(PlayCard card){
        // Remove the card from the personal deck
        playCards.remove(card);
        // If the card is not a GoldCard, update the score based on the updated state of the PersonalBoard
            if (!card.isBackSide()) {
                for (Symbol symbol : card.getCorners().values()) {
                    if (symbol != null && !symbol.equals(Symbol.EMPTY)) {
                        int old = personalBoard.getNumOfSymbols().get(symbol);
                        personalBoard.getNumOfSymbols().put(symbol, old + 1);
                    }
                }
            } else {
                Symbol center = card.getColor();
                int old = personalBoard.getNumOfSymbols().get(center);
                personalBoard.getNumOfSymbols().put(center, old + 1);
            }
    }

    /**
     * Receives the deck from which to draw and calls the drawCard method of the current player
     * @param resourceDeck the deck from which to draw
     * @throws MoreThanThreeCardsException if the player already has three cards in their personal deck
     * @throws DeckFinishedException if there are no more cards in the deck
     */
    public void drawCard(ResourceDeck resourceDeck) throws MoreThanThreeCardsException, DeckFinishedException {
        if(playCards.size()==3){
            throw new MoreThanThreeCardsException("Non puoi pescare se hai già tre carte nel tuo mazzo!");
        }
        PlayCard c = resourceDeck.getTopCard();
        playCards.add(c);

    }
    /**
     * Receives the deck from which to draw and calls the drawCard method of the current player
     * @param goldDeck the deck from which to draw
     * @throws MoreThanThreeCardsException if the player already has three cards in their personal deck
     * @throws DeckFinishedException if there are no more cards in the deck
     */
    public void drawCard(GoldDeck goldDeck) throws MoreThanThreeCardsException, DeckFinishedException {
        if(playCards.size()==3){
            throw new MoreThanThreeCardsException("Non puoi pescare se hai già tre carte nel tuo mazzo!");
        }
        PlayCard c = goldDeck.getTopCard();
        this.playCards.add(c);

    }


}