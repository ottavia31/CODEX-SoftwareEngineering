package it.polimi.ingsw.network.DoneMessages;

import it.polimi.ingsw.controller.State;

/**
 * Represents a disconnection message in the application, extending from the DoneMessage class.
 * This class encapsulates information about the disconnection event and the client identifier.
 */
public class DisconnectionMessage extends DoneMessage {
    private final Integer client;

    /**
     * Constructs a DisconnectionMessage object with the specified parameters.
     *
     * @param type    the type of confirmation action associated with the disconnection
     * @param state   the state associated with the disconnection event
     * @param client  the identifier of the client that got disconnected
     */
    public DisconnectionMessage(ConfirmAction type, State state, Integer client) {
        super(type, state);
        this.client = client;
    }

    /**
     * Retrieves the identifier of the client that got disconnected.
     *
     * @return the identifier of the disconnected client
     */
    public Integer getClient() {
        return client;
    }
}

