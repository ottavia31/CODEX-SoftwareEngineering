package it.polimi.ingsw.network.DoneMessages;


import it.polimi.ingsw.controller.State;

/**
 * Represents a message indicating an update to a faced-up card in the game.
 * Extends {@link DoneMessage}, specifying the ID and index of the updated card.
 */
public class UpdateFacedupCardsMessage extends DoneMessage {

    private int id; // The ID of the updated faced-up card
    private int index; // The index of the faced-up card in the list

    /**
     * Constructs a new UpdateFacedupCardsMessage with the specified game state, card ID, and index.
     *
     * @param state the updated game state after the faced-up card update.
     * @param id the ID of the faced-up card that was updated.
     * @param index the index of the faced-up card in the list of faced-up cards.
     */
    public UpdateFacedupCardsMessage(State state, int id, int index) {
        super(ConfirmAction.FACEDUP_CARDS_UPDATE, state);
        this.id = id;
        this.index = index;
    }

    /**
     * Retrieves the ID of the faced-up card that was updated.
     *
     * @return the ID of the updated faced-up card.
     */
    public int getId() {
        return id;
    }

    /**
     * Retrieves the index of the faced-up card in the list of faced-up cards.
     *
     * @return the index of the faced-up card.
     */
    public int getIndex() {
        return index;
    }
}
