package it.polimi.ingsw.model;
import java.util.ArrayList;

/**
 * Represents a public chat containing messages from various senders.
 */
public class PublicChat {
    private final ArrayList<String> messages = new ArrayList<>();

    /**
     * Constructor for the PublicChat class.
     * Initializes an empty list of messages.
     */
    public PublicChat() {

    }

    /**
     * Adds a message to the public chat.
     *
     * @param sender  The sender of the message.
     * @param message The content of the message.
     */
    public void addMessage(String sender, String message) {
        this.messages.add(sender + ": " + message);
    }

    /**
     * Retrieves all messages in the public chat.
     *
     * @return An ArrayList containing all messages in the chat.
     */
    public ArrayList<String> getMessages() {
        return this.messages;
    }
}
