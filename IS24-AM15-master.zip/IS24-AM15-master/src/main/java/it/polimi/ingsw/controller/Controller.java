package it.polimi.ingsw.controller;

import it.polimi.ingsw.model.*;
import it.polimi.ingsw.model.cards.*;
import it.polimi.ingsw.model.exceptions.*;

import java.util.ArrayList;

/**
 * The Controller class is responsible for managing the game logic and coordinating interactions between the model and the view.
 */
public class Controller {
    private final GameBoard model;
    private State state;
    private final ArrayList<Chat> privateChats = new ArrayList<>();
    private final PublicChat publicChat = new PublicChat();
    private static final int MAX_SCORE = 20;

    /**
     * Constructor for the Controller class.
     * Initializes the game board and sets the state to STARTED.
     */
    public Controller(){
        this.model = new GameBoard();
        this.state = State.STARTED;
    }


    /**
     * Returns the current state of the game.
     * @return the current state of the game.
     */
    public State getState() {
        return state;
    }


    /** Controls the flow of the game by updating the state based on the current state.
     * The state is updated according to the following rules:
     * - STARTED -> FIRST_PLAYER_ADDED
     * - FIRST_PLAYER_ADDED -> NUM_SETTED
     * - NUM_SETTED -> PLAYER_ADDED if the number of players is less than the total number of players
     * - PLAYER_ADDED -> GAME_SETTED if the number of players is equal to the total number of players
     * - GAME_SETTED -> ALL_PAWNS_SETTED if all players have set their pawns
     * - ALL_PAWNS_SETTED -> STARTER_CARD_PLAYED if all players have played their starter cards
     * - STARTER_CARD_PLAYED -> ALL_SECRET_GOALS_SETTED if all players have set their secret goals
     * - ALL_SECRET_GOALS_SETTED -> THROWN if all players have thrown the card
     * - THROWN -> DRAWN if one player has drawn a card
     * - DRAWN -> POINTS_CALCULATED if all players have played in the last turn
     * - POINTS_CALCULATED -> END_GAME if the game is over
     */
    public void updateState(){
        switch(state){
            case STARTED -> this.state = State.FIRST_PLAYER_ADDED;
            case FIRST_PLAYER_ADDED -> this.state = State.NUM_SETTED;
            case NUM_SETTED -> {
                if (this.getGame().getPlayers().size() == this.getGame().getNumPlayers()) {
                    this.state = State.ALL_PLAYERS_ADDED;
                } else {
                    this.state = State.PLAYER_ADDED;
                }
            }

            case ALL_PLAYERS_ADDED -> this.state = State.GAME_SETTED;
            case PLAYER_ADDED -> {
                if (this.getGame().getPlayers().size() == this.getGame().getNumPlayers())
                    this.state = State.ALL_PLAYERS_ADDED;
            }
            case GAME_SETTED -> {
                if(getCurrentPlayerNickname().equals(this.getGame().getPlayers().get(getGame().getNumPlayers()-1).getNickname())){
                    this.state = State.ALL_PAWNS_SETTED;
                }

            }
            case ALL_PAWNS_SETTED ->{
              if(getCurrentPlayerNickname().equals(this.getGame().getPlayers().get(getGame().getNumPlayers()-1).getNickname())) {
                this.state = State.STARTER_CARD_PLAYED;
              }
            }
            case STARTER_CARD_PLAYED -> {
                if(getCurrentPlayerNickname().equals(this.getGame().getPlayers().get(getGame().getNumPlayers()-1).getNickname())) {
                    this.state = State.ALL_SECRET_GOALS_SETTED;
                }
            }
            case ALL_SECRET_GOALS_SETTED -> this.state = State.THROWN;
            case THROWN -> this.state = State.DRAWN;
            case DRAWN -> {
                if(this.getGame().getIsLastTurn() && this.getCurrentPlayer().equals(this.getGame().getPlayers().get(getGame().getNumPlayers()-1))){
                    //calcola i punti di tutti
                    this.state = State.LAST_TURN_COMPLETED;
                } else {
                    this.state = State.THROWN;
                }

            }
            case POINTS_CALCULATED -> this.state = State.END_GAME;



        }
    }

    /**
     * Aggiunge un messaggio privato tra due utenti specificati.
     *
     * @param message Il messaggio da aggiungere.
     * @param sender Il mittente del messaggio.
     * @param receiver Il destinatario del messaggio.
     */
    public void addPrivateMessage(String message, String sender, String receiver){
        for(Chat c : privateChats){
            if(c.getP1().equals(sender) && c.getP2().equals(receiver) || c.getP2().equals(sender) && c.getP1().equals(receiver)){
                c.addMessage(sender, message);
                return;
            }
        }
        this.privateChats.add(new Chat(sender, receiver, sender, message));
    }

    /**
     * Aggiunge un messaggio pubblico alla chat pubblica.
     *
     * @param sender Il mittente del messaggio.
     * @param message Il messaggio da aggiungere.
     */
    public void addPublicMessage(String sender, String message){
        this.publicChat.addMessage(sender, message);
    }

    /**
     * Restituisce la chat pubblica.
     *
     * @return L'oggetto PublicChat che rappresenta la chat pubblica.
     */
    public PublicChat getPublicChat(){ return this.publicChat; }

    /**
     * Restituisce la lista dei messaggi tra due utenti specificati in una chat privata.
     *
     * @param player1 Il primo utente.
     * @param player2 Il secondo utente.
     * @return Un ArrayList di stringhe contenente i messaggi tra i due utenti.
     */
    public ArrayList<String> getPrivateChats(String player1, String player2) {
        ArrayList<String> c = new ArrayList<>();
        for(Chat chat : this.privateChats){
            if(chat.getP1().equals(player1) && chat.getP2().equals(player2) || chat.getP2().equals(player1) && chat.getP1().equals(player2)){
               c = chat.getChat();
            }
        }
        return c;
    }

    /**
     * Returns the game board.
     * @return the game board.
     */
    public GameBoard getGame(){
        return this.model;
    }

    /**
     * Changes the state of the game to LastTurn.
     */
    public void startLastTurn(){
        //notify the view that the last turn has started
        this.model.setIsStarted(false);
        this.model.isLastTurn(true);
    }

    /**
     * Changes the current player of the game to the next player.
     * If the current player is the last player in the list, the first player is set as the current player.
     */
    public void nextPlayer(){
        //notifica il prossimo giocatore che è il suo turno
        ArrayList<Player> players = this.getPlayers();
        int index = players.indexOf(this.getCurrentPlayer());
        if (index == players.size() - 1){
            this.getGame().setCurrentPlayer(players.getFirst());
        } else {
            this.getGame().setCurrentPlayer(players.get(index + 1));
        }
    }

    /**
     * Gets the nicknames of the winners of the game.
     * @return the nicknames of the winners of the game.
     */
    public ArrayList<String> getWinners(){
        ArrayList<String> winners = new ArrayList<>();
        this.getGame().getWinner().forEach(player -> winners.add(player.getNickname()));
        return winners;
    }

    /**
     * Returns the nickname of the current player.
     * @return the nickname of the current player.
     */
    public String getCurrentPlayerNickname() {
        return this.getGame().getCurrentPlayer().getNickname();
    }

    /**
     * Gets the current player of the game.
     * @return the current player of the game.
     */
    public Player getCurrentPlayer(){
        return this.getGame().getCurrentPlayer();
    }

    /**
     * Returns the list of players of the game.
     * @return the list of players of the game.
     */
    public ArrayList<Player> getPlayers(){
        return this.getGame().getPlayers();
    }


    /**
     * Places a card on the personal board of the current player
     * @param card the card to be placed
     * @param coordinates the coordinates where the card should be placed
     */
    public void playCard(PlayCard card, Coordinates coordinates) throws InvalidCardPositionException{
        Player currentPlayer = this.getCurrentPlayer();
        if (card.getId()>40 && card.getId()<81){
            currentPlayer.playPlayCard((GoldCard) card,coordinates);
        } else if (card.getId() < 41){
            currentPlayer.playPlayCard((ResourceCard) card,coordinates);
        }

        if (currentPlayer.getScore()>= MAX_SCORE && !this.getGame().getCompletingRound()){
            this.getGame().setCompletingRound(true);
        }

        if(this.getGame().bothDecksFinished() && !this.getGame().getCompletingRound()){
            this.getGame().setCompletingRound(true);
        }
        updateState();
    }

    /**
     * Receives the deck to draw from and calls the drawCard method of the current player
     * @param deck the deck from which to draw
     * @throws MoreThanThreeCardsException if the player already has three cards in their personal deck
     * @throws DeckFinishedException if the deck is empty
     */
    public void drawCard(ResourceDeck deck)throws MoreThanThreeCardsException, DeckFinishedException {
        this.getCurrentPlayer().drawCard(deck);
        this.nextPlayer();
        if(this.getCurrentPlayer().getIsFirst() && this.getGame().getCompletingRound()){
            this.getGame().setCompletingRound(false);
            this.startLastTurn();
        }
        this.updateState();
    }

    /**
     * Draws a card from the given deck and adds it to the current player's hand.
     * @param deck the deck from which to draw.
     * @throws MoreThanThreeCardsException if the player already has three cards in their hand.
     * @throws DeckFinishedException if the deck is empty.
     */
    public void drawCard(GoldDeck deck) throws MoreThanThreeCardsException, DeckFinishedException{
        this.getCurrentPlayer().drawCard(deck);
        this.nextPlayer();
        if(this.getCurrentPlayer().getIsFirst() && this.getGame().getCompletingRound()){
            this.getGame().setCompletingRound(false);
            this.startLastTurn();
        }
        this.updateState();
    }

    /**
     * Draws a face-up card from the board and adds it to the current player's hand.
     * @param index the index of the face-up card to draw.
     * @throws MoreThanThreeCardsException if the player already has three cards in their hand.
     * @throws BothDeckFinishedException if both decks are empty.
     * @throws NoCardException if there is no card at the given index.
     */
    public void drawCard(Integer index) throws MoreThanThreeCardsException, BothDeckFinishedException, NoCardException {
        try {
            this.getGame().drawFaceUpCard(index);
        } catch (NoCardException e) {
            //modify the view to show the right error message (e.printStackTrace();)
        }

        this.nextPlayer();
        if(this.getCurrentPlayer().getIsFirst() && this.getGame().getCompletingRound()){
            this.startLastTurn();
        }
        this.updateState();
    }

    /**
     * Restituisce il numero di giocatori attualmente nel gioco.
     *
     * @return Il numero di giocatori nel gioco.
     */
    public int getPlayersSize() {
        return this.getGame().getPlayers().size();
    }

    /**
     * Restituisce il numero massimo di giocatori permessi nel gioco.
     *
     * @return Il numero massimo di giocatori.
     */
    public int getNumPlayers() {
        return this.getGame().getNumPlayers();
    }

    /**
     * Restituisce la lista dei colori delle pedine disponibili.
     *
     * @return Un ArrayList di PawnColor che rappresenta i colori delle pedine disponibili.
     */
    public ArrayList<PawnColor> getAvailableColors() {
        return this.getGame().getAvailableColors();
    }

}