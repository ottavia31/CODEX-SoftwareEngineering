package it.polimi.ingsw.network.DoneMessages;
import it.polimi.ingsw.controller.State;

/**
 * Represents an error message in the application, extending from the DoneMessage class.
 * This class encapsulates information about success status and possible errors.
 */
public class ErrorMessage extends DoneMessage {
    private final String success;
    private final String possibleErrors;

    /**
     * Constructs an ErrorMessage object with the specified parameters.
     *
     * @param state           the state associated with the message
     * @param type            the type of confirmation action
     * @param success         the success message or status
     * @param possibleErrors  the possible errors message (can be null if no errors)
     */
    public ErrorMessage(State state, ConfirmAction type, String success, String possibleErrors) {
        super(type, state);
        this.success = success;
        this.possibleErrors = possibleErrors;
    }

    /**
     * Retrieves the possible errors message.
     *
     * @return the possible errors message, or null if no errors were reported
     */
    public String getPossibleErrors() {
        return possibleErrors;
    }
}

