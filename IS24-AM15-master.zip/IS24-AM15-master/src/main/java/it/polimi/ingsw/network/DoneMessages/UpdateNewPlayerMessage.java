package it.polimi.ingsw.network.DoneMessages;

import it.polimi.ingsw.controller.State;

import java.io.Serializable;

/**
 * Represents a message indicating the addition of a new player.
 * Extends {@link DoneMessage}, specifying the nickname of the new player and its associated state.
 */
public class UpdateNewPlayerMessage extends DoneMessage implements Serializable {

    private final String nickname;

    /**
     * Constructs a new UpdateNewPlayerMessage with the specified game state and nickname of the new player.
     *
     * @param state the state associated with the addition of the new player.
     * @param nickname the nickname of the new player.
     */
    public UpdateNewPlayerMessage(State state, String nickname) {
        super(ConfirmAction.ADD_PLAYER_CONFIRM, state);
        this.nickname = nickname;
    }

    /**
     * Retrieves the nickname of the new player.
     *
     * @return the nickname of the new player.
     */
    public String getNickname() {
        return nickname;
    }
}

