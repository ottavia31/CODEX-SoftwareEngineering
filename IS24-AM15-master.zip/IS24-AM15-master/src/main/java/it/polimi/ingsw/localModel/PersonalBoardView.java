package it.polimi.ingsw.localModel;

import it.polimi.ingsw.model.Coordinates;
import it.polimi.ingsw.model.PawnColor;
import it.polimi.ingsw.model.Symbol;

import java.util.HashMap;

/**
 * Represents the view of a player's personal board, including the map of cards, resources, and score.
 */
public class PersonalBoardView {
    private HashMap<Coordinates, CardView> map;
    private HashMap<Symbol, Integer> resources;
    private int score;
    private String pawn;

    /**
     * Constructor for the PersonalBoardView class. Initializes the data structures.
     */
    public PersonalBoardView() {
        this.map = new HashMap<>();
        this.resources = new HashMap<>();
    }

    /**
     * Sets the pawn color for a player.
     *
     * @param color The color of the pawn.
     */
    public void setPawn(PawnColor color) {
        this.pawn = color.toString();
    }
    public String getPawn() {
        return pawn;
    }

    /**
     * Sets the score of the player.
     *
     * @param score The new score of the player.
     */
    public void setScore(int score) {
        this.score = score;
    }

    /**
     * Retrieves the score of the player.
     *
     * @return The score of the player.
     */
    public int getScore() {
        return score;
    }

    /**
     * Retrieves the card at the specified position on the board.
     *
     * @param x The X coordinate of the card.
     * @param y The Y coordinate of the card.
     * @return The card at the specified position, or null if it doesn't exist.
     */
    public CardView getCard(int x, int y) {
        return map.get(new Coordinates(x, y));
    }

    /**
     * Updates the personal board with a new card at the specified position.
     *
     * @param coordinates The coordinates of the card.
     * @param id The ID of the card.
     * @param isBack Whether the card is face down.
     */
    public void updatePersonalBoard(Coordinates coordinates, int id, Boolean isBack) {
        CardView card = new CardView(id);
        card.setIsBack(isBack);
        map.put(coordinates, card);
        coverAdjacentCorners(coordinates);
    }

    /**
     * Covers the adjacent corners to the card at the specified coordinates.
     *
     * @param coordinates The coordinates of the card.
     */
    private void coverAdjacentCorners(Coordinates coordinates) {
        Coordinates UL = new Coordinates(coordinates.getX() - 1, coordinates.getY() + 1);
        Coordinates UR = new Coordinates(coordinates.getX() + 1, coordinates.getY() + 1);
        Coordinates DL = new Coordinates(coordinates.getX() - 1, coordinates.getY() - 1);
        Coordinates DR = new Coordinates(coordinates.getX() + 1, coordinates.getY() - 1);

        if (map.containsKey(UL))
            map.get(UL).updateCoverCorner("DR");
        if (map.containsKey(UR))
            map.get(UR).updateCoverCorner("DL");
        if (map.containsKey(DL))
            map.get(DL).updateCoverCorner("UR");
        if (map.containsKey(DR))
            map.get(DR).updateCoverCorner("UL");
    }

    /**
     * Retrieves the resource map with their respective symbols and quantities.
     *
     * @return A HashMap of resources.
     */
    public HashMap<Symbol, Integer> getResources() {
        return resources;
    }

    /**
     * Retrieves the card map with their respective coordinates.
     *
     * @return A HashMap of cards.
     */
    public HashMap<Coordinates, CardView> getMap() {
        return map;
    }
}
