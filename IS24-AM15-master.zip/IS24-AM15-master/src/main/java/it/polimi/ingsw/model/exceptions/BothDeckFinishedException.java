package it.polimi.ingsw.model.exceptions;

/**
 * This class represents an exception that is thrown when both decks in the game are finished.
 */
public class BothDeckFinishedException extends Exception {

    /**
     * Constructs a new exception with the specified detail message.
     *
     * @param msg the detail message. The detail message is saved for later retrieval by the Throwable.getMessage() method.
     */
    public BothDeckFinishedException(String msg) {
        super(msg);
    }
}