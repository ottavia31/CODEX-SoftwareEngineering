package it.polimi.ingsw.localModel;

import java.util.ArrayList;

/**
 * Represents the view of a player, including their cards in play, score, goals, and personal board view.
 */
public class PlayerView {
    private Boolean isFirst;
    private final ArrayList<Integer> playCards;
    private int secretGoalCard;
    private int score;
    private final ArrayList<Integer> goalCards;
    private final PersonalBoardView personalBoardView;

    /**
     * Constructor for the PlayerView class. Initializes the data structures.
     */
    public PlayerView() {
        this.playCards = new ArrayList<>();
        this.secretGoalCard = 0;
        this.goalCards = new ArrayList<>();
        this.score = 0;
        this.personalBoardView = new PersonalBoardView();
        this.isFirst = false;
    }

    /**
     * Updates the player's score.
     *
     * @param score The new score of the player.
     */
    public void updateScore(int score) {
        this.score = score;
    }

    /**
     * Returns whether the player is the first player.
     *
     * @return True if the player is the first player, otherwise false.
     */
    public Boolean getFirst() {
        return isFirst;
    }

    /**
     * Sets whether the player is the first player.
     *
     * @param first True to set the player as the first player, otherwise false.
     */
    public void setFirst(Boolean first) {
        isFirst = first;
    }

    /**
     * Returns the list of cards in play for the player.
     *
     * @return An ArrayList of card IDs in play.
     */
    public ArrayList<Integer> getPlayCards() {
        return playCards;
    }

    /**
     * Adds a card in play to the player.
     *
     * @param id The ID of the card to add.
     */
    public void addPlayCard(int id) {
        playCards.add(id);
    }

    /**
     * Returns the ID of the player's secret goal card.
     *
     * @return The ID of the secret goal card.
     */
    public int getSecretGoalCard() {
        return secretGoalCard;
    }

    /**
     * Sets the ID of the player's secret goal card.
     *
     * @param secretGoalCard The ID of the new secret goal card.
     */
    public void setSecretGoalCard(int secretGoalCard) {
        this.secretGoalCard = secretGoalCard;
    }

    /**
     * Adds a goal card to the player.
     * If the player already has two goal cards, the new card becomes the secret goal card.
     *
     * @param goalCard The ID of the goal card to add.
     */
    public void setGoalCard(int goalCard) {
        if (goalCards.size() < 2) {
            this.goalCards.add(goalCard);
        } else {
            int secretGoalCard = goalCards.get(goalCard - 1);
            this.setSecretGoalCard(secretGoalCard);
        }
    }

    /**
     * Returns the list of goal cards for the player.
     *
     * @return An ArrayList of goal card IDs.
     */
    public ArrayList<Integer> getGoalCards() {
        return this.goalCards;
    }

    /**
     * Removes a card in play from the player.
     *
     * @param card The ID of the card to remove.
     */
    public void removeCard(int card) {
        this.playCards.remove(card - 1);
    }

    /**
     * Returns the personal board view of the player.
     *
     * @return The PersonalBoardView object of the player.
     */
    public PersonalBoardView getPersonalBoardView() {
        return personalBoardView;
    }
}
