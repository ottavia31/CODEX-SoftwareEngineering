package it.polimi.ingsw.network.DoneMessages;


import it.polimi.ingsw.controller.State;

/**
 * Represents a message indicating an update to the secret goal card.
 * Extends {@link DoneMessage}, specifying the updated secret goal card and its state.
 */
public class UpdateGoalCardMessage extends DoneMessage {

    private final int card;

    /**
     * Constructs a new UpdateGoalCardMessage with the specified game state and secret goal card.
     *
     * @param state the state associated with the update.
     * @param card  the updated secret goal card.
     */
    public UpdateGoalCardMessage(State state, int card) {
        super(ConfirmAction.SECRET_GOAL_CARD, state);
        this.card = card;
    }

    /**
     * Retrieves the updated secret goal card.
     *
     * @return the updated secret goal card.
     */
    public int getCard() {
        return this.card;
    }
}
