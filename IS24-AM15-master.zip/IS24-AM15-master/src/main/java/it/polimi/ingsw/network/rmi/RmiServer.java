package it.polimi.ingsw.network.rmi;

import it.polimi.ingsw.controller.Controller;
import it.polimi.ingsw.controller.LobbyController;
import it.polimi.ingsw.controller.State;
import it.polimi.ingsw.model.Coordinates;
import it.polimi.ingsw.model.PawnColor;
import it.polimi.ingsw.model.Player;
import it.polimi.ingsw.model.Symbol;
import it.polimi.ingsw.model.cards.PlayCard;
import it.polimi.ingsw.model.exceptions.*;
import it.polimi.ingsw.network.Client;
import it.polimi.ingsw.network.DoneMessages.*;
import it.polimi.ingsw.network.VirtualServer;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Iterator;

public class RmiServer implements VirtualServer {
    private final Controller controller;
    private final LobbyController lobbyController;
    private final ArrayList <Client> clients = new ArrayList<>();

    public RmiServer(Controller controller, LobbyController lobbyController) {
        this.controller = controller;
        this.lobbyController = lobbyController;
    }

    //TODO aggiungere remote exception
    @Override
    public void updateAllClients(DoneMessage message) throws RemoteException {
        try {
            for (Client client : clients) {
                client.addMessage(message);
            }
        } catch (RemoteException e) {
            System.out.println("Connection lost with client, closing...");
            System.exit(0);
        }
    }

    public void updateClient(String nickname, DoneMessage message) throws RemoteException {
        try {
            for (Client client : clients) {
                if (client.getNickname().equals(nickname)) { //da ottimizzare
                    client.addMessage(message);
                }
            }

        }catch(RemoteException e){
            System.out.println("Connection lost with client, closing...");
            System.exit(0);
        }
    }

    @Override
    public void connect(Client client) throws RemoteException {
        System.err.println("New client connected");
        synchronized (this.clients) {
            this.clients.add(client);
        }
        for (Client c : clients) {
           c.setCurrentPlayer("newPlayer");
        }
        //client.setNickname("other player");
    }

    @Override
    public void setNickname(String nickname) throws RemoteException {
        DoneMessage answer;
        try {
            lobbyController.addPlayer(nickname);
            answer = new UpdateNewPlayerMessage(getState(), nickname);
            updateAllClients(answer);
            System.out.println("Player added: " + nickname);
            if (this.controller.getPlayersSize() == this.controller.getNumPlayers()){
                this.setupGame();
            }
        } catch (IllegalArgumentException e) {
            DoneMessage ans;
            ans = new ErrorMessage(getState(), ConfirmAction.ADD_PLAYER_ERROR, null,"Nickname already chosen");
            System.out.println("Error setting nickname");
            updateAllClients(ans);
        } catch (IllegalStateException e) {
            ErrorMessage ans;
            ans  = new ErrorMessage(getState(), ConfirmAction.ADD_PLAYER_ERROR, null,"Game already started");
            updateAllClients(ans);
        }

    }

    @Override
    public void setNumPlayers(Integer num) throws RemoteException {
        //il numero di giocatori non ? nel modelView
        DoneMessage answer;
        try {
            lobbyController.setNumPlayers(num);
            answer = new UpdateNumPlayersMessage(getState(), num);
            System.out.println("Number of players setted to: " + num);
        } catch (IllegalArgumentException e) {
            System.out.println("Error setting number of players");
            answer = new ErrorMessage(getState(), ConfirmAction.NUM_PLAYER_ERROR, null,"Error setting number of players");
        }
        updateAllClients(answer);
    }

    public State getState() throws RemoteException {
        return controller.getState();
    }

   public ArrayList<PawnColor> getAvaiableColors() throws RemoteException{
        return this.controller.getAvailableColors();
   }
    @Override
    public void setPawn(PawnColor color, String nickname) throws RemoteException, IllegalArgumentException {
        try{
            lobbyController.setPawn(color, nickname);
            DoneMessage message = new UpdatePawnColorMessage(this.getState(), color, nickname);
            updateAllClients(message);
            DoneMessage stateandturnMessage = new UpdateStateAndTurnMessage(this.getState(), controller.getCurrentPlayerNickname());
            updateAllClients(stateandturnMessage);
            System.out.println("Pawn setted: " + color + " for player: " + nickname);
        }catch(IllegalArgumentException e){
           //TODO non lo manda
            DoneMessage error = new ErrorMessage(this.getState(), ConfirmAction.CHOOSE_PAWN_ERROR, "non va bene il colore", null);
        }
    }



    @Override
    public void setFirstPlayer() throws RemoteException {
        lobbyController.chooseFirstPlayer();
    }



    @Override
    public void playStarterCard(boolean isBack) throws RemoteException {
        Player currentPlayer = this.controller.getCurrentPlayer();
        lobbyController.playStarterCard(isBack);
        DoneMessage message = new UpdateStarterCardMessage(this.getState(), currentPlayer.getStarterCard().getId(), currentPlayer.getStarterCard().isBackSide(), currentPlayer.getNickname());
        updateAllClients(message);
        DoneMessage turnandstateMessage = new UpdateStateAndTurnMessage(this.getState(), this.controller.getCurrentPlayerNickname());
        updateAllClients(turnandstateMessage);
        System.out.println("Starter card played by: " + currentPlayer.getNickname());
    }


    @Override
    public void setupGame() throws RemoteException {
        try{
            this.lobbyController.setupGame();
        }catch(DeckFinishedException e){
            //mai fatta
        }
        System.out.println("Game Setted ");
        Symbol gold = Symbol.valueOf(controller.getGame().getGoldDeck().getTopCardColor().toString());
        Symbol resource = Symbol.valueOf(controller.getGame().getResourceDeck().getTopCardColor().toString());

        ArrayList<Integer> goals = new ArrayList<>();
        try {
            goals.add(controller.getGame().getGoalDeck().getTopCard().getId());
            goals.add(controller.getGame().getGoalDeck().getTopCard().getId());
        } catch (DeckFinishedException e) {
            //non dovrebbe mai succedere
        }

        ArrayList<Player> players = new ArrayList<>(controller.getPlayers());

        ArrayList<Integer> faceup = new ArrayList<>();
        for(int i = 0; i < 4; i++){
            faceup.add(controller.getGame().getFacedUpCards().get(i).getId());
        }

        Player currentPlayer = controller.getCurrentPlayer();
        ArrayList<String> allplayers = new ArrayList<>();
        for(Player player : this.controller.getPlayers()){
            allplayers.add(player.getNickname());
        }
        DoneMessage answer = new UpdateSetupGameMessage(getState(),currentPlayer.getNickname(), allplayers, gold, resource, faceup, goals);
        updateAllClients(answer);

        for(Player player: controller.getPlayers()){


            DoneMessage message1 = new UpdatePersonalDeckMessage(this.getState(), player.getPlayCards().get(0).getId());
            updateClient(player.getNickname(), message1);
            DoneMessage message2 = new UpdatePersonalDeckMessage(this.getState(), player.getPlayCards().get(1).getId());
            updateClient(player.getNickname(), message2);
            DoneMessage message3 = new UpdatePersonalDeckMessage(this.getState(), player.getPlayCards().get(2).getId());
            updateClient(player.getNickname(), message3);

            DoneMessage message4 = new UpdateGoalCardMessage(this.getState(), player.getInitialGoalCards().get(0).getId());
            updateClient(player.getNickname(), message4);
            DoneMessage message5 = new UpdateGoalCardMessage(this.getState(), player.getInitialGoalCards().get(1).getId());
            updateClient(player.getNickname(), message5);

            DoneMessage message6 = new UpdateStarterCardMessage(this.getState(), player.getStarterCard().getId(), player.getStarterCard().isBackSide(), player.getNickname());
            updateClient(player.getNickname(), message6);
        }

    }
    @Override
    public int getNumPlayers() throws RemoteException{
        return this.controller.getNumPlayers();
    }
    @Override
    public int getNumPlayersConnected() throws RemoteException{
        return this.clients.size();
    }

    @Override
    public ArrayList<String> getWinners() throws RemoteException {
        return this.controller.getWinners();
    }

    public void playPlayCard(int card, int x, int y, Boolean isBack, String player) throws RemoteException {
        PlayCard playCard = this.controller.getCurrentPlayer().getPlayCards().get(card-1);
        playCard.setBack(isBack);
        Coordinates coordinates = new Coordinates(x,y);
        DoneMessage answer;
        try {

            this.controller.playCard(playCard, coordinates);
            answer = new UpdatePersonalBoardMessage(this.controller.getState(), playCard.getId(), isBack, coordinates, this.controller.getCurrentPlayerNickname(), this.controller.getCurrentPlayer().getScore() );
            updateAllClients(answer);
            DoneMessage personaldeck = new UpdateCardRemoved(this.controller.getState(), card);
            DoneMessage stateandTurn = new UpdateStateAndTurnMessage(this.controller.getState(), this.controller.getCurrentPlayerNickname());
            updateAllClients(stateandTurn);
            updateClient(this.controller.getCurrentPlayerNickname(), personaldeck);
            System.out.println("Card played by: " + this.controller.getCurrentPlayerNickname());

        } catch(InvalidCardPositionException e) {
            answer = new ErrorMessage(this.controller.getState(), ConfirmAction.PLAY_CARD_ERROR,"not possible to insert the card", e.getMessage());
            updateClient(this.controller.getCurrentPlayerNickname(), answer);
        }
    }
    public void sendPrivateMessage(String sender, String receiver, String message) throws RemoteException {
        this.controller.addPrivateMessage(message, sender, receiver);
        DoneMessage privatemessage = new NewMessage(sender, message, this.controller.getGame().getState());
        updateClient(receiver, privatemessage);
    }


    public void sendPublicMessage(String sender, String message) throws RemoteException {
        this.controller.addPublicMessage(sender, message);
        DoneMessage publicmessage = new NewMessage(sender, message, this.controller.getGame().getState());
        updateAllClients(publicmessage);

    }

    public void showPublicChat(String player) throws RemoteException {
       DoneMessage showchat = new ShowChatMessage(this.controller.getState(), this.controller.getPublicChat().getMessages());
       updateClient(player, showchat);

    }

    public void showPrivateChat(String player1, String player2) throws RemoteException {
        DoneMessage showchat = new ShowChatMessage(this.controller.getState(), this.controller.getPrivateChats(player1, player2));
        updateClient(player2, showchat);
    }


    @Override
    public void chooseSecretGoal(Integer num, String nickname) throws RemoteException {
            lobbyController.setSecretGoalCard(num, nickname);
            DoneMessage message = new UpdateGoalCardMessage(getState(),num);
            updateClient(this.controller.getCurrentPlayerNickname(), message);
            controller.updateState();
            controller.nextPlayer();
            DoneMessage turnandstateMessage = new UpdateStateAndTurnMessage(getState(), this.controller.getCurrentPlayerNickname());
            updateAllClients(turnandstateMessage);
            System.out.println("Secret goal card chosen by: " + nickname);
    }

    public void drawResourceCard() throws RemoteException{
        Player oldPlayer = this.controller.getCurrentPlayer();
        String oldCurrentPlayer = this.controller.getCurrentPlayerNickname();
        try{
            this.controller.drawCard(this.controller.getGame().getResourceDeck());
        } catch (MoreThanThreeCardsException | DeckFinishedException e) {
            DoneMessage error = new ErrorMessage(this.controller.getState(),ConfirmAction.DRAW_CARD_ERROR,  "non puoi pescare qui", "riprova");
            updateClient(this.controller.getCurrentPlayerNickname(), error);
            return;
        }

        DoneMessage message1 = new UpdatePersonalDeckMessage(this.controller.getState(), oldPlayer.getPlayCards().get(2).getId());
        updateClient(oldCurrentPlayer, message1);
        DoneMessage message2 = new UpdateResourceDeckMessage(this.controller.getState(), this.controller.getGame().getResourceDeck().getTopCardColor());
        updateAllClients(message2);
        DoneMessage turnandstateMessage = new UpdateStateAndTurnMessage(getState(), this.controller.getCurrentPlayerNickname());
        updateAllClients(turnandstateMessage);
        System.out.println("Resource card drawn by: " + this.controller.getCurrentPlayerNickname());
    }
    public void drawGoldCard() throws RemoteException{
        String oldCurrentPlayer = this.controller.getCurrentPlayerNickname();
        Player oldPlayer = this.controller.getCurrentPlayer();
        try{
            this.controller.drawCard(this.controller.getGame().getGoldDeck());
        } catch (MoreThanThreeCardsException | DeckFinishedException e) {
            DoneMessage error = new ErrorMessage(this.controller.getState(),ConfirmAction.DRAW_CARD_ERROR,  "non puoi pescare qui", "riprova");
            updateClient(this.controller.getCurrentPlayerNickname(), error);
            return;
        }
        DoneMessage message1 = new UpdatePersonalDeckMessage(this.controller.getState(), oldPlayer.getPlayCards().get(2).getId());
        updateClient(oldCurrentPlayer, message1);
        DoneMessage message2 = new UpdateGoldDeckMessage(this.controller.getState(), this.controller.getGame().getGoldDeck().getTopCardColor());
        updateAllClients(message2);
        DoneMessage turnandstateMessage = new UpdateStateAndTurnMessage(getState(), this.controller.getCurrentPlayerNickname());
        updateAllClients(turnandstateMessage);
    }
    public void drawFacedUpCard(int i) throws RemoteException{
        Player oldPlayer = this.controller.getCurrentPlayer();
        String oldCurrentPlayer = this.controller.getCurrentPlayerNickname();
        try{
            this.controller.drawCard(i);
        }catch(MoreThanThreeCardsException | BothDeckFinishedException | NoCardException e){
            DoneMessage error = new ErrorMessage(this.controller.getState(),ConfirmAction.DRAW_CARD_ERROR,  "non puoi pescare qui", "riprova");
            updateClient(this.controller.getCurrentPlayerNickname(), error);
        }
        DoneMessage message1 = new UpdatePersonalDeckMessage(this.controller.getState(), oldPlayer.getPlayCards().get(2).getId());
        updateClient(oldCurrentPlayer, message1);
        DoneMessage message2 = new UpdateFacedupCardsMessage(this.controller.getState(), this.controller.getGame().getFacedUpCards().get(i).getId(), i);
        updateAllClients(message2);
        if( i ==0 || i==1){
            DoneMessage message3 = new UpdateResourceDeckMessage(this.controller.getState(), this.controller.getGame().getResourceDeck().getTopCardColor());
            updateAllClients(message3);
        }
        if(i == 2 || i==3){
            DoneMessage message4 = new UpdateGoldDeckMessage(this.controller.getState(), this.controller.getGame().getGoldDeck().getTopCardColor());
            updateAllClients(message4);
        }

        DoneMessage turnandstateMessage = new UpdateStateAndTurnMessage(getState(), this.controller.getCurrentPlayer().getNickname());
        updateAllClients(turnandstateMessage);
        System.out.println("Faced up card" + i + "drawn by: " + this.controller.getCurrentPlayerNickname());
    }

    @Override
    public void ping() throws RemoteException{

    }
    @Override
    public void sendPing() throws RemoteException {
        Integer i = 0;
        Iterator<Client> clientIterator = clients.iterator();
        while (clientIterator.hasNext()) {
            Client thisClient = clientIterator.next();
            try {
                thisClient.ping();
                i++;
            } catch (RemoteException e) {

                DoneMessage disconnectionMessage = new DisconnectionMessage(ConfirmAction.DISCONNECTION, controller.getState(), i);
                clientIterator.remove();
                try {
                    updateAllClients(disconnectionMessage);
                    System.exit(0);
                } catch (RemoteException ex) {
                    //Da gestire
                }
            }
        }
    }
    @Override
    public void run() throws RemoteException {
        System.out.println("Server ready");
        //ping
        Iterator<Client> iterator = clients.iterator();

        new Thread (() -> {
            while (true) {
                try {
                    sendPing();
                } catch (RemoteException e) {
                    System.out.println("Error in establishing a connection, closing...");
                }
                try {
                    Thread.sleep(10000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

}
