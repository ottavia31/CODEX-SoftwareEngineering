package it.polimi.ingsw.network.DoneMessages;

import it.polimi.ingsw.controller.State;
/**
 * Represents a message sent from one player to another.
 * Extends {@link DoneMessage}, adding fields for sender and message content.
 */
public class NewMessage extends DoneMessage {

    private final String sender;
    private final String message;

    /**
     * Constructs a new NewMessage with the specified sender, message content, and game state.
     *
     * @param sender the sender of the message.
     * @param message the content of the message.
     * @param state the updated game state after sending the message.
     */
    public NewMessage(String sender, String message, State state) {
        super(ConfirmAction.MESSAGE, state);
        this.sender = sender;
        this.message = message;
    }

    /**
     * Retrieves the sender of the message.
     *
     * @return the sender of the message.
     */
    public String getSender() {
        return this.sender;
    }

    /**
     * Retrieves the content of the message.
     *
     * @return the content of the message.
     */
    public String getMessage() {
        return this.message;
    }
}