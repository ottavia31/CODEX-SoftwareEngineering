package it.polimi.ingsw.model;
/**
 * This enum represents the various symbols that can be present in the game.
 * Each symbol corresponds to a specific color or item in the game.
 */
public enum Symbol implements java.io.Serializable{
    /**
     * Represents the color red.
     */
    RED,

    /**
     * Represents the color green.
     */
    GREEN,

    /**
     * Represents the color blue.
     */
    BLUE,

    /**
     * Represents the color purple.
     */
    PURPLE,

    /**
     * Represents the parchment item.
     */
    PARCHMENT,

    /**
     * Represents the potion item.
     */
    POTION,

    /**
     * Represents the feather item.
     */
    FEATHER,

    /**
     * Represents the corner item.
     */
    CORNER,

    /**
     * Represents an empty space or no item.
     */
    EMPTY;

    /**
     * Returns a string representation of this enum constant.
     * The string returned is the name of the enum constant in uppercase letters.
     *
     * @return A string representation of this enum constant.
     */
    public String toString(){
        return switch (this) {
            case RED -> "RED";
            case GREEN -> "GREEN";
            case BLUE -> "BLUE";
            case PURPLE -> "PURPLE";
            case PARCHMENT -> "PARCHMENT";
            case POTION -> "POTION";
            case FEATHER -> "FEATHER";
            case CORNER -> "CORNER";
            case EMPTY -> "EMPTY";
        };

    }
}