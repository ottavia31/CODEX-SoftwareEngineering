package it.polimi.ingsw.model.exceptions;

/**
 * This class represents an exception that is thrown when an operation is attempted on a deck that has no more cards.
 */
public class DeckFinishedException extends Exception{

    /**
     * Constructs a new DeckFinishedException with a specified detail message.
     *
     * @param msg the detail message, saved for later retrieval by the Throwable.getMessage() method.
     */
    public DeckFinishedException(String msg){
        super (msg);
    }
}