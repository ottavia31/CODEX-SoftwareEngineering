package it.polimi.ingsw.controller;
import it.polimi.ingsw.model.*;
import it.polimi.ingsw.model.exceptions.DeckFinishedException;

import java.util.ArrayList;
/**
 * This class is the controller for the lobby.
 * It manages the players joining the game and the setup of the game.
 * It coordinates interactions between the view and the lobby.
 */
public class LobbyController {
    private final Controller controller;
    private final Lobby lobby;
    private GameBoard gameBoard;

    /**
     * Constructor for the LobbyController class.
     * It creates a new LobbyController instance with the specified controller and a new lobby.
     * @param controller the controller of the game
     */
    public LobbyController(Controller controller){
        this.controller = controller;
        this.lobby = new Lobby(controller.getGame());
        this.gameBoard= controller.getGame();
    }

    /**
     * Sets the number of players in the game
     * @param numPlayers the number of players choosen by the user
     * @throws IllegalArgumentException if the number of players is not between 2 and 4
     */
    public void setNumPlayers(int numPlayers) throws IllegalArgumentException {
        if (numPlayers < 2 || numPlayers > 4){
            throw new IllegalArgumentException("Number of players must be between 2 and 4");
        }
        this.gameBoard.setNumPlayers(numPlayers);
        this.controller.updateState();
    }

    /**
     * Adds a player to the game
     * If the maximum number of players has been reached, the game is set up
     * @param nickname the nickname of the player
     * @throws IllegalArgumentException if the nickname is already taken
     * @throws IllegalStateException if the maximum number of players has been reached
     */
    public void addPlayer(String nickname) throws IllegalArgumentException {
        //check if the maximum number of players has been reached
        if (this.gameBoard.getPlayers().size() == this.controller.getGame().getNumPlayers()){

            throw new IllegalStateException("Maximum number of players reached");
        }
        //check if the nickname is already taken
        for (Player player : this.gameBoard.getPlayers()){
            if (player.getNickname().equals(nickname)){
                this.controller.updateState();
                throw new IllegalArgumentException("Nickname already chosen");
            }
        }
        Player player = new Player(nickname);
        this.lobby.addPlayer(player);
        this.controller.updateState();
        }


    /**
     * Sets up the game
     * It shuffles the cards, sets the faced up cards, the common goals and deals the play cards
     * @throws DeckFinishedException if the decks have not been initialized correctly (if the decks are empty)
     */
    public void setupGame() throws DeckFinishedException {
        this.gameBoard.setCurrentPlayer(this.gameBoard.getPlayers().get(0));
        this.lobby.shuffleCards();
        this.lobby.setFacedUpCards();
        this.lobby.setCommonGoals();

        // Deal the cards to the players
        lobby.dealPlayCards();
        lobby.dealStarterCard();
        lobby.setGoalCards();

        this.controller.updateState();
        this.controller.updateState();
    }

    /**
     * Creates a new personal board for the player
     * It sets the starter card of the player as faced up or faced down
     * @param isBack true if the starter card is faced down, false otherwise
     */
    public void playStarterCard(Boolean isBack){
        Player p = this.gameBoard.getCurrentPlayer();
        p.getStarterCard().setBackSide(isBack);
        p.setPersonalBoard(new PersonalBoard(p.getStarterCard(), isBack));
        this.controller.updateState();
        this.controller.nextPlayer();
    }

    /**
     * Sets the secret goal card that the player has chosen between the two available
     * @param numCard the number of the secret goal card chosen, either 1 or 2
     * @param nickname the nickname of the player choosing the card
     * @throws IllegalArgumentException if the input is not 1 or 2
     */
    public void setSecretGoalCard(int numCard, String nickname) throws IllegalArgumentException{
        if (numCard < 1 || numCard > 2) {
            throw new IllegalArgumentException("Input must be either 1 or 2");
        }
        for (Player player : this.gameBoard.getPlayers()){
            if (player.getNickname().equals(nickname)){
                player.setSecretGoalCard(numCard);
            }
        }
    }

    /**
     * Chooses the first player to play.
     * The first player is the first one to connect to the game
     */
    public void chooseFirstPlayer(){
        ArrayList<Player> players = this.gameBoard.getPlayers();
        this.gameBoard.setCurrentPlayer(players.get(0));
        players.get(0).setIsFirst(true);
        this.gameBoard.setFirstPlayer(players.get(0));
    }

    /**
     * Sets the pawn color for the player
     * @param color the color of the pawn chosen by the player
     * @param nickname the nickname of the player
     * @throws IllegalArgumentException if the color has already been chosen
     */
    public void setPawn(PawnColor color, String nickname) throws IllegalArgumentException {
        ArrayList<PawnColor> availableColors = this.gameBoard.getAvailableColors();
        for (Player player : this.gameBoard.getPlayers()) {
            if (player.getNickname().equals(nickname)) {
                if(!availableColors.contains(color))
                    throw new IllegalArgumentException("Color already chosen");
                availableColors.remove(color);
                player.setPawnColor(color);

                this.controller.updateState();
                this.controller.nextPlayer();
            }
        }
    }
}