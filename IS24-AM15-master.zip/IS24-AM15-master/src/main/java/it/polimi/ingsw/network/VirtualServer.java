package it.polimi.ingsw.network;

import it.polimi.ingsw.controller.State;
import it.polimi.ingsw.model.PawnColor;
import it.polimi.ingsw.network.DoneMessages.DoneMessage;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;

/**
 * The VirtualServer interface defines the remote methods that can be invoked
 * by clients in a networked game application. It extends the Remote interface,
 * which makes it suitable for use in Java RMI (Remote Method Invocation).
 */
public interface VirtualServer extends Remote {

    /**
     * Sends a message to all connected clients.
     *
     * @param message The message to send.
     * @throws RemoteException If a remote communication error occurs.
     */
    void updateAllClients(DoneMessage message) throws RemoteException;

    /**
     * Connects a new client to the server.
     *
     * @param client The client to connect.
     * @throws RemoteException If a remote communication error occurs.
     */
    void connect(Client client) throws RemoteException;

    /**
     * Sets the nickname for the current player.
     *
     * @param nickname The nickname to set.
     * @throws RemoteException If a remote communication error occurs.
     */
    void setNickname(String nickname) throws RemoteException;

    /**
     * Sets the number of players in the game.
     *
     * @param num The number of players.
     * @throws RemoteException If a remote communication error occurs.
     */
    void setNumPlayers(Integer num) throws RemoteException;

    /**
     * Gets the current state of the game.
     *
     * @return The current state.
     * @throws RemoteException If a remote communication error occurs.
     */
    State getState() throws RemoteException;

    /**
     * Sets the pawn color for a player.
     *
     * @param color The pawn color.
     * @param nickname The player's nickname.
     * @throws RemoteException If a remote communication error occurs.
     * @throws IllegalArgumentException If the pawn color is invalid.
     */
    void setPawn(PawnColor color, String nickname) throws RemoteException, IllegalArgumentException;

    /**
     * Sets the first player in the game.
     *
     * @throws RemoteException If a remote communication error occurs.
     */
    void setFirstPlayer() throws RemoteException;

    /**
     * Chooses a secret goal card for a player.
     *
     * @param idSecretGoal The ID of the secret goal card.
     * @param nickname The player's nickname.
     * @throws RemoteException If a remote communication error occurs.
     * @throws IllegalArgumentException If the secret goal card ID is invalid.
     */
    void chooseSecretGoal(Integer idSecretGoal, String nickname) throws RemoteException, IllegalArgumentException;

    /**
     * Plays a starter card for the current player.
     *
     * @param isBack Whether the card is played on its back side.
     * @throws RemoteException If a remote communication error occurs.
     */
    void playStarterCard(boolean isBack) throws RemoteException;

    /**
     * Sets up the game.
     *
     * @throws RemoteException If a remote communication error occurs.
     */
    void setupGame() throws RemoteException;

    /**
     * Plays a card at the specified coordinates for a player.
     *
     * @param i1 The first coordinate.
     * @param i2 The second coordinate.
     * @param i3 The third coordinate.
     * @param isBack Whether the card is played on its back side.
     * @param nickname The player's nickname.
     * @throws RemoteException If a remote communication error occurs.
     */
    void playPlayCard(int i1, int i2, int i3, Boolean isBack, String nickname) throws RemoteException;

    /**
     * Draws a gold card for the current player.
     *
     * @throws RemoteException If a remote communication error occurs.
     */
    void drawGoldCard() throws RemoteException;

    /**
     * Draws a resource card for the current player.
     *
     * @throws RemoteException If a remote communication error occurs.
     */
    void drawResourceCard() throws RemoteException;

    /**
     * Draws a faced-up card for the current player.
     *
     * @param i The index of the faced-up card.
     * @throws RemoteException If a remote communication error occurs.
     */
    void drawFacedUpCard(int i) throws RemoteException;

    /**
     * Pings the server to check the connection.
     *
     * @throws RemoteException If a remote communication error occurs.
     */
    void ping() throws RemoteException;

    /**
     * Gets the number of players in the game.
     *
     * @return The number of players.
     * @throws RemoteException If a remote communication error occurs.
     */
    int getNumPlayers() throws RemoteException;

    /**
     * Sends a private message from one player to another.
     *
     * @param sender The sender's nickname.
     * @param receiver The receiver's nickname.
     * @param message The message to send.
     * @throws RemoteException If a remote communication error occurs.
     */
    void sendPrivateMessage(String sender, String receiver, String message) throws RemoteException;

    /**
     * Sends a public message to all players.
     *
     * @param sender The sender's nickname.
     * @param message The message to send.
     * @throws RemoteException If a remote communication error occurs.
     */
    void sendPublicMessage(String sender, String message) throws RemoteException;

    /**
     * Gets the number of connected clients.
     *
     * @return The number of connected clients.
     * @throws RemoteException If a remote communication error occurs.
     */
    int getNumPlayersConnected() throws RemoteException;

    /**
     * Gets the list of winners of the game.
     *
     * @return A list of winners.
     * @throws RemoteException If a remote communication error occurs.
     */
    ArrayList<String> getWinners() throws RemoteException;

    /**
     * Sends a ping to all connected clients to check the connection status.
     *
     * @throws RemoteException If a remote communication error occurs.
     */
    void sendPing() throws RemoteException;

    /**
     * Runs the server, starting the connection check loop.
     *
     * @throws RemoteException If a remote communication error occurs.
     */
    void run() throws RemoteException;

    /**
     * Shows the public chat to a specific player.
     *
     * @param player The player's nickname.
     * @throws RemoteException If a remote communication error occurs.
     */
    void showPublicChat(String player) throws RemoteException;

    /**
     * Shows the private chat between two players.
     *
     * @param player1 The first player's nickname.
     * @param player2 The second player's nickname.
     * @throws RemoteException If a remote communication error occurs.
     */
    void showPrivateChat(String player1, String player2) throws RemoteException;

    /**
     * Retrieves the list of available pawn colors.
     *
     * @return An ArrayList of available PawnColor objects.
     * @throws RemoteException If a remote communication error occurs.
     */
    ArrayList<PawnColor> getAvaiableColors() throws RemoteException;
}
