package it.polimi.ingsw.model.cards;

import it.polimi.ingsw.model.Symbol;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Map;
/**
 * This class represents a StarterCard in the game.
 * Each StarterCard has front and back corners, front symbols, an id, and a flag indicating if it's back side is up.
 */
public class StarterCard extends Card implements Serializable{
    private final Map<String, Symbol> FrontCorners;
    private final Map<String, Symbol> BackCorners;
    private final ArrayList<Symbol> frontSymbols;
    private boolean isBackSide;
    private final int id;
    /**
     * Constructs a new StarterCard with the given id, front corners, back corners, and front symbols.
     * Initially, the card is not on its back side.
     */
    public StarterCard(int id, Map<String, Symbol> frontCorners, Map<String, Symbol> backCorners, ArrayList<Symbol> frontSymbols){
        FrontCorners = frontCorners;
        BackCorners = backCorners;
        this.frontSymbols = frontSymbols;
        this.isBackSide = false;
        this.id = id;
    }
    /**
     * Flips the card. If the card was on its back side, it is now on its front side, and vice versa.
     */
    public void flip() {
        this.isBackSide = !this.isBackSide;
    }
    /**
     * Returns the corners of the card. If the card is on its back side, it returns the back corners.
     * Otherwise, it returns the front corners.
     */
    @Override
    public Map<String, Symbol> getCorners() {
        if (isBackSide) {
            return BackCorners;
        } else {
            return FrontCorners;
        }
    }
    /**
     * Returns the color of the card. This method is not applicable for StarterCard and always returns null.
     * @return null
     */
    @Override
    public Symbol getColor(){
        return null;
    }
    /**
     * Returns the boolean of back side.
     * @return whether the card is back side or not
     */
    @Override
    public boolean isBackSide() {
        return isBackSide;
    }

    /**
     * Returns the symbols on the front of the card.
     * @return an ArrayList of symbols on the front of the card
     */
    public ArrayList<Symbol> getFrontSymbols() {
        return frontSymbols;
    }
    /**
     * Returns the id of the card.
     * @return the id of the card
     */
    @Override
    public int getId() {
        return this.id;
    }

    /**
     * Set the back side status of the card.
     * @param isBack the front corners of the card
     */
    public void setBackSide(Boolean isBack) {
        this.isBackSide = isBack;
    }
}

