package it.polimi.ingsw.network.DoneMessages;

import it.polimi.ingsw.controller.State;

import java.io.Serializable;


/**
 * Represents a message confirming an action with associated game state.
 * Instances of this class are used to communicate confirmations from the server
 * to the client, providing information about the type of action confirmed
 * and the updated game state after the action.
 */
public class DoneMessage implements Serializable {

    private final ConfirmAction type;
    private State state;

    /**
     * Constructs a new DoneMessage with the specified action type and game state.
     *
     * @param type the type of action confirmed.
     * @param state the updated game state after the action.
     */
    public DoneMessage(ConfirmAction type, State state) {
        this.type = type;
        this.state = state;
    }

    /**
     * Retrieves the type of action confirmed by this DoneMessage.
     *
     * @return the type of action confirmed.
     */
    public ConfirmAction getType() {
        return type;
    }

    /**
     * Retrieves the updated game state after the action confirmed by this DoneMessage.
     *
     * @return the updated game state after the action.
     */
    public State getState() {
        return state;
    }
}