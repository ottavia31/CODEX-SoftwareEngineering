package it.polimi.ingsw;

import it.polimi.ingsw.model.exceptions.DeckFinishedException;
import it.polimi.ingsw.network.rmi.RmiClient;
import it.polimi.ingsw.view.CLI.CLIView;
import it.polimi.ingsw.view.ViewController;

import java.io.IOException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import static java.lang.Integer.parseInt;
/**
 * Main class for the client application.
 * Configures and starts the RMI connection to the server.
 */
public class ClientApp {

    /**
     * Main method that starts the client application.
     * Configures the RMI hostname and starts the RMI client with the view controller.
     *
     * @param args Command line arguments: server port and hostname.
     * @throws IOException If an I/O error occurs.
     * @throws NotBoundException If the RMI object is not bound in the registry.
     * @throws InterruptedException If the thread is interrupted.
     * @throws DeckFinishedException If the deck of cards is finished.
     */
    public static void main(String[] args) throws IOException, NotBoundException, InterruptedException, DeckFinishedException {
        //192.168.118.22
        System.setProperty("java.rmi.server.hostname", "127.0.0.1");
        ViewController viewController = new CLIView();
        int port = parseInt(args[0]);
        String host = args[1];
        try {
            new RmiClient().start(host, port, viewController);
        } catch (RemoteException e) {
        e.printStackTrace();
        }
    }
}