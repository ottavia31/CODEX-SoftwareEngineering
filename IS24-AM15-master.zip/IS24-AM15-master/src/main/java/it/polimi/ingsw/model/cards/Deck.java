package it.polimi.ingsw.model.cards;
import it.polimi.ingsw.model.Symbol;
import it.polimi.ingsw.model.exceptions.DeckFinishedException;
/**
 * The Deck interface represents a deck of cards in the game.
 * It provides methods to get the top card of the deck and to shuffle the deck.
 */
public interface Deck {
    /**
     * Retrieves the top card from the deck.
     *
     * @return the top card from the deck
     * @throws DeckFinishedException if the deck is empty
     */
        Card getTopCard() throws DeckFinishedException;
    /**
     * Returns the color of the top card of the deck.
     *
     * @return the color of the top card of the deck
     */
    Symbol getTopCardColor();;
}
