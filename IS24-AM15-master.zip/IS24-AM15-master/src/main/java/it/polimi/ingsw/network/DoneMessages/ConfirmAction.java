package it.polimi.ingsw.network.DoneMessages;

/**
 * Enum representing various confirmation actions and states in the game.
 * Each enum constant corresponds to a specific confirmation or state update.
 */
public enum ConfirmAction {
    NUM_PLAYER_CONFIRM,
    NUM_PLAYER_ERROR,
    SECRET_GOAL_CARD,
    UPDATE_PERSONAL_DECK,
    PLAY_CARD_CONFIRM,
    PLAY_CARD_ERROR,
    GAME_STATE,
    ADD_PLAYER_CONFIRM,
    ADD_PLAYER_ERROR,
    CHOOSEN_PAWN,
    DRAW_CARD_ERROR,
    RESOURCE_DECK_UPDATE,
    GOLD_DECK_UPDATE,
    FACEDUP_CARDS_UPDATE,
    TURN_UPDATE,
    SETUP_GAME_CONFIRM, STARTER_CARD, CHOOSE_PAWN_ERROR,
    TURN_STATE_UPDATE, REMOVED_FROM_PERSONAL_DECK,
    DISCONNECTION, MESSAGE,
    SHOW_CHAT;
}
