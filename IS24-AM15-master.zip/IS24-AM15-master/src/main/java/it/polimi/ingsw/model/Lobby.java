package it.polimi.ingsw.model;

import it.polimi.ingsw.model.cards.GoalCard;
import it.polimi.ingsw.model.cards.GoldCard;
import it.polimi.ingsw.model.cards.ResourceCard;
import it.polimi.ingsw.model.cards.StarterCard;
import it.polimi.ingsw.model.exceptions.DeckFinishedException;

import java.util.ArrayList;
import java.util.Collections;
/**
 * This class represents the lobby in the game. It is responsible for managing the game board and the players.
 */
public class Lobby {
    private final GameBoard game;
    private final ArrayList<Player> allPlayers;
    /**
     * Constructs a new Lobby object.
     *
     * @param game the game board
     */
    public Lobby(GameBoard game) {
        this.game = game;
        this.allPlayers = new ArrayList<>();
    }

    /**
     * Adds a player to the game.
     *
     * @param player the player to be added
     */
    public void addPlayer(Player player){
        this.allPlayers.add(player);
        this.game.getPlayers().add(player);
        if(game.getPlayers().size() == 1){
            player.setIsFirst(true);
        }
        }

    /**
     * Shuffles the deck in the game.
     */
    public void shuffleCards() {

        // Mescola le carte
        Collections.shuffle(this.game.getResourceDeck().getCards());
        Collections.shuffle(this.game.getGoldDeck().getCards());
        Collections.shuffle(this.game.getStarterDeck().getCards());
        Collections.shuffle(this.game.getGoalDeck().getCards());

    }
    /**
     * Sets the common goals for the game.
     *
     * @throws DeckFinishedException if the deck is empty
     */
    public void setCommonGoals() throws DeckFinishedException {
        for (int i = 0; i < 2; i++) {
            GoalCard goalCard = game.getGoalDeck().getTopCard();
            this.game.getCommonGoals().add(goalCard);
        }
    }
    /**
     * Sets the faced up cards for the game.
     *
     * @throws DeckFinishedException if the deck is empty
     */
    public void setFacedUpCards () throws DeckFinishedException {
        for (int i = 0; i < 2; i++) {
            ResourceCard card = this.game.getResourceDeck().getTopCard();
            this.game.getFacedUpCards().add(card);
        }

        for (int i = 0; i < 2; i++) {
            GoldCard card = this.game.getGoldDeck().getTopCard();
            this.game.getFacedUpCards().add(card);
        }

    }
    /**
     * Deals the starter card to each player.
     *
     * @throws DeckFinishedException if the deck is empty
     */
    public void dealStarterCard () throws DeckFinishedException {
        for (Player player : game.getPlayers()) {
            StarterCard starterCard = game.getStarterDeck().getTopCard();
            player.setStarterCard(starterCard);
        }
    }
    /**
     * Deals the play cards to each player.
     *
     * @throws DeckFinishedException if the deck is empty
     */
    public void dealPlayCards () throws DeckFinishedException {
        for (Player player : allPlayers) {
            ResourceCard card1 = this.game.getResourceDeck().getTopCard();
            ResourceCard card2 = this.game.getResourceDeck().getTopCard();
            GoldCard card3 = this.game.getGoldDeck().getTopCard();
            player.setPlayCard(card1);
            player.setPlayCard(card2);
            player.setPlayCard(card3);
        }
    }
    /**
     * Sets the goal cards for each player.
     *
     * @throws DeckFinishedException if the deck is empty
     */
    public void setGoalCards () throws DeckFinishedException {
        for (Player player : allPlayers) {
            for (int j = 0; j < 2; j++) {
                GoalCard card = this.game.getGoalDeck().getTopCard();
                player.getInitialGoalCards().add(card);
            }
        }
    }


}