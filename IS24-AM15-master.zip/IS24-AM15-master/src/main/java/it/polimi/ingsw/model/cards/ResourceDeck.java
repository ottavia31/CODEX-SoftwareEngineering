package it.polimi.ingsw.model.cards;

import it.polimi.ingsw.model.Symbol;
import it.polimi.ingsw.model.exceptions.DeckFinishedException;

import java.util.ArrayList;
/**
 * This class represents a deck of resourceCards in the game.
 * It implements the Deck interface.
 */
public class ResourceDeck implements Deck {
    private final ArrayList<ResourceCard> cards;
    /**
     * Constructs a new ResourceDeck.
     * Initializes an empty list of ResourceCard objects.
     */
    public ResourceDeck() {
        super();
        this.cards = new ArrayList<>(); // Initialize the cards field
    }
    /**
     * Returns the ResourceCard with the specified id from the deck.
     * @param id the id of the ResourceCard to be returned
     * @return the ResourceCard with the specified id, or null if no such card exists in the deck
     */
    public ResourceCard getResourceCardById(int id) {
        for (ResourceCard card : cards) {
            if (card.getId() == id) {
                return card;
            }
        }
        return null;
    }

    /**
     * Returns the top card of the deck and removes it from the deck.
     * If the deck is empty, throws a DeckFinishedException.
     * @return the top card of the deck
     * @throws DeckFinishedException if the deck is empty
     */
    @Override
    public ResourceCard getTopCard() throws DeckFinishedException{
        if (cards.isEmpty() || cards.getLast() == null) {
            throw new DeckFinishedException("Deck is empty");
        }
        else {
            ResourceCard curr = cards.getLast();
            cards.remove(cards.size() - 1);
            return curr;
        }
    }
    /**
     * Returns the color of the top card of the deck.
     * @return the color of the top card of the deck
     */
    @Override
    public Symbol getTopCardColor() {
        return cards.getLast().getColor();
    }

    /**
     * Returns the list of cards in the deck.
     * @return the list of cards in the deck
     */
    public ArrayList<ResourceCard> getCards() {
        return cards;
    }
}
