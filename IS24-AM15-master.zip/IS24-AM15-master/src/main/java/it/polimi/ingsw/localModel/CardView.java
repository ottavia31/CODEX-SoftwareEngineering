package it.polimi.ingsw.localModel;

import java.util.ArrayList;

/**
 * Represents the view of a card in the game, including the card ID, covered corners, and whether it is face down.
 */
public class CardView {
    private final int id;
    private static ArrayList<String> coveredCorners;
    private boolean isBack;

    /**
     * Constructor for the CardView class. Initializes the card ID and other properties.
     *
     * @param id The ID of the card.
     */
    public CardView(int id) {
        this.id = id;
        coveredCorners = new ArrayList<>();
        this.isBack = false;
    }

    /**
     * Retrieves the ID of the card.
     *
     * @return The ID of the card.
     */
    public int getId() {
        return id;
    }

    /**
     * Checks if the card is face down.
     *
     * @return True if the card is face down, otherwise false.
     */
    public boolean isBack() {
        return isBack;
    }

    /**
     * Updates the covered corner of the card.
     *
     * @param corner The name of the covered corner.
     */
    public void updateCoverCorner(String corner) {
        coveredCorners.add(corner);
    }

    /**
     * Sets whether the card is face down.
     *
     * @param isBack True to set the card as face down, otherwise false.
     */
    public void setIsBack(Boolean isBack) {
        this.isBack = isBack;
    }
}

