package it.polimi.ingsw.model.cards;

import it.polimi.ingsw.model.Symbol;

import java.io.Serializable;
import java.util.Map;
/**
 * The ResourceCard class extends the PlayCard class.
 * It represents a resource card in the game.
 */
public class ResourceCard extends PlayCard implements Serializable {

    /**
     * Constructor for the ResourceCard class.
     * @param id The unique identifier of the card.
     * @param color The color of the card.
     * @param corners A map representing the symbols in the corners of the card.
     * @param points The points awarded by the card.
     */

    public ResourceCard(int id, Symbol color, Map<String, Symbol> corners, int points) {
        super(id, color, corners, points);
    }
    /**
     * Returns the id of the card.
     * @return the id of the card
     */
    @Override
    public int getId() {
        return super.getId();
    }
}

