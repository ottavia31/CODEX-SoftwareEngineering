package it.polimi.ingsw.network.DoneMessages;


import it.polimi.ingsw.controller.State;

/**
 * Represents a message indicating the update of the number of players in the game.
 * Extends {@link DoneMessage}, specifying the new number of players and its associated state.
 */
public class UpdateNumPlayersMessage extends DoneMessage {

    private final int numPlayers;

    /**
     * Constructs a new UpdateNumPlayersMessage with the specified game state and number of players.
     *
     * @param state the state associated with the update of the number of players.
     * @param numPlayers the new number of players in the game.
     */
    public UpdateNumPlayersMessage(State state, int numPlayers) {
        super(ConfirmAction.NUM_PLAYER_CONFIRM, state);
        this.numPlayers = numPlayers;
    }

    /**
     * Retrieves the new number of players in the game.
     *
     * @return the new number of players.
     */
    public int getNumPlayers() {
        return numPlayers;
    }
}
