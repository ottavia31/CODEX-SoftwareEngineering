package it.polimi.ingsw.model.cards;

import it.polimi.ingsw.model.Player;
import it.polimi.ingsw.model.Symbol;

import java.io.Serializable;
import java.util.ArrayList;
/**
 * This class represents a Symbols Goal Card in the game.
 * It extends the GoalCard class and contains an ArrayList of symbols and a boolean to check if it's a resource.
 */
public class SymbolsGoalCard extends GoalCard implements Serializable{
    private final ArrayList<Symbol> symbols;
    private boolean isResource; //true if there are 3 resources,false if there are 2
    /**
     * Constructs a SymbolsGoalCard with the specified id, points and symbols.
     * @param id the id of the card
     * @param points the points of the card
     * @param symbols the symbols of the card
     */
    public SymbolsGoalCard(int id, int points, ArrayList<Symbol> symbols) {
        super(id, points);
        this.symbols = symbols;
    }
    /**
     * Calculates the final goal points for a player.
     * @param player the player for whom to calculate the points
     * @return the calculated points
     */
    @Override
    public int finalGoalPoints(Player player) {
        int points;
        if (isResource){
            Symbol symbol = this.symbols.getFirst();
            points = (player.getPersonalBoard().getNumOfSymbols().get(symbol)/3);
        }
        else {
            Symbol symbol1 = this.symbols.get(0);
            Symbol symbol2 = this.symbols.get(1);
            if(symbol2.equals(symbol1))
                points = (player.getPersonalBoard().getNumOfSymbols().get(symbol1)/2);
            else
                points = (Math.min(player.getPersonalBoard().getNumOfSymbols().get(symbol1), player.getPersonalBoard().getNumOfSymbols().get(symbol2)));

        }
        return points*this.getPoints();
    }
    /**
     * Returns the symbols of the card.
     * @return the symbols of the card
     */
    public ArrayList<Symbol> getSymbols() {
        return symbols;
    }

}
