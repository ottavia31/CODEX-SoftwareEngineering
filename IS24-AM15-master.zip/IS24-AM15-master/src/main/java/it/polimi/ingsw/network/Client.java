package it.polimi.ingsw.network;

import it.polimi.ingsw.controller.State;
import it.polimi.ingsw.localModel.ModelView;
import it.polimi.ingsw.model.PawnColor;
import it.polimi.ingsw.network.DoneMessages.DoneMessage;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;

/**
 * The {@code Client} interface provides methods for communication between the server and client in a networked game environment.
 * It extends the {@code Remote} interface to support remote method invocation (RMI).
 */
public interface Client extends Remote {

    /**
     * Retrieves the nickname of the client.
     *
     * @return the nickname of the client
     * @throws RemoteException if a remote communication error occurs
     */
    String getNickname() throws RemoteException;

    /**
     * Sets the number of players in the game.
     *
     * @param input the number of players as a string
     * @throws RemoteException if a remote communication error occurs
     */
    void setNumPlayers(String input) throws RemoteException;

    /**
     * Retrieves the current state of the game.
     *
     * @return the current state of the game
     * @throws RemoteException if a remote communication error occurs
     */
    State getState() throws RemoteException;

    /**
     * Retrieves the model view of the game.
     *
     * @return the model view of the game
     * @throws RemoteException if a remote communication error occurs
     */
    ModelView getModelView() throws RemoteException;

    /**
     * Sets the first player in the game.
     *
     * @throws RemoteException if a remote communication error occurs
     */
    void setFirstPlayer() throws RemoteException;

    /**
     * Plays the starter card.
     *
     * @param b a boolean indicating whether to play the starter card
     * @throws RemoteException if a remote communication error occurs
     */
    void playStarterCard(boolean b) throws RemoteException;

    /**
     * Handles the input from the client.
     *
     * @param input the input from the client
     * @throws RemoteException if a remote communication error occurs
     */
    void inputHandler(String input) throws RemoteException;

    /**
     * Sets the nickname of the client.
     *
     * @param input the new nickname for the client
     * @throws RemoteException if a remote communication error occurs
     */
    void setNickname(String input) throws RemoteException;

    /**
     * Handles the done message from the client.
     *
     * @param message the done message
     * @throws RemoteException if a remote communication error occurs
     */
    void doneHandler(DoneMessage message) throws RemoteException;

    /**
     * Retrieves the update from the server.
     *
     * @return the update from the server
     * @throws RemoteException if a remote communication error occurs
     */
    Update getUpdate() throws RemoteException;

    /**
     * Pings the server to check the connection.
     *
     * @throws RemoteException if a remote communication error occurs
     */
    void ping() throws RemoteException;

    /**
     * Adds a done message to the client's message queue.
     *
     * @param message the done message to add
     * @throws RemoteException if a remote communication error occurs
     */
    void addMessage(DoneMessage message) throws RemoteException;

    /**
     * Adds input to the client's input queue.
     *
     * @param input the input to add
     * @throws RemoteException if a remote communication error occurs
     */
    void addInput(String input) throws RemoteException;

    /**
     * Retrieves the available colors for pawns.
     *
     * @return a list of available pawn colors
     * @throws RemoteException if a remote communication error occurs
     */
    ArrayList<PawnColor> getAvaiableColors() throws RemoteException;

    /**
     * Sets the current player in the model view of the client
     * @param player the name of the current player
     * @throws RemoteException if a remote communication error occurs
     */
    void setCurrentPlayer(String player)throws RemoteException;
}
