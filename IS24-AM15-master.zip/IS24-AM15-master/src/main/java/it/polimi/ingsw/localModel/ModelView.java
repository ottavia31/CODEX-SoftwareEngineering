package it.polimi.ingsw.localModel;

import it.polimi.ingsw.controller.State;
import it.polimi.ingsw.model.PawnColor;
import it.polimi.ingsw.model.Symbol;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Represents the view model of the game, maintaining the current game state and player-related information.
 */
public class ModelView {
    private State state;
    private int numPlayers;
    private String currentPlayer;
    private final HashMap<String, PersonalBoardView> players;
    private final ArrayList<Integer> commonGoalCards;
    private Symbol resourceTopCardColor;
    private Symbol goldTopCardColor;
    private final ArrayList<Integer> facedUpCards;

    /**
     * Constructor for the ModelView class. Initializes the game state and data structures.
     */
    public ModelView() {
        this.state = State.STARTED;
        this.players = new HashMap<>();
        this.currentPlayer = "first";
        this.commonGoalCards = new ArrayList<>();
        this.resourceTopCardColor = null;
        this.goldTopCardColor = null;
        this.facedUpCards = new ArrayList<>(4);
        for (int i = 0; i < 4; i++) {
            this.facedUpCards.add(null);
        }
    }

    /**
     * Updates the game state.
     *
     * @param state The new game state.
     */
    public void updateState(State state) {
        this.state = state;
    }

    /**
     * Updates the pawn color for a player.
     *
     * @param color    The new pawn color.
     * @param nickname The player's nickname.
     */
    public void updatePawn(PawnColor color, String nickname) {
        this.players.get(nickname).setPawn(color);
    }

    /**
     * Sets the players in the game.
     *
     * @param players A list of player nicknames.
     */
    public void setPlayers(ArrayList<String> players) {
        for (String nickname : players) {
            if (!this.players.containsKey(nickname)) {
                this.players.put(nickname, new PersonalBoardView());
            }
        }
    }

    /**
     * Updates the current player.
     *
     * @param player The nickname of the new current player.
     */
    public void updateCurrentPlayer(String player) {
        this.currentPlayer = player;
    }

    /**
     * Retrieves the current game state.
     *
     * @return The current game state.
     */
    public State getState() {
        return state;
    }

    /**
     * Retrieves the number of players.
     *
     * @return The number of players.
     */
    public int getNumPlayers() {
        return numPlayers;
    }

    /**
     * Updates the number of players.
     *
     * @param numPlayers The new number of players.
     */
    public void updateNumPlayers(int numPlayers) {
        this.numPlayers = numPlayers;
    }

    /**
     * Retrieves the map of players with their nicknames and respective personal board views.
     *
     * @return A HashMap of players.
     */
    public HashMap<String, PersonalBoardView> getPlayers() {
        return players;
    }

    /**
     * Retrieves the current player's nickname.
     *
     * @return The current player's nickname.
     */
    public String getCurrentPlayer() {
        return this.currentPlayer;
    }

    /**
     * Retrieves the list of common goal cards.
     *
     * @return An ArrayList of common goal card IDs.
     */
    public ArrayList<Integer> getCommonGoalCards() {
        return commonGoalCards;
    }

    /**
     * Adds a common goal card.
     *
     * @param id The ID of the common goal card to add.
     */
    public void addCommonGoalCard(Integer id) {
        commonGoalCards.add(id);
    }

    /**
     * Retrieves the color symbol of the top card in the resource deck.
     *
     * @return The symbol of the color of the top card in the resource deck.
     */
    public Symbol getResourceTopCardColor() {
        return resourceTopCardColor;
    }

    /**
     * Sets the color symbol of the top card in the resource deck.
     *
     * @param resourceTopCardColor The new color of the top card in the resource deck.
     */
    public void setResourceTopCardColor(Symbol resourceTopCardColor) {
        this.resourceTopCardColor = resourceTopCardColor;
    }

    /**
     * Retrieves the color symbol of the top card in the gold deck.
     *
     * @return The symbol of the color of the top card in the gold deck.
     */
    public Symbol getGoldTopCardColor() {
        return goldTopCardColor;
    }

    /**
     * Sets the color symbol of the top card in the gold deck.
     *
     * @param goldTopCardColor The new color of the top card in the gold deck.
     */
    public void setGoldTopCardColor(Symbol goldTopCardColor) {
        this.goldTopCardColor = goldTopCardColor;
    }

    /**
     * Retrieves the list of faced-up cards.
     *
     * @return An ArrayList of faced-up card IDs.
     */
    public ArrayList<Integer> getFacedUpCards() {
        return facedUpCards;
    }

    /**
     * Updates a faced-up card at a specific position.
     *
     * @param id    The ID of the new card.
     * @param index The index of the card to update.
     */
    public void updateFacedUpCard(int id, int index) {
        facedUpCards.set(index, id);
    }

    public void setCurrentPlayer(String player) {
        this.currentPlayer = player;
    }
}
