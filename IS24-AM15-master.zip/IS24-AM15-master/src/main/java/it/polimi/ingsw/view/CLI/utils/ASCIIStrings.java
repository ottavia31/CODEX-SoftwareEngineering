package it.polimi.ingsw.view.CLI.utils;

import it.polimi.ingsw.localModel.CardView;
import it.polimi.ingsw.localModel.PersonalBoardView;
import it.polimi.ingsw.model.Coordinates;
import it.polimi.ingsw.model.GameBoard;
import it.polimi.ingsw.model.Symbol;
import it.polimi.ingsw.model.cards.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
/**
 * This class contains ASCII art strings representing various components used in the game interface.
 * These strings include logos, card representations, and arrangements for display purposes.
 */
public class ASCIIStrings {

    /**
     * ASCII art representing the Codex Naturalis logo.
     */
    public static final String codexNaturalisLogo = """
            """ +
            " ▄████████  ▄██████▄  ████████▄     ▄████████ ▀████    ▐████▀      \n" +
            "███    ███ ███    ███ ███   ▀███   ███    ███   ███▌   ████▀       \n" +
            "███    █▀  ███    ███ ███    ███   ███    █▀     ███  ▐███         \n" +
            "███        ███    ███ ███    ███  ▄███▄▄▄        ▀███▄███▀         \n" +
            "███        ███    ███ ███    ███ ▀▀███▀▀▀        ████▀██▄          \n" +
            "███    █▄  ███    ███ ███    ███   ███    █▄    ▐███  ▀███         \n" +
            "███    ███ ███    ███ ███   ▄███   ███    ███  ▄███     ███▄       \n" +
            "████████▀   ▀██████▀  ████████▀    ██████████ ████       ███▄   ";

    /**
     * ASCII art representing the front side of a resource card.
     * The card has spaces to fill with resource values.
     */
    public static final String resourceCardFront = """
            ┌────────────────────────────┐
            │%2s         %2s          %2s\s
            │                            │
            │                            │
            │                            │
            │%2s                      %2s\s
            └────────────────────────────┘""";


    /**
     * ASCII art representing the front side of a starter card.
     * The card has spaces to fill with starter card values.
     */
    public static final String starterCardFront = """
            ┌────────────────────────────┐
            │%2s                      %2s\s
            │                            │
            │           %2s              \s
            │                            │
            │%2s                      %2s\s
            └────────────────────────────┘""";


    /**
     * ASCII art representing the front side of a gold card.
     * The card has spaces to fill with gold card values.
     */
    public static final String goldCardFront = """
            ┌────────────────────────────┐
            │%s       %s|%s          %s \s
            │                            │
            │                           \s
            │                            │
            │%s    %s%s%s%s%s  %s       \s
            └────────────────────────────┘""";


    /**
     * ASCII art representing a goal card.
     * The card has spaces to fill with goal card values.
     */
    public static final String goalCard = """
            +----+---+---+---+----+
            |         %s           |
            |                     |
            |      %s             \s
            |                     |
            |                     |
            +----+---+---+---+----+""";

    /**
     * ASCII art representing an arrangement of goal cards.
     * The arrangement has spaces to fill with goal card values.
     */
    public static final String arrangmentGoalCard =
            """
            +----+---+---+---+----+
            |         %s           |
            |         %s          \s
            |         %s          \s
            |         %s          \s
            |                      |
            +----+---+---+---+----+""";



    /**
     * Prints an ASCII representation of a goal card based on its type.
     * @param goalCardId The ID of the goal card to print.
     */
    public static void printGoalCard(int goalCardId) {
        GameBoard gameBoard = GameBoard.getInstance();
        GoalCard goalcard = gameBoard.getGoalDeck().getGoalCardById(goalCardId);
        int points = goalcard.getPoints();
        if (goalcard instanceof ArrangementGoalCard arrangementGoalCard) {
            Symbol symbol = arrangementGoalCard.getColor();
            boolean isDiagonal = arrangementGoalCard.isDiagonal();
            if (isDiagonal) {
                switch (symbol) {
                    case BLUE -> {
                        String output = String.format(arrangmentGoalCard, points, "      \uD83D\uDFE6", "   \uD83D\uDFE6", "\uD83D\uDFE6");
                        System.out.println(output);
                    }
                    case GREEN -> {
                        String output = String.format(arrangmentGoalCard, points, "\uD83D\uDFE9", "   \uD83D\uDFE9", "      \uD83D\uDFE9");
                        System.out.println(output);
                    }
                    case PURPLE -> {
                        String output = String.format(arrangmentGoalCard, points, "\uD83D\uDFEA", "   \uD83D\uDFEA", "      \uD83D\uDFEA");
                        System.out.println(output);
                    }
                    case RED -> {
                        String output = String.format(arrangmentGoalCard, points, "      \uD83D\uDFE5", "   \uD83D\uDFE5", "\uD83D\uDFE5");
                        System.out.println(output);
                    }
                }
            } else {
                switch (symbol) {
                    case BLUE -> {
                        String output = String.format(arrangmentGoalCard, points, "   \uD83D\uDFE5", "\uD83D\uDFE6", "\uD83D\uDFE6");
                        System.out.println(output);
                    }
                    case GREEN -> {
                        String output = String.format(arrangmentGoalCard, points, "   \uD83D\uDFE9", "   \uD83D\uDFE9", "\uD83D\uDFEA");
                        System.out.println(output);
                    }
                    case PURPLE -> {
                        String output = String.format(arrangmentGoalCard, points, "\uD83D\uDFE6", "   \uD83D\uDFEA", "   \uD83D\uDFEA");
                        System.out.println(output);
                    }
                    case RED -> {
                        String output = String.format(arrangmentGoalCard, points, "\uD83D\uDFE5", "\uD83D\uDFE5", "   \uD83D\uDFE9");
                        System.out.println(output);
                    }
                }
            }

        } else if (goalcard instanceof SymbolsGoalCard symbolGoalCard) {
            ArrayList<Symbol> symbols = symbolGoalCard.getSymbols();
            StringBuilder symbolsString = new StringBuilder();
            for (Symbol symbol : symbols) {
                switch (symbol) {
                    case FEATHER -> symbolsString.append("\uD83E\uDEB6");
                    case POTION -> symbolsString.append("\uD83E\uDED9");
                    case PARCHMENT -> symbolsString.append("\uD83D\uDCDC");
                    case RED -> symbolsString.append("\uD83C\uDF44");
                    case GREEN -> symbolsString.append("\uD83C\uDF43");
                    case BLUE -> symbolsString.append("\uD83D\uDC3A");
                    case PURPLE -> symbolsString.append(" \uD83E\uDD8B");
                }
            }
            String output = String.format(goalCard, points, symbolsString);
            System.out.println(output);
        }
    }

    /**
     * Maps representing different states of card placements and their coverage.
     * Key: Integer representing card ID.
     * Value: HashMap with String keys representing corner names and Boolean values indicating coverage.
     */
    private static final HashMap<Integer, HashMap<String, Boolean>> coveredCornersMap = new HashMap<>();
    /**
     * HashMap storing the last printed map of coordinates to CardView objects.
     * Key: Coordinates object representing the position.
     * Value: CardView object representing the card at that position.
     */
    private static HashMap<Coordinates, CardView> lastPrintedMap = new HashMap<>();
    /**
     * HashMap storing the current map of coordinates to CardView objects.
     * Key: Coordinates object representing the position.
     * Value: CardView object representing the card at that position.
     */
    private static HashMap<Coordinates, CardView> currentMap = new HashMap<>();

    /**
     * Compares two HashMaps of Coordinates to CardView objects for equality.
     *
     * @param map1 The first HashMap to compare.
     * @param map2 The second HashMap to compare.
     * @return true if the two HashMaps are equal (contain the same keys and values), false otherwise.
     */
    public static boolean mapsAreEqual(HashMap<Coordinates, CardView> map1, HashMap<Coordinates, CardView> map2) {
        if (map1.size() != map2.size()) {
            return false;
        }
        for (Map.Entry<Coordinates, CardView> entry : map1.entrySet()) {
            Coordinates key = entry.getKey();
            CardView value1 = entry.getValue();
            CardView value2 = map2.get(key);

            if (value2 == null || !value2.equals(value1)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Finds the newly added coordinate in the current map that is not present in the last printed map.
     *
     * @param currentMap The current map of coordinates to CardView objects.
     * @return Coordinates object representing the newly added coordinate, or null if no new coordinate is found.
     */
    public static Coordinates findNewlyAddedCoordinate(HashMap<Coordinates, CardView> currentMap) {
        for (Map.Entry<Coordinates, CardView> entry : currentMap.entrySet()) {
            Coordinates coords = entry.getKey();
            if (coords.getX() == 0 && coords.getY() == 0) {
                continue;
            }
            if (!lastPrintedMap.containsKey(coords)) {
                return coords;
            }
        }
        return null;
    }

    /**
     * Updates the map of covered corners for adjacent cards based on a new coordinate.
     * Four adjacent coordinates (top-right, bottom-right, top-left, bottom-left) are derived
     * from the given new coordinate and used to update the covered corners map.
     *
     * @param newCoordinate The new coordinate from which adjacent coordinates are calculated.
     *                      If null, no updates are performed.
     * @param currentMap    The current map of coordinates to CardView objects.
     *                      Used to check and update the covered corners for adjacent cards.
     */
    public static void updateCoveredCorners(Coordinates newCoordinate, HashMap<Coordinates, CardView> currentMap) {
        if (newCoordinate != null) {
            // Trova le coordinate adiacenti
            Coordinates topRight = new Coordinates(newCoordinate.getX() - 1, newCoordinate.getY() - 1);
            Coordinates bottomRight = new Coordinates(newCoordinate.getX() - 1, newCoordinate.getY() + 1);
            Coordinates topLeft = new Coordinates(newCoordinate.getX() + 1, newCoordinate.getY() - 1);
            Coordinates bottomLeft = new Coordinates(newCoordinate.getX() + 1, newCoordinate.getY() + 1);

            // Aggiorna la mappa degli angoli coperti per le carte adiacenti
            updateAdjacentCardCoveredCorners(topRight, currentMap, "UR");
            updateAdjacentCardCoveredCorners(bottomRight, currentMap, "DR");
            updateAdjacentCardCoveredCorners(topLeft, currentMap, "UL");
            updateAdjacentCardCoveredCorners(bottomLeft, currentMap, "DL");
        }
    }

    /**
     * Updates the map of covered corners for an adjacent card based on the specified coordinates.
     * If the card at the given coordinates exists in the current map, the corner specified is marked as covered.
     *
     * @param coords     The coordinates of the adjacent card to update.
     * @param currentMap The current map of coordinates to CardView objects, where the adjacent card is checked.
     * @param corner     The corner of the adjacent card to mark as covered ("UR", "DR", "UL", "DL").
     */
    private static void updateAdjacentCardCoveredCorners(Coordinates coords, HashMap<Coordinates, CardView> currentMap, String corner) {
        CardView card = currentMap.get(coords);
        if (card == null) {
            return;
        }
        int cardId = card.getId();
        HashMap<String, Boolean> cornersMap = coveredCornersMap.computeIfAbsent(cardId, k -> new HashMap<>());
        cornersMap.put(corner, true);
    }

    /**
     * Prints the resources of the player to the standard output.
     *
     * @param resources A HashMap containing the Symbol and corresponding quantity of resources.
     */
    public static void printResources(HashMap<Symbol, Integer> resources) {
        System.out.println("Your resources are:");
        for (Map.Entry<Symbol, Integer> entry : resources.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }

    /**
     * Prints the personal board of a player to the standard output.
     *
     * @param personalBoard The PersonalBoardView object representing the player's personal board.
     */
    public static void printPersonalBoard(PersonalBoardView personalBoard) {
        HashMap<Coordinates, CardView> map = personalBoard.getMap();
        printCardTable(map);
        System.out.println();
    }

    /**
     * Prints a visual representation of the card table based on the provided map of coordinates to CardView objects.
     * If the provided map is different from the previously printed map, updates the last printed map and current map.
     * Finds the newly added coordinate in the current map and updates the covered corners for adjacent cards.
     * Calculates the minimum and maximum coordinates to determine the table dimensions.
     * Constructs a table with cards and aligns them for printing.
     * Displays the table with proper formatting and card alignment, including card-specific color coding and spacing.
     *
     * @param map The HashMap containing coordinates mapped to CardView objects representing the cards to be printed.
     */
    public static void printCardTable(HashMap<Coordinates, CardView> map ) {
        if(!mapsAreEqual(map, currentMap)) {
            lastPrintedMap = new HashMap<>(currentMap);
            currentMap = new HashMap<>(map);
        }
        Coordinates newCoordinate = findNewlyAddedCoordinate(currentMap);
        updateCoveredCorners(newCoordinate, currentMap);

        // Trova le coordinate massime e minime
        int minX = map.keySet().stream().mapToInt(Coordinates::getX).min().orElse(0);
        int maxX = map.keySet().stream().mapToInt(Coordinates::getX).max().orElse(0);
        int minY = map.keySet().stream().mapToInt(Coordinates::getY).min().orElse(0);
        int maxY = map.keySet().stream().mapToInt(Coordinates::getY).max().orElse(0);

        // Create a table with the cards
        String[][] table = new String[maxY - minY + 1][maxX - minX + 1];

        // Fill the table
        for (Map.Entry<Coordinates, CardView> entry : map.entrySet()) {
            Coordinates coord = entry.getKey();
            CardView card = entry.getValue();

            if (card.getId()<41)
                table[coord.getY() - minY][coord.getX() - minX] = getResourceCard(card.getId(), card.isBack());
            else if(card.getId()<81&&card.getId()>40)
                table[coord.getY() - minY][coord.getX() - minX] = getGoldCard(card.getId(), card.isBack());
            else if(card.getId()>80 && card.getId()<87)
                table[coord.getY() - minY][coord.getX() - minX] = getStarterCard(card.getId(), card.isBack());
        }

        // Max number of rows in a cell
        int maxRows = 0;
        for (String[] row : table) {
            for (String cell : row) {
                if (cell != null) {
                    maxRows = Math.max(maxRows, cell.split("\n").length);
                }
            }
        }

        // Print the table
        int Y = maxY + 1;
        for (int j = 0; j < maxRows; j++) {
            if (j == maxRows/2)
                System.out.print(Y + "\t\t\t\t\t\t\t\t ");
            else
                System.out.print(" \t\t\t\t\t\t\t\t ");
            System.out.println();
        }
            for (int i = table.length - 1; i >=0 ; i--) {
            for (int j = 0; j < maxRows; j++) {

                if(j == maxRows/2)
                    System.out.print(i + minY+ "                                    ");
                else
                    System.out.print("                                     ");
                for (int k = 0; k < table[i].length; k++) {
                    if (table[i][k] != null) {

                        String[] lines = table[i][k].split("\n");
                        String colorCode = lines[0].substring(0, 5);
                        int lenght = lines[0].length();
                        //color the started card in yellow
                        if(k + minX==0 && i+minY==0) {
                            colorCode = "\033[33m";
                        }
                        if (j < lines.length) {
                            // Add spaces to align the cards
                            if (lines[j].length()<lenght) {
                                for (int l = 0; l < lenght -5 - lines[j].length(); l++) {
                                    lines[j] += " ";
                                }
                            } else { // Remove spaces to align the cards
                                for (int l = 0; l < lines[j].length() - 5 - lenght; l++) {
                                    lines[j] = lines[j].substring(0, lines[j].length() - 1);
                                }
                            }

                            System.out.print(colorCode+lines[j]+"\033[0m");
                        }
                    }
                    else
                        System.out.print("                             "); // Tabulazione per separare le carte
                    }
                System.out.println();
            }
        }
        System.out.print("\t ");
        for (int k = -1; k < maxX - minX + 2; k++) {
            int x = k + minX;
            System.out.print("             "+ x +"              ");
        }
    }

    /**
     * Prints a visual representation of a starter card based on the provided starter card ID and whether it's the back side.
     * Uses {@link #getStarterCard(int, boolean)} to retrieve the card's representation and prints it to the console.
     *
     * @param starterCardId The ID of the starter card to print.
     * @param isBackSide    Specifies whether to print the back side of the starter card.
     */
    public static void printStarterCard(int starterCardId, boolean isBackSide) {
        String output = getStarterCard(starterCardId, isBackSide);
        System.out.print(output);
        System.out.println();
    }

    /**
     * Prints a visual representation of a resource card based on the provided resource card ID and whether it's the back side.
     * Uses {@link #getResourceCard(int, boolean)} to retrieve the card's representation and prints it to the console.
     *
     * @param resourceCardId The ID of the resource card to print.
     * @param isBackSide     Specifies whether to print the back side of the resource card.
     */
    public static void printResourceCard(int resourceCardId, boolean isBackSide) {
        String output = getResourceCard(resourceCardId, isBackSide);
        System.out.print(output);
        System.out.println();
    }

    /**
     * Prints a visual representation of a gold card based on the provided gold card ID and whether it's the back side.
     * Uses {@link #getGoldCard(int, boolean)} to retrieve the card's representation and prints it to the console.
     *
     * @param goldCardId The ID of the gold card to print.
     * @param isBackSide Specifies whether to print the back side of the gold card.
     */
    public static void printGoldCard(int goldCardId, boolean isBackSide) {
        String output = getGoldCard(goldCardId, isBackSide);
        System.out.print(output);
        System.out.println();
    }

    /**
     * Retrieves the symbol corresponding to the given corner of a card, checking if the corner is covered.
     * If the card ID is found in {@link #coveredCornersMap}, checks if the specified corner is covered.
     *
     * @param corner  The corner identifier (e.g., "UL", "UR", "DL", "DR") to retrieve the symbol for.
     * @param corners A map containing corner identifiers mapped to symbols for a specific card.
     * @param id      The ID of the card for which to retrieve the corner symbol.
     * @return The symbol or emoji representing the specified corner of the card.
     */
    private static String getCornerSymbol(String corner, Map<String, Symbol> corners, Integer id) {
        if (coveredCornersMap.containsKey(id) && coveredCornersMap.get(id).containsKey(corner) && coveredCornersMap.get(id).get(corner)) {
            return "❌";
        } else {
            return getEmojiForSymbol(corners.get(corner));
        }
    }


    /**
     * Retrieves the emoji representation for a given symbol.
     *
     * @param symbol The symbol for which to retrieve the emoji.
     * @return The emoji corresponding to the provided symbol.
     */
    public static String getEmojiForSymbol(Symbol symbol) {
        if (symbol == null) {
            return "  "; // or some default value
        }
        return switch (symbol) {
            case RED -> "\uD83C\uDF44";
            case GREEN -> "\uD83C\uDF43";
            case BLUE -> "\uD83D\uDC3A";
            case PURPLE -> "\uD83E\uDD8B";
            case FEATHER -> "\uD83E\uDEB6";
            case POTION -> "\uD83E\uDED9";
            case PARCHMENT -> "\uD83D\uDCDC";
            case CORNER -> "\uD83E\uDEAA";
            case EMPTY -> "⬜";
        };
    }

    /**
     * Constructs and retrieves a string representation of a starter card based on the provided starter card ID and whether it's the back side.
     * Uses {@link GameBoard#getInstance()} to retrieve the game board instance,
     * {@link GameBoard#getStarterDeck()} to access the starter deck, and {@link StarterDeck#getStarterCardById(int)} to fetch the starter card by ID.
     * If {@code isBackSide} is {@code true}, flips the starter card and retrieves back side corner symbols; otherwise, retrieves front side corner symbols and front symbols.
     *
     * @param starterCardId The ID of the starter card.
     * @param isBackSide Specifies whether to retrieve the back side representation of the starter card.
     * @return A formatted string representing the starter card.
     */
    public static String getStarterCard(int starterCardId, boolean isBackSide) {
        GameBoard gameBoard = GameBoard.getInstance();
        StarterCard starterCard = gameBoard.getStarterDeck().getStarterCardById(starterCardId);
        if(starterCard.isBackSide()&& !isBackSide)
            starterCard.flip();
        if(!starterCard.isBackSide()&& isBackSide)
            starterCard.flip();

        if (isBackSide) {
            Map<String, Symbol> backCorners = starterCard.getCorners();
            String topLeftSymbol = getCornerSymbol("UL", backCorners, starterCardId);
            String topRightSymbol = getCornerSymbol("UR", backCorners, starterCardId);
            String bottomLeftSymbol = getCornerSymbol("DL", backCorners, starterCardId);
            String bottomRightSymbol = getCornerSymbol("DR", backCorners, starterCardId);
            String points = "  ";

            return String.format(resourceCardFront, topLeftSymbol, points, topRightSymbol, bottomLeftSymbol, bottomRightSymbol);

        } else {
            Map<String, Symbol> frontCorners = starterCard.getCorners();
            String topLeftSymbol = getCornerSymbol("UL", frontCorners, starterCardId);
            String topRightSymbol = getCornerSymbol("UR", frontCorners, starterCardId);
            String bottomLeftSymbol = getCornerSymbol("DL", frontCorners, starterCardId);
            String bottomRightSymbol = getCornerSymbol("DR", frontCorners, starterCardId);

            ArrayList<Symbol> frontSymbols = starterCard.getFrontSymbols();
            ArrayList<String> emojiSymbols = new ArrayList<>();
            for (Symbol symbol : frontSymbols) {
                String emoji = getEmojiForSymbol(symbol);
                emojiSymbols.add(emoji);
            }

            return String.format(starterCardFront, topLeftSymbol, topRightSymbol, emojiSymbols, bottomLeftSymbol, bottomRightSymbol);
        }
    }

    /**
     * Constructs and retrieves a string representation of a resource card based on the provided resource card ID and whether it's the back side.
     * Uses {@link GameBoard#getInstance()} to retrieve the game board instance,
     * {@link GameBoard#getResourceDeck()} to access the resource deck, and {@link ResourceDeck#getResourceCardById(int)} to fetch the resource card by ID.
     * If {@code isBackSide} is {@code true}, retrieves a color symbol; otherwise, retrieves corner symbols and front symbols.
     *
     * @param resourceCardId The ID of the resource card.
     * @param isBackSide Specifies whether to retrieve the back side representation of the resource card.
     * @return A formatted string representing the resource card.
     */
    public static String getResourceCard(int resourceCardId, boolean isBackSide) {
        GameBoard gameBoard = GameBoard.getInstance();
        ResourceCard resourceCard = gameBoard.getResourceDeck().getResourceCardById(resourceCardId);

        if (isBackSide) {
            Symbol color = resourceCard.getColor();
            String colorSymbol = getEmojiForSymbol(color);
            String colorCode = colorCard(color);
            Map<String, Symbol> backcorners = new HashMap<>();
            backcorners.put("UL", Symbol.EMPTY);
            backcorners.put("UR", Symbol.EMPTY);
            backcorners.put("DL", Symbol.EMPTY);
            backcorners.put("DR", Symbol.EMPTY);

            String topLeftSymbol = getCornerSymbol("UL", backcorners, resourceCardId);
            String topRightSymbol = getCornerSymbol("UR", backcorners, resourceCardId);
            String bottomLeftSymbol = getCornerSymbol("DL", backcorners, resourceCardId);
            String bottomRightSymbol = getCornerSymbol("DR", backcorners, resourceCardId);

            return colorCode + String.format(starterCardFront, topLeftSymbol, topRightSymbol, colorSymbol, bottomLeftSymbol, bottomRightSymbol) + "\033[0m";

        } else {
            Map<String, Symbol> corners = resourceCard.getCorners();
            String topLeftSymbol = getCornerSymbol("UL", corners, resourceCardId);
            String topRightSymbol = getCornerSymbol("UR", corners, resourceCardId);
            String bottomLeftSymbol = getCornerSymbol("DL", corners, resourceCardId);
            String bottomRightSymbol = getCornerSymbol("DR", corners, resourceCardId);

            Symbol color = resourceCard.getColor();
            String colorCode = colorCard(color);

            int point = resourceCard.getPoints();

            return colorCode + String.format(resourceCardFront, topLeftSymbol, point, topRightSymbol, bottomLeftSymbol, bottomRightSymbol)+ "\033[0m";
        }
    }

    /**
     * Constructs and retrieves a string representation of a gold card based on the provided gold card ID and whether it's the back side.
     * Uses {@link GameBoard#getInstance()} to retrieve the game board instance,
     * {@link GameBoard#getGoldDeck()} to access the gold deck, and {@link GoldDeck#getGoldCardById(int)} to fetch the gold card by ID.
     * If {@code isBackSide} is {@code true}, retrieves a color symbol; otherwise, retrieves corner symbols, points, conditions to use, and goal symbol.
     *
     * @param goldCardId The ID of the gold card.
     * @param isBackSide Specifies whether to retrieve the back side representation of the gold card.
     * @return A formatted string representing the gold card.
     */
    public static String getGoldCard(int goldCardId, boolean isBackSide) {
        GameBoard gameBoard = GameBoard.getInstance();
        GoldCard goldCard = gameBoard.getGoldDeck().getGoldCardById(goldCardId);

        if (isBackSide) {
            Symbol color = goldCard.getColor();
            String colorCode = colorCard(color);
            String colorSymbol = getEmojiForSymbol(color);

            Map<String, Symbol> backcorners = new HashMap<>();
            backcorners.put("UL", Symbol.EMPTY);
            backcorners.put("UR", Symbol.EMPTY);
            backcorners.put("DL", Symbol.EMPTY);
            backcorners.put("DR", Symbol.EMPTY);

            String topLeftSymbol = getCornerSymbol("UL", backcorners, goldCardId);
            String topRightSymbol = getCornerSymbol("UR", backcorners, goldCardId);
            String bottomLeftSymbol = getCornerSymbol("DL", backcorners, goldCardId);
            String bottomRightSymbol = getCornerSymbol("DR", backcorners, goldCardId);


            return colorCode + String.format(starterCardFront, topLeftSymbol, topRightSymbol, colorSymbol, bottomLeftSymbol, bottomRightSymbol) +"\033[0m";

        } else {
            Map<String, Symbol> corners = goldCard.getCorners();
            Symbol color = goldCard.getColor();
            String colorCode = colorCard(color);

            String topLeftSymbol = getCornerSymbol("UL", corners, goldCardId);
            String topRightSymbol = getCornerSymbol("UR", corners, goldCardId);
            String bottomLeftSymbol = getCornerSymbol("DL", corners, goldCardId);
            String bottomRightSymbol = getCornerSymbol("DR", corners, goldCardId);

            int point = goldCard.getPoints();
            ArrayList<Symbol> conditionsToUse= goldCard.getConditionsToUse();
            ArrayList<String> emojiSymbols = new ArrayList<>();
            for (int i = 0; i < 5; i++){
                if (i >= conditionsToUse.size()) {
                    emojiSymbols.add("  ");
                } else {
                    Symbol symbol = conditionsToUse.get(i);
                    String emoji = getEmojiForSymbol(symbol);
                    emojiSymbols.add(emoji);
                }
            }
            String goal = getEmojiForSymbol(goldCard.getGoal());

            return colorCode + String.format(goldCardFront, topLeftSymbol, point, goal, topRightSymbol, bottomLeftSymbol, emojiSymbols.get(0),emojiSymbols.get(1), emojiSymbols.get(2), emojiSymbols.get(3), emojiSymbols.get(4), bottomRightSymbol) +"\033[0m";

        }
    }

    /**
     * Retrieves the ANSI color code corresponding to the provided symbol for coloring cards.
     *
     * @param symbol The symbol for which to retrieve the ANSI color code.
     * @return The ANSI color code corresponding to the provided symbol.
     */
    public static String colorCard(Symbol symbol) {
        return switch (symbol) {
            case RED -> "\033[31m";
            case BLUE -> "\033[34m";
            case GREEN -> "\033[32m";
            case PURPLE -> "\033[35m";
            default -> "\033[0m";
        };
    }
}

