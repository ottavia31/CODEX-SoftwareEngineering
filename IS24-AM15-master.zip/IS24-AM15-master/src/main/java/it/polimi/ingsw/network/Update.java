package it.polimi.ingsw.network;

import it.polimi.ingsw.controller.State;
import it.polimi.ingsw.localModel.ModelView;
import it.polimi.ingsw.localModel.PersonalBoardView;
import it.polimi.ingsw.localModel.PlayerView;
import it.polimi.ingsw.model.Coordinates;
import it.polimi.ingsw.network.DoneMessages.*;

/**
 * The {@code Update} class manages the updates to the model view, personal board view, and player view
 * in a networked game environment.
 */
public class Update {
    private final ModelView modelView;
    private final PlayerView playerView;

    /**
     * Constructs an {@code Update} object and initializes its views.
     */
    public Update(){
        this.modelView = new ModelView();
        this.playerView = new PlayerView();
        this.modelView.updateState(State.STARTED);
    }

    /**
     * Updates the state of the game.
     *
     * @param state the new state of the game
     */
    public void updateState(State state){
        this.modelView.updateState(state);
    }

    /**
     * Retrieves the model view.
     *
     * @return the model view
     */
    public ModelView getModelView(){
        return this.modelView;
    }

    /**
     * Modifies the model with new player information.
     *
     * @param message the message containing new player information
     */
    public void modifyModel(UpdateNewPlayerMessage message){
        if(!this.modelView.getPlayers().containsKey(message.getNickname())){
            this.modelView.getPlayers().put(message.getNickname(), new PersonalBoardView());
        }
        if(this.modelView.getPlayers().size() == 1){
            this.playerView.setFirst(true);
        }
        this.modelView.updateCurrentPlayer(message.getNickname());
    }

    /**
     * Retrieves the current state of the game.
     *
     * @return the current state of the game
     */
    public State getState(){
        return this.modelView.getState();
    }

    /**
     * Modifies the model with new state and turn information.
     *
     * @param message the message containing new state and turn information
     */
    public void modifyModel(UpdateStateAndTurnMessage message){
        this.modelView.updateState(message.getState());
        this.modelView.updateCurrentPlayer(message.getPlayer());
    }

    /**
     * Modifies the model with new number of players.
     *
     * @param message the message containing new number of players
     */
    public void modifyModel(UpdateNumPlayersMessage message){
        this.modelView.updateNumPlayers(message.getNumPlayers());
    }

    /**
     * Modifies the model with new faced-up cards information.
     *
     * @param message the message containing new faced-up cards information
     */
    public void modifyModel(UpdateFacedupCardsMessage message){
        this.modelView.updateFacedUpCard(message.getId(), message.getIndex());
    }

    /**
     * Retrieves the player view.
     *
     * @return the player view
     */
    public PlayerView getPlayerView(){
        return this.playerView;
    }

    /**
     * Modifies the model with new game state information.
     *
     * @param message the message containing new game state information
     */
    public void modifyModel(UpdateGameStateMessage message){
        this.modelView.updateState(message.getState());
    }

    /**
     * Modifies the model with new gold deck information.
     *
     * @param message the message containing new gold deck information
     */
    public void modifyModel(UpdateGoldDeckMessage message){
        this.modelView.setGoldTopCardColor(message.getColor());
    }

    /**
     * Modifies the model with new setup game information.
     *
     * @param message the message containing new setup game information
     */
    public void modifyModel(UpdateSetupGameMessage message){
        this.modelView.updateCurrentPlayer(message.getCurrentPlayer());
        this.modelView.setPlayers(message.getPlayers());
        this.modelView.setGoldTopCardColor(message.getGoldTopCardColor());
        this.modelView.setResourceTopCardColor(message.getResourceTopCardColor());
        this.modelView.addCommonGoalCard(message.getGoals().get(0));
        this.modelView.addCommonGoalCard(message.getGoals().get(1));
        this.modelView.updateFacedUpCard(message.getFacedUpCards().get(0), 0);
        this.modelView.updateFacedUpCard(message.getFacedUpCards().get(1), 1);
        this.modelView.updateFacedUpCard(message.getFacedUpCards().get(2), 2);
        this.modelView.updateFacedUpCard(message.getFacedUpCards().get(3), 3);
    }

    /**
     * Modifies the model with new resource deck information.
     *
     * @param message the message containing new resource deck information
     */
    public void modifyModel(UpdateResourceDeckMessage message){
        this.modelView.setResourceTopCardColor(message.getColor());
    }

    /**
     * Modifies the model with new starter card information.
     *
     * @param message the message containing new starter card information
     */
    public void modifyModel(UpdateStarterCardMessage message){
        Coordinates coordinates = new Coordinates(0, 0);
        this.modelView.getPlayers().get(message.getPlayer()).updatePersonalBoard(coordinates, message.getCard(), message.getIsback());
    }

    /**
     * Modifies the model with new personal deck information.
     *
     * @param message the message containing new personal deck information
     */
    public void modifyModel(UpdatePersonalDeckMessage message){
        this.playerView.addPlayCard(message.getId());
    }

    /**
     * Modifies the model with new personal board information.
     *
     * @param message the message containing new personal board information
     */
    public void modifyModel(UpdatePersonalBoardMessage message){
        this.modelView.getPlayers().get(message.getNickname()).updatePersonalBoard(message.getCoordinates(), message.getCard(), message.getIsback());
        this.playerView.updateScore(message.getPoints());
        this.modelView.getPlayers().get(message.getNickname()).setScore(message.getPoints());
    }

    /**
     * Modifies the model with new goal card information.
     *
     * @param message the message containing new goal card information
     */
    public void modifyModel(UpdateGoalCardMessage message){
        this.playerView.setGoalCard(message.getCard());
    }

    /**
     * Modifies the model with new pawn color information.
     *
     * @param message the message containing new pawn color information
     */
    public void modifyModel(UpdatePawnColorMessage message){
        this.modelView.updatePawn(message.getColor(), message.getNickname());
    }

    /**
     * Modifies the model with new turn information.
     *
     * @param message the message containing new turn information
     */
    public void modifyModel(TurnMessage message){
        this.modelView.updateCurrentPlayer(message.getNickname());
    }

    /**
     * Modifies the model with card removal information.
     *
     * @param message the message containing card removal information
     */
    public void modifyModel(UpdateCardRemoved message) {
        this.playerView.removeCard(message.getCard());
    }
}
