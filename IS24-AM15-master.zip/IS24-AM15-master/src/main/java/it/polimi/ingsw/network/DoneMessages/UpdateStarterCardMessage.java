package it.polimi.ingsw.network.DoneMessages;

import it.polimi.ingsw.controller.State;
import it.polimi.ingsw.network.DoneMessages.ConfirmAction;

/**
 * Represents a message indicating the update of a starter card for a player.
 * Extends {@link DoneMessage}.
 */
public class UpdateStarterCardMessage extends DoneMessage {

    private final int card;
    private final Boolean isback;
    private final String player;

    /**
     * Constructs an UpdateStarterCardMessage object.
     *
     * @param state  the state associated with this message
     * @param card   the identifier of the starter card
     * @param isback whether the card is facing back or front
     * @param player the player associated with the starter card update
     */
    public UpdateStarterCardMessage(State state, int card, Boolean isback, String player) {
        super(ConfirmAction.STARTER_CARD, state);
        this.card = card;
        this.isback = isback;
        this.player = player;
    }

    /**
     * Retrieves the identifier of the starter card.
     *
     * @return the starter card identifier
     */
    public int getCard() {
        return this.card;
    }

    /**
     * Checks whether the starter card is facing back or front.
     *
     * @return {@code true} if the card is facing back, {@code false} otherwise
     */
    public Boolean getIsback() {
        return this.isback;
    }

    /**
     * Retrieves the player associated with the starter card update.
     *
     * @return the player's nickname
     */
    public String getPlayer() {
        return this.player;
    }
}
