package it.polimi.ingsw.view.CLI;

import it.polimi.ingsw.controller.State;
import it.polimi.ingsw.localModel.ModelView;
import it.polimi.ingsw.model.PawnColor;
import it.polimi.ingsw.model.Symbol;
import it.polimi.ingsw.network.Client;
import it.polimi.ingsw.view.CLI.utils.ASCIIStrings;
import it.polimi.ingsw.view.ViewController;

import java.rmi.RemoteException;
import java.util.*;
import java.util.stream.Collectors;
/**
 * This class is the view for the TUI.
 * It manages the interactions between the user and the game.
 * It accepts inputs from the user and sends them to the handler.
 * It also prints the game state to the user.
 */
public class CLIView implements ViewController {
    private ModelView modelView;
    private Client client;
    /**
     * This method is launched when the client starts.
     * It accepts inputs from the user and sends them to the handler.
     * @param client the client
     * @throws RemoteException if the server is not reachable
     */
    @Override
    public void run(Client client) throws RemoteException {
        this.client = client;
        this.modelView = client.getModelView();
        Scanner scanner = new Scanner(System.in);
        System.out.println(ASCIIStrings.codexNaturalisLogo);
        System.out.println("Welcome to the game! Please enter your name: ");
        while (true){
            String input = scanner.nextLine();
            client.addInput(input);
        }
    }

    /**
     * This method updates the view based on the game state.
     * @param state the current state of the game
     * @throws RemoteException if the server is not reachable
     */
    public void update (State state) throws RemoteException {
        String clientNickname = client.getNickname();
        switch (state) {
            case FIRST_PLAYER_ADDED -> System.out.println("Choose the number of players:\n");

            case PLAYER_ADDED -> {
                String lastPlayer = modelView.getCurrentPlayer();
                if(lastPlayer.equals(clientNickname)){
                    System.out.println("You have joined the game");
                    System.out.println("\nWaiting for other players to join...\n");
                }
                else if(!lastPlayer.equals("newPlayer")){
                    System.out.println("Player " + lastPlayer + " has joined the game");
                }
            }

            case NUM_SETTED -> {
                int num = modelView.getNumPlayers();
                System.out.println("You have set the number of players to " + num);
                System.out.println("Waiting for other players to join...");
            }

            case GAME_SETTED -> {
                if(clientNickname.equals(modelView.getCurrentPlayer())){
                    System.out.println("Choose your pawn: \n");
                    ArrayList<PawnColor> colors;
                    colors = this.client.getAvaiableColors();
                    for(PawnColor color : colors){
                        System.out.println(color );
                    }
                    System.out.println("\n");
                }
                else {
                    System.out.println(modelView.getCurrentPlayer()+"'s choosing their pawn, wait...");
                }
            }
            case ALL_PAWNS_SETTED ->  {
                if(client.getNickname().equals(modelView.getCurrentPlayer())){
                    System.out.println("Front side: ");
                    ASCIIStrings.printStarterCard(this.client.getModelView().getPlayers().get(client.getNickname()).getCard(0, 0).getId(),false);
                    System.out.println("Back side: ");
                    ASCIIStrings.printStarterCard(this.client.getModelView().getPlayers().get(client.getNickname()).getCard(0, 0).getId(),true);
                    System.out.println("Choose the side of your starter card: [front/back]");
                } else {
                    System.out.println(modelView.getCurrentPlayer()+"'s choosing their starter card, wait...");
                }

            }
            case STARTER_CARD_PLAYED -> {
                if (client.getNickname().equals(modelView.getCurrentPlayer())) {
                    System.out.println("Choose one of the goal cards (choose 1 or 2)\n");
                    ASCIIStrings.printGoalCard(this.client.getUpdate().getPlayerView().getGoalCards().get(0));
                    ASCIIStrings.printGoalCard(this.client.getUpdate().getPlayerView().getGoalCards().get(1));
                } else {
                    System.out.println(modelView.getCurrentPlayer()+"'s choosing their goal card, wait...");
                }
            }

            case ALL_SECRET_GOALS_SETTED -> {
                System.out.println("""
                        From now on, any time you want to chat, you can write CHAT WITH and then:
                        - EVERYONE --> if you want to send the message to all the players
                        - player's nickname --> if you want to send the message to one of the players
                        The other players are:\s
                        """);
                for(String player : this.client.getUpdate().getModelView().getPlayers().keySet()) {
                    if (!player.equals(this.client.getNickname())) {
                        System.out.println(player);
                    }
                }
                System.out.println("If you want to see the full chat type 'SHOW CHAT WITH' and then 'EVERYONE' or one of the players");
                System.out.println("INIZIA IL GIOCO!\n");
                if(client.getNickname().equals(modelView.getCurrentPlayer())){
                    printPlayCard();
                } else {
                    System.out.println("It's " + modelView.getCurrentPlayer() + "'s turn");
                }

            }
            case THROWN -> {
                if(client.getNickname().equals(modelView.getCurrentPlayer())){

                    System.out.println("Your personal board:");
                    ASCIIStrings.printPersonalBoard(this.client.getModelView().getPlayers().get(this.client.getNickname()));
                    System.out.println("\033[0mResource deck:" + this.client.getUpdate().getModelView().getResourceTopCardColor());
                    System.out.println("Gold deck:" + this.client.getUpdate().getModelView().getGoldTopCardColor());
                    printFaceupCardsHorizontal();
                    System.out.println();
                    System.out.println("""
                            \033[0mDraw a card:
                            [1] Resource deck
                            [2] Gold deck
                            [3] Face-up card 1
                            [4] Face-up card 2
                            [5] Face-up card 3
                            [6] Face-up card 4""");

                }else{
                    System.out.println(modelView.getCurrentPlayer() + " played a card. \n" +
                            "Updated " + modelView.getCurrentPlayer()+ "'s personal board:");
                    ASCIIStrings.printPersonalBoard(this.client.getModelView().getPlayers().get(modelView.getCurrentPlayer()));
                }
            }
            case DRAWN -> {
                if (client.getNickname().equals(modelView.getCurrentPlayer())) {
                    printPlayCard();
                } else {
                    System.out.println("Score board: ");
                    for(String player : this.client.getUpdate().getModelView().getPlayers().keySet()){

                        printPawn(this.client.getUpdate().getModelView().getPlayers().get(player).getPawn());
                        System.out.println(player + ": " + this.client.getUpdate().getModelView().getPlayers().get(player).getScore());
                    }
                    System.out.println("It's " + modelView.getCurrentPlayer() + "'s turn");
                }
            }

            case LAST_TURN_COMPLETED-> System.out.println("The game is ended! Type [winner] to see if you are the winner!");

            }
        }

    private void printPawn(String pawn) {
        switch (pawn){
            case "BLUE" -> System.out.print("\uD83D\uDD35");
            case "GREEN" -> System.out.print("\uD83D\uDFE2");
            case "YELLOW" -> System.out.print("\uD83D\uDFE1");
            case "RED" -> System.out.print("\uD83D\uDD34");
        }
    }

    /**
     * Prints the game setup details including common goal cards, player's secret goal card,
     * personal board, resources, and prompts for card selection and placement.
     *
     * @throws RemoteException If a network-related error occurs while accessing client or server data.
     */
    private void printPlayCard() throws RemoteException {
        System.out.println("Common goal cards:");
        ASCIIStrings.printGoalCard(this.client.getUpdate().getModelView().getCommonGoalCards().get(0));
        ASCIIStrings.printGoalCard(this.client.getUpdate().getModelView().getCommonGoalCards().get(1));

        System.out.println("Your goalCard:");
        int goalCard = client.getUpdate().getPlayerView().getSecretGoalCard();
        System.out.println(goalCard + " ");
        ASCIIStrings.printGoalCard(goalCard);

        System.out.println("Your personal board:\n");
        ASCIIStrings.printPersonalBoard(this.client.getUpdate().getModelView().getPlayers().get(this.client.getNickname()));

        HashMap<Symbol, Integer> resource = this.client.getUpdate().getPlayerView().getPersonalBoardView().getResources();
        for (Symbol s : resource.keySet()) {
            System.out.println(s + ": " + resource.get(s));
        }
        ASCIIStrings.printResources(resource);

        printHandHorizontal();
        System.out.println("Choose the card you want to play [1-3], the coordinates [x y] where you want to place the card, \n" +
                "and the side of the card [front/back]");
        System.out.println("Example: 3 1 1 front");
        System.out.print(">");
    }

    /**
     * This method prints the face-up cards horizontally.
     * @throws RemoteException if the server is not reachable
     */
    private void printFaceupCardsHorizontal() throws RemoteException {
        System.out.println("Face-up cards:");

        // Convert each card to a list of lines
        List<List<String>> cardLines = new ArrayList<>();
        for(int card : this.client.getModelView().getFacedUpCards()){
            String cardString;
            if(card > 0 && card < 41){
                cardString = ASCIIStrings.getResourceCard(card, false);
            } else if(card > 40 && card < 81) {
                cardString = ASCIIStrings.getGoldCard(card, false);
            } else {
                continue;
            }
            String colorCode = cardString.substring(0, 5);
            cardLines.add(Arrays.stream(cardString.split("\n"))
                    .map(line -> colorCode+line)
                    .collect(Collectors.toList()));
        }

        // Find the maximum number of lines in a card
        int maxLines = cardLines.stream().mapToInt(List::size).max().orElse(0);

        // Print each line of each card
        for (int i = 0; i < maxLines; i++) {
            for (List<String> lines : cardLines) {
                if (i < lines.size()) {
                    System.out.print(lines.get(i)+"\t\t\t");
                }
            }
            System.out.println();
        }
        for(int i = 1; i < 5; i++){
            System.out.print("              "+ i +"              ");
            System.out.print("\t\t\t");
        }
    }

    /**
     * Prints the horizontal representation of the player's hand, including resource cards and gold cards.
     *
     * @throws RemoteException If a network-related error occurs while accessing client or server data.
     */
    public void printHandHorizontal() throws RemoteException {
        System.out.println("Your hand:");
        List<List<String>> cardLines = new ArrayList<>();
        for(Integer card : client.getUpdate().getPlayerView().getPlayCards()){
            String cardString;
            if(card > 0 && card < 41){
                cardString = ASCIIStrings.getResourceCard(card, false);
            } else if(card > 41 && card < 81) {
                cardString = ASCIIStrings.getGoldCard(card, false);
            } else {
                continue;
            }
            String colorCode = cardString.substring(0, 5);
            cardLines.add(Arrays.stream(cardString.split("\n"))
                    .map(line -> colorCode+line)
                    .collect(Collectors.toList()));
        }

        // Find the maximum number of lines in a card
        int maxLines = cardLines.stream().mapToInt(List::size).max().orElse(0);

        // Print each line of each card
        for (int i = 0; i < maxLines; i++) {
            for (List<String> lines : cardLines) {
                if (i < lines.size()) {
                    System.out.print(lines.get(i)+"\t\t\t");
                }
            }
            System.out.println();
        }
        for(int i = 1; i < 4; i++){

            System.out.print("              "+ i +"              ");
            System.out.print("\t\t\t");
        }
        System.out.println();
    }

    /**
     * This method prints a message.
     * @param message the message to be printed
     */
    public void print(String message) {
        System.out.print(message + "\n");
    }

    /**
     * This method prints an error message.
     * @param details the details of the error
     */
    public void reportError(String details){
        System.err.print("\n[ERROR] " + details + "\n> ");
    }

    /**
     * Prints the ASCII art representation of a card based on its ID and side.
     *
     * @param id The ID of the card to print.
     * @param isbackSide Whether to print the back side (true) or front side (false) of the card.
     */
    public void printCard(int id, boolean isbackSide){
        if(id > 0 && id < 41){
            ASCIIStrings.printResourceCard(id, isbackSide);
        } else if(id > 40 && id < 81){
            ASCIIStrings.printGoldCard(id, isbackSide);
        } else if (id > 80 && id < 87){
            ASCIIStrings.printStarterCard(id, isbackSide);
        } else if (id > 86 && id < 103){
            ASCIIStrings.printGoalCard(id);
        } else {
            System.out.println("non ho trovato la carta numero " + id);
        }
    }
}