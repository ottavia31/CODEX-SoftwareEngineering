package it.polimi.ingsw.model.cards;

import it.polimi.ingsw.model.Symbol;
import it.polimi.ingsw.model.exceptions.DeckFinishedException;

import java.util.ArrayList;
/**
 * This class represents a deck of starter cards in the game.
 * It implements the Deck interface.
 */
public class StarterDeck implements Deck {
    private final ArrayList<StarterCard> cards;
    /**
     * Constructor for the StarterDeck class.
     * Initializes an empty list of StarterCard objects.
     */
    public StarterDeck() {
        super();
        cards = new ArrayList<>();
    }
    /**
     * Returns the StarterCard with the specified id from the deck.
     * @param id the id of the StarterCard to be returned
     * @return the StarterCard with the specified id, or null if no such card exists in the deck
     */
    public StarterCard getStarterCardById(int id) {
        for (StarterCard card : cards) {
            if (card.getId() == id) {
                return card;
            }
        }
        return null;
    }

    /**
     * Returns the top card of the deck and removes it from the deck.
     * If the deck is empty, throws a DeckFinishedException.
     * @return the top card of the deck
     * @throws DeckFinishedException if the deck is empty
     */
    @Override
    public StarterCard getTopCard() throws DeckFinishedException{
        if (cards.isEmpty()) {
            throw new DeckFinishedException("Deck is empty");
        }
        StarterCard curr = cards.getLast();
        cards.remove(cards.size() - 1);
        return curr;
    }
    /**
     * Returns the color of the top card of the deck.
     * @return the color of the top card of the deck
     */
    @Override
    public Symbol getTopCardColor() {
        return cards.getLast().getColor();
    }

    /**
     * This method returns the list of cards in the deck.
     * @return An ArrayList of StarterCard objects in the deck.
     */
    public ArrayList<StarterCard> getCards() {
        return this.cards;
    }
}
