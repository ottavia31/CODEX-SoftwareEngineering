package it.polimi.ingsw.model;
/**
 * This enum represents the colors that a pawn can have in the game.
 * Each color is represented as a separate enum constant.
 */
public enum PawnColor {
    /**
     * Represents the color red.
     */
    RED,

    /**
     * Represents the color blue.
     */
    BLUE,

    /**
     * Represents the color green.
     */
    GREEN,

    /**
     * Represents the color yellow.
     */
    YELLOW
}