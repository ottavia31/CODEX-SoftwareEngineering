package it.polimi.ingsw.network.DoneMessages;

import it.polimi.ingsw.controller.State;
/**
 * Represents a message indicating a turn update in the game, extending from the DoneMessage class.
 * This class encapsulates information about the player taking the turn.
 */
public class TurnMessage extends DoneMessage{
    private final String player;

    /**
     * Constructs a TurnMessage object with the specified game state and player.
     *
     * @param state  the updated game state after the turn
     * @param player the player who is taking the turn
     */
    public TurnMessage(State state, String player){
        super(ConfirmAction.TURN_UPDATE, state);
        this.player = player;
    }

    /**
     * Retrieves the nickname of the player who is taking the turn.
     *
     * @return the nickname of the player taking the turn
     */
    public String getNickname(){ return this.player;}

}
