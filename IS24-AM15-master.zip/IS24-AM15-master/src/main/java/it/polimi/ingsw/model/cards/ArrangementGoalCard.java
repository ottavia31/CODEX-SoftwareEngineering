package it.polimi.ingsw.model.cards;

import it.polimi.ingsw.model.Coordinates;
import it.polimi.ingsw.model.Player;
import it.polimi.ingsw.model.Symbol;

import java.io.Serializable;
import java.util.Map;
/**
 * This class represents an ArrangementGoalCard in the game. It extends the GoalCard class and
 * contains additional properties such as isDiagonal and color.
 */
public class ArrangementGoalCard extends GoalCard implements Serializable {
    private final boolean isDiagonal;
    private final Symbol color;

    /**
     * Constructor for the ArrangementGoalCard class.
     * @param id The unique identifier of the card.
     * @param points The points associated with the card.
     * @param isDiagonal A boolean indicating if the arrangement is diagonal.
     * @param color The color associated with the card.
     */
    public ArrangementGoalCard(int id, int points, boolean isDiagonal, Symbol color) {
        super(id, points);
        this.isDiagonal = isDiagonal;
        this.color = color;
    }
    /**
     * Returns whether the arrangement is diagonal.
     * @return A boolean indicating if the arrangement is diagonal.
     */
    public Symbol getColor() {
        return color;
    }

    /**
     * Calculates the final goal points for a player.
     * @param player The player for whom the points are calculated.
     * @return The final goal points for the player.
     */
    @Override
    public int finalGoalPoints(Player player) {
        int points=0;
        Map <Coordinates, Card> configuration = player.getPersonalBoard().getConfiguration();
        //scorro su ogni carta della mappa
        for(Coordinates coordinates: configuration.keySet()){
            Card card = configuration.get(coordinates);
            Coordinates starterCoord = new Coordinates(0,0);
            if(!coordinates.equals(starterCoord)){ //se non è una starter card
                if (card.getColor().equals(color)) { //se la carta è del colore giusto
                    Coordinates UL = new Coordinates(coordinates.getX() - 1, coordinates.getY() + 1);
                    Coordinates UR = new Coordinates(coordinates.getX() + 1, coordinates.getY() + 1);
                    Coordinates DL = new Coordinates(coordinates.getX() - 1, coordinates.getY() - 1);
                    Coordinates DR = new Coordinates(coordinates.getX() + 1, coordinates.getY() - 1);
                    Coordinates UP = new Coordinates(coordinates.getX(), coordinates.getY() + 2);
                    Coordinates DOWN  = new Coordinates(coordinates.getX(), coordinates.getY() -2);
                    //caso diagonale verde o viola
                    if (isDiagonal&&(card.getColor().equals(Symbol.GREEN) || card.getColor().equals(Symbol.PURPLE))) {
                        if (!UL.equals(starterCoord) && configuration.get(UL) != null && configuration.get(UL).getColor().equals(this.color)) {
                            if (!DR.equals(starterCoord) && configuration.get(DR) != null && configuration.get(DR).getColor().equals(this.color))
                                points++;
                        }
                    }
                    //caso diagonale rosso o blu
                    if (isDiagonal&&(card.getColor().equals(Symbol.RED) || card.getColor().equals(Symbol.BLUE))) {
                        if (!UR.equals(starterCoord)&& configuration.get(UR) != null && configuration.get(UR).getColor().equals(this.color)) {
                            if (!DL.equals(starterCoord)&& configuration.get(DL) != null && configuration.get(DL).getColor().equals(this.color))
                                points++;
                        }
                    }
                    //caso non diagonale rosso
                    if (!isDiagonal&&this.color.equals(Symbol.RED)) {
                        if (!UP.equals(starterCoord)
                                && configuration.get(UP) != null
                                && !DR.equals(starterCoord)
                                && configuration.get(DR) != null
                                &&configuration.get(UP).getColor().equals(Symbol.RED)
                                &&configuration.get(DR).getColor().equals(Symbol.GREEN))
                            points++;
                    }
                    //caso non diagonale verde
                    if (!isDiagonal&&this.color.equals(Symbol.GREEN)) {
                        if (!UP.equals(starterCoord)
                                &&!DL.equals(starterCoord)
                                && configuration.get(UP) != null
                                && configuration.get(DL) != null
                                && configuration.get(UP).getColor().equals(Symbol.GREEN)
                                && configuration.get(DL).getColor().equals(Symbol.PURPLE))
                            points++;
                    }
                    //caso non diagonale viola
                    if (!isDiagonal&&this.color.equals(Symbol.PURPLE)) {
                        if (!DOWN.equals(starterCoord)
                                &&!UL.equals(starterCoord)
                                && configuration.get(DOWN) != null
                                && configuration.get(UL) != null
                                && configuration.get(DOWN).getColor().equals(Symbol.PURPLE)
                                && configuration.get(UL).getColor().equals(Symbol.BLUE))
                            points++;
                    }
                    //caso non diagonale blu
                    if (!isDiagonal&&this.color.equals(Symbol.BLUE)) {
                        if (!DOWN.equals(starterCoord)
                                && !UR.equals(starterCoord)
                                && configuration.get(DOWN) != null
                                && configuration.get(UR) != null
                                && configuration.get(DOWN).getColor().equals(Symbol.BLUE)
                                && configuration.get(UR).getColor().equals(Symbol.RED))
                            points++;
                    }
                }
            }
        }
        return points*this.getPoints();
        //TODO aggiungere controllo: stessa carta non può essere contata due volte
    }

    public boolean isDiagonal() {
        return isDiagonal;
    }
}
