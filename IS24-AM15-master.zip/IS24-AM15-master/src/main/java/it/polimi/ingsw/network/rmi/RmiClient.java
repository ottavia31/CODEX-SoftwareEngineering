package it.polimi.ingsw.network.rmi;

import it.polimi.ingsw.controller.State;
import it.polimi.ingsw.localModel.ModelView;
import it.polimi.ingsw.model.PawnColor;
import it.polimi.ingsw.model.exceptions.DeckFinishedException;
import it.polimi.ingsw.network.Client;
import it.polimi.ingsw.network.DoneMessages.*;
import it.polimi.ingsw.network.Update;
import it.polimi.ingsw.network.VirtualServer;
import it.polimi.ingsw.view.ViewController;

import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Queue;

import static java.lang.Integer.parseInt;

/**
 * Remote Client implementation using RMI (Remote Method Invocation).
 * This class handles interactions between the client and the server via RMI,
 * providing methods to communicate game updates, handle user inputs, and manage state transitions.
 */
public class RmiClient extends UnicastRemoteObject implements Client {
    private VirtualServer server;
    private ViewController view;
    private String nickname;
    private Update update;
    private final Queue<DoneMessage> messages = new ArrayDeque<>();
    private final Queue<String> inputQueue = new ArrayDeque<>();

    /**
     * Constructs an RmiClient object.
     *
     * @throws RemoteException if there is an RMI communication-related exception.
     */
    public RmiClient() throws RemoteException {
        this.nickname = "newPlayer";
    }

    /**
     * Handles incoming DoneMessage from the server.
     *
     * @param message the DoneMessage received from the server.
     * @throws RemoteException if there is an RMI communication-related exception.
     */
    @Override
    public void doneHandler(DoneMessage message)  throws RemoteException {
        State oldState = this.update.getState();
        String oldCurrentPlayer = this.update.getModelView().getCurrentPlayer();
        switch (message.getType()) {
            case ADD_PLAYER_CONFIRM -> {
                if(this.nickname == "newPlayer")
                    this.nickname = ((UpdateNewPlayerMessage)message).getNickname();
                update.modifyModel((UpdateNewPlayerMessage) message);
                update.getModelView().updateState(message.getState());
            }
            case NUM_PLAYER_CONFIRM -> {
                update.modifyModel((UpdateNumPlayersMessage) message);
                update.getModelView().updateState(message.getState());
            }
            case ADD_PLAYER_ERROR -> {
                update.updateState(State.STARTED);
                if (this.nickname == "newPlayer") {
                    System.out.println("Nickname già scelto, inseriscine un altro:  ");
                }
            }

            case SETUP_GAME_CONFIRM -> {
                update.modifyModel((UpdateSetupGameMessage) message);
                update.updateState(State.GAME_SETTED);
                update.getModelView().updateState(message.getState());
            }
            case UPDATE_PERSONAL_DECK -> {
                update.modifyModel((UpdatePersonalDeckMessage) message);
                if(this.getModelView().getState().equals(State.THROWN)) {
                    view.print("You've drawn this card: ");
                    view.printCard(((UpdatePersonalDeckMessage) message).getId(), false);
                }
            }

            case SECRET_GOAL_CARD ->
                    update.modifyModel((UpdateGoalCardMessage) message);

            case TURN_STATE_UPDATE -> update.modifyModel((UpdateStateAndTurnMessage) message);

            case STARTER_CARD -> update.modifyModel((UpdateStarterCardMessage) message);

            case CHOOSEN_PAWN -> update.modifyModel((UpdatePawnColorMessage) message);
            case CHOOSE_PAWN_ERROR -> System.out.println("pedina già scelta, scegli un altro colore");
            case GOLD_DECK_UPDATE -> update.modifyModel((UpdateGoldDeckMessage) message);
            case RESOURCE_DECK_UPDATE -> update.modifyModel((UpdateResourceDeckMessage) message);
            case FACEDUP_CARDS_UPDATE -> update.modifyModel((UpdateFacedupCardsMessage) message);
            case TURN_UPDATE -> {
                update.modifyModel((TurnMessage) message);
                System.out.println("è il turno di " + ((TurnMessage) message).getNickname());
            }
            case MESSAGE -> {
                NewMessage message1 = ((NewMessage) message);
                System.out.println(message1.getSender() + " ti ha mandato il seguente messaggio: " + message1.getMessage());
            }
            case SHOW_CHAT ->{
                ShowChatMessage message1 = ((ShowChatMessage) message);
                if(message1.getMessages().isEmpty()){
                    System.out.println("not messages yet");
                }
                for (String element : message1.getMessages()) {
                    System.out.println(element);
                }
            }

            case PLAY_CARD_CONFIRM -> update.modifyModel((UpdatePersonalBoardMessage) message);
            case REMOVED_FROM_PERSONAL_DECK -> update.modifyModel((UpdateCardRemoved) message);
            case GAME_STATE -> //System.out.println("notifico all'update che sono nello stato" + ((UpdateGameStateMessage) message).getState());
                    update.modifyModel((UpdateGameStateMessage) message);
            case NUM_PLAYER_ERROR -> System.err.println("You can only choose between 2 and 4 players");
            case PLAY_CARD_ERROR -> System.err.println(((ErrorMessage)message).getPossibleErrors());
            case DISCONNECTION -> {
                System.out.println("The game has been interrupted because one of the player quit, disconnecting from the game...");
                System.exit(0);
            }
        }

        if (this.update.getModelView().getCurrentPlayer() == null || oldCurrentPlayer == null && this.update.getModelView().getCurrentPlayer() != null || !oldState.equals(update.getState())) {
            this.view.update(message.getState());
        } else {
            assert oldCurrentPlayer != null;
            if (!oldCurrentPlayer.equals(this.update.getModelView().getCurrentPlayer())) {
                this.view.update(this.update.getState());
            }
        }

    }

    /**
     * Handles user input received from the client interface.
     *
     * @param input the user input received.
     * @throws RemoteException if there is an RMI communication-related exception.
     */
    @Override
    public void inputHandler(String input) throws RemoteException {
        if (input.equals("exit")) {
            System.exit(0);

        }else if (input.startsWith("CHAT WITH")) {
            String[] parts = input.split(" ", 4);
            if (parts.length < 3) {
                System.out.println("Invalid chat command. Use 'CHAT WITH <player> <message>' or 'CHAT WITH EVERYONE <message>'");
            } else {
                handleChatInput(parts);
            }

        }else if(input.startsWith("SHOW CHAT WITH")){
            String[] parts = input.split(" ", 4);
            if (parts.length != 4) {
                System.out.println("Invalid show chat command. Use 'SHOW CHAT WITH <player> ' or 'SHOW CHAT WITH EVERYONE'");
            } else {
                handleShowChatInput(parts);
            }

        } else {
            if (!update.getModelView().getCurrentPlayer().equals(this.nickname)
                    && update.getState() != State.STARTED
                    && update.getState() != State.NUM_SETTED
                    && update.getState() != State.PLAYER_ADDED
                    && update.getState() != State.FIRST_PLAYER_ADDED
                    && update.getState() != State.LAST_TURN_COMPLETED) {
                view.reportError("Wait, it's" + update.getModelView().getCurrentPlayer() + "'s turn\n");
            } else {

                switch (update.getState()) {
                    case STARTED, NUM_SETTED, PLAYER_ADDED -> {
                        if (this.nickname.equals("newPlayer")) {
                            setNickname(input);
                        }
                    }

                    case FIRST_PLAYER_ADDED -> {
                        setFirstPlayer();
                        setNumPlayers(input);
                    }
                    case GAME_SETTED -> {
                        if (update.getModelView().getCurrentPlayer().equals(this.nickname)) {
                            this.choosePawn(input);
                        } else {
                            view.reportError("Wait, it's" + update.getModelView().getCurrentPlayer() + "'s turn\n");
                        }
                    }
                    case ALL_PAWNS_SETTED -> {
                        if (update.getModelView().getCurrentPlayer().equals(this.nickname)) {
                            if (input.equals("front")) {
                                playStarterCard(false);
                            } else if (input.equals("back")) {
                                playStarterCard(true);
                            } else {
                                view.reportError("Invalid input, choose between front and back\n");
                                this.view.update(getState());
                            }

                        } else {
                            view.reportError("Wait, it's" + update.getModelView().getCurrentPlayer() + "'s turn\n");
                        }

                    }
                    case STARTER_CARD_PLAYED -> {
                        int i;
                        try {
                            i = parseInt(input);
                        } catch (NumberFormatException e) {
                            i = 0;
                        }
                        if (i == 1 || i == 2) {
                            try {
                                this.server.chooseSecretGoal(i, nickname);
                            } catch (RemoteException e) {
                                view.reportError("Connection lost, disconnecting from the game...");
                            }
                        } else {
                            view.reportError("Choose between 1 and 2:\n");
                        }

                    }
                    case ALL_SECRET_GOALS_SETTED, DRAWN -> {
                        String[] parts = input.split(" ");
                        if (parts.length != 4) {
                            view.reportError("Invalid input, please provide three integers separated by spaces and a side:\n");
                            return;
                        }
                        int i1, i2, i3;
                        try {
                            i1 = Integer.parseInt(parts[0]);
                            i2 = Integer.parseInt(parts[1]);
                            i3 = Integer.parseInt(parts[2]);
                        } catch (NumberFormatException e) {
                            view.reportError("Invalid input, please enter three integers separated by spaces:\n");
                            return;
                        }

                        String side = parts[3];
                        boolean isBack;
                        if (side.equals("front"))
                            isBack = false;
                        else if (side.equals("back"))
                            isBack = true;
                        else {
                            view.reportError("Invalid input, choose between front and back");
                            return;
                        }

                        if (i1 == 1 || i1 == 2 || i1 == 3) {
                            try {
                                this.server.playPlayCard(i1, i2, i3, isBack, nickname);
                            } catch (RemoteException e) {
                                view.reportError("Connection lost, disconnecting from the game...");

                            }
                        } else {
                            view.reportError("Choose between 1, 2, and 3 for each input\n");
                        }

                    }
                    case THROWN -> {
                        int i;
                        try {
                            i = parseInt(input);
                        } catch (NumberFormatException e) {
                            view.reportError("Invalid input, please enter an integer between 1 and 6:\n");
                            return;
                        }
                        try {
                            if (i == 1) {
                                this.server.drawResourceCard();
                            } else if (i == 2) {
                                this.server.drawGoldCard();
                            } else if (i == 3) {
                                this.server.drawFacedUpCard(0);
                            } else if (i == 4) {
                                this.server.drawFacedUpCard(1);
                            } else if (i == 5) {
                                this.server.drawFacedUpCard(2);
                            } else if (i == 6) {
                                this.server.drawFacedUpCard(3);
                            } else {
                                view.reportError("Choose between 1, 2, 3, 4, 5, 6\n");
                            }
                        } catch (RemoteException e) {
                            view.reportError("Connection lost, disconnecting from the game...");
                        }
                    }
                    case LAST_TURN_COMPLETED -> {
                        if (input.equals("winner")) {
                            ArrayList<String> winners;
                            try {
                                winners = server.getWinners();
                            } catch (RemoteException e){
                                view.reportError("Connection lost, disconnecting from the game...");
                                return;
                            }
                            if (winners.contains(nickname)) {
                                view.print("You are the winner!");
                            } else {
                                for (String winner : winners) {
                                    view.print(winner + " is the winner!");
                                }

                            }
                        } else {
                            view.reportError("Invalid input, type 'winner' to see the winner\n");
                        }
                    }

                }
            }
        }

    }

    /**
     * Handles the SHOW CHAT command input from the client.
     *
     * @param parts an array of String parts from the SHOW CHAT command.
     * @throws RemoteException if there is an RMI communication-related exception.
     */
    private void handleShowChatInput(String[] parts) throws RemoteException {
        String player1 = parts[3];
        String player2 = this.nickname;
        if (player1.equals("EVERYONE")) {
            try {
                server.showPublicChat(player2);
            } catch (RemoteException e) {
                view.reportError("Connection lost, disconnecting from the game...");
            }
        } else if (!this.update.getModelView().getPlayers().containsKey(player1)) {
            this.view.reportError("The player you chose does not exist");
        } else {
            try {
                server.showPrivateChat(player1, player2);
            } catch (RemoteException e) {
                view.reportError("Connection lost, disconnecting from the game...");
            }
        }
    }

    /**
     * Sets the first player in the game.
     *
     * @throws RemoteException if there is an RMI communication-related exception.
     */
    @Override
    public void setFirstPlayer() throws RemoteException {
        try {
            server.setFirstPlayer();
        } catch (RemoteException e) {
            view.reportError("Connection lost, disconnecting from the game...");
        }
    }

    /**
     * Plays the starter card with the specified orientation.
     *
     * @param isBack true if the starter card is played facing back, false if facing front.
     * @throws RemoteException if there is an RMI communication-related exception.
     */
    @Override
    public void playStarterCard(boolean isBack) throws RemoteException {
        try {
            server.playStarterCard(isBack);
        } catch (RemoteException e) {
            view.reportError("Connection lost, disconnecting from the game...");
        }
    }

    /**
     * Retrieves the current game update object.
     *
     * @return the current game update object.
     */
    public Update getUpdate() {
        return update;
    }

    /**
     * Sets the nickname for the client.
     *
     * @param nickname the nickname to set for the client.
     * @throws RemoteException if there is an RMI communication-related exception.
     */
    public void setNickname(String nickname) throws RemoteException {
        try {
            server.setNickname(nickname);
        } catch (RemoteException e) {
            view.reportError("Connection lost, disconnecting from the game...");
        }
    }

    /**
     * Retrieves the nickname of the client.
     *
     * @return the nickname of the client.
     * @throws RemoteException if there is an RMI communication-related exception.
     */
    @Override
    public String getNickname() throws RemoteException {
        return this.nickname;
    }

    /**
     * Sets the number of players for the game.
     *
     * @param input the input specifying the number of players.
     * @throws RemoteException if there is an RMI communication-related exception.
     */
    @Override
    public synchronized void setNumPlayers(String input) throws RemoteException {
        try {
            Integer number = Integer.parseInt(input);
            server.setNumPlayers(number);
        } catch (IllegalArgumentException e) {
            System.out.println("Error setting number of players: " + e.getMessage());
            this.view.update(this.update.getState());
        } catch (RemoteException e) {
            view.reportError("Connection lost, disconnecting from the game...");
        }
    }

    /**
     * Retrieves the current state of the game.
     *
     * @return the current state of the game.
     * @throws RemoteException if there is an RMI communication-related exception.
     */
    @Override
    public State getState() throws RemoteException {
        return this.getModelView().getState();
    }

    /**
     * Retrieves the current model view of the game.
     *
     * @return the current model view of the game.
     * @throws RemoteException if there is an RMI communication-related exception.
     */
    @Override
    public ModelView getModelView() throws RemoteException {
        return this.update.getModelView();
    }

    /**
     * Retrieves the list of available pawn colors.
     *
     * @return the list of available pawn colors.
     * @throws RemoteException if there is an RMI communication-related exception.
     */
    @Override
    public ArrayList<PawnColor> getAvaiableColors() throws RemoteException {
        return this.server.getAvaiableColors();
    }

    @Override
    public void setCurrentPlayer(String player) throws RemoteException {
        this.update.getModelView().setCurrentPlayer(player);
    }

    /**
     * Chooses a pawn color for the client.
     *
     * @param input the input specifying the pawn color.
     * @throws RemoteException if there is an RMI communication-related exception.
     */
    public void choosePawn(String input) throws RemoteException {
        String pawn = input.toUpperCase();
        try {
            switch (pawn) {
                case "RED":
                    this.server.setPawn(PawnColor.RED, this.nickname);
                    break;
                case "BLUE":
                    this.server.setPawn(PawnColor.BLUE, this.nickname);
                    break;
                case "YELLOW":
                    this.server.setPawn(PawnColor.YELLOW, this.nickname);
                    break;
                case "GREEN":
                    this.server.setPawn(PawnColor.GREEN, this.nickname);
                    break;
                default:
                    view.reportError("The color you chose is not valid!\n");
                    view.update(getState());
                    break;
            }
        } catch (RemoteException e) {
            view.reportError("Connection lost, disconnecting from the game...");
        }
    }

    /**
     * Adds a DoneMessage to the client's message queue.
     *
     * @param message the DoneMessage to add.
     * @throws RemoteException if there is an RMI communication-related exception.
     */
    public void addMessage(DoneMessage message) throws RemoteException {
        synchronized (messages) {
            messages.add(message);
            messages.notify();
        }
    }

    /**
     * Adds user input to the client's input queue.
     *
     * @param input the input to add.
     * @throws RemoteException if there is an RMI communication-related exception.
     */
    @Override
    public void addInput(String input) throws RemoteException {
        synchronized (inputQueue) {
            inputQueue.add(input);
            inputQueue.notify();
        }
    }

    /**
     * Handles the chat command input from the client.
     *
     * @param parts an array of String parts from the chat command.
     * @throws RemoteException if there is an RMI communication-related exception.
     */
    private void handleChatInput(String[] parts) throws RemoteException {
        if (parts.length < 4) {
            this.view.reportError("The format you used for the chat is not valid");
        } else {
            String target = parts[2];
            String message = parts[3];

            if (target.equalsIgnoreCase("EVERYONE")) {
                try {
                    server.sendPublicMessage(nickname, message);
                } catch (RemoteException e) {
                    view.reportError("Connection lost, disconnecting from the game...");
                }
            } else {
                if (this.getUpdate().getModelView().getPlayers().containsKey(target)) {
                    try {
                        server.sendPrivateMessage(this.nickname, target, message);
                    } catch (RemoteException e) {
                        view.reportError("Connection lost, disconnecting from the game...");
                    }
                } else {
                    System.out.println("Player not found: " + target);
                }
            }
        }
    }

    /**
     * Handles the ping command to keep the connection active.
     *
     * @throws RemoteException if there is an RMI communication-related exception.
     */
    @Override
    public void ping() throws RemoteException {
        // Method to maintain connection, no implementation required here.
    }

    /**
     * Starts the RMI client with the specified host, port, and view controller.
     *
     * @param host           the host address of the RMI server.
     * @param port           the port number of the RMI server.
     * @param viewController the view controller for the client.
     * @throws RemoteException    if there is an RMI communication-related exception.
     * @throws NotBoundException  if the specified name in the registry is not currently bound.
     * @throws MalformedURLException if the specified URL is invalid.
     * @throws InterruptedException if the thread is interrupted during sleep.
     * @throws DeckFinishedException if there is an exception related to the deck being finished.
     */
    public void start(String host, int port, ViewController viewController) throws RemoteException, NotBoundException, MalformedURLException, InterruptedException, DeckFinishedException {
        // Locate the RMI registry at the specified host and port
        Registry registry = LocateRegistry.getRegistry(host, port);
        VirtualServer server;
        try {
            server = (VirtualServer) registry.lookup("VirtualServer");
        } catch (RemoteException e) {
            System.out.println("Server not found, closing...");
            System.exit(0);
            return; // Exit method after closing
        }

        this.server = server;

        // Check if the game is full or not ready yet
        if (server.getNumPlayers() == server.getNumPlayersConnected()) {
            System.out.println("The game is full, disconnecting from the game...");
            System.exit(0);
            return; // Exit method after closing
        }
        if (server.getNumPlayers() == 5 && server.getNumPlayersConnected() == 1) {
            System.out.println("The game is not ready yet, disconnecting from the game...");
            System.exit(0);
            return; // Exit method after closing
        }



        // Set the view controller and initialize update object
        this.view = viewController;
        this.update = new Update();

        // Start a new thread to handle server ping at regular intervals
        VirtualServer finalServer = server;
        new Thread(() -> {
            while (true) {
                try {
                    finalServer.ping();
                } catch (RemoteException e) {
                    view.reportError("The connection with the server was lost, disconnecting from the game...");
                    System.exit(0); // Exit the application
                }

                try {
                    Thread.sleep(10000); // Ping interval
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();

        // Start a new thread to handle incoming messages from the server
        Thread messageHandlerThread = new Thread(() -> {
            while (true) {
                DoneMessage message;
                synchronized (messages) {
                    while (messages.isEmpty()) {
                        try {
                            messages.wait();
                        } catch (InterruptedException e) {
                            Thread.currentThread().interrupt();
                            return;
                        }
                    }
                    message = messages.poll();
                }
                try {
                    doneHandler(message);
                } catch (RemoteException e) {
                    System.out.println("Error handling message: " + e.getMessage());
                }
            }
        });
        messageHandlerThread.start();

        // Start a new thread to handle user inputs
        Thread inputHandlerThread = new Thread(() -> {
            while (true) {
                String input;
                synchronized (inputQueue) {
                    while (inputQueue.isEmpty()) {
                        try {
                            inputQueue.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    input = inputQueue.poll();
                }
                try {
                    inputHandler(input);
                } catch (RemoteException e) {
                    System.out.println("Error handling input: " + e.getMessage());
                }
            }
        });
        inputHandlerThread.start();
        // Connect the client to the server
        server.connect(this);
        // Run the view controller with this client instance
        this.view.run(this);
    }
}
