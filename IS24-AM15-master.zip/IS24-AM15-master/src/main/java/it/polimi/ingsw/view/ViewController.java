package it.polimi.ingsw.view;

import it.polimi.ingsw.controller.State;
import it.polimi.ingsw.model.exceptions.DeckFinishedException;
import it.polimi.ingsw.network.Client;

import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;


/**
 * Interface defining methods for handling client-side view interactions in a game.
 */
public interface ViewController {

    /**
     * Starts the client view interaction.
     *
     * @param client The client instance connected to the server.
     * @throws RemoteException      If a network-related error occurs.
     * @throws InterruptedException If the thread is interrupted.
     * @throws MalformedURLException If there is an issue with the URL.
     * @throws DeckFinishedException If the deck of cards is finished.
     * @throws NotBoundException    If an RMI object is not found in the registry.
     */
    void run(Client client) throws RemoteException, InterruptedException, MalformedURLException, DeckFinishedException, NotBoundException;

    /**
     * Prints a string message to the client's output.
     *
     * @param string The string message to print.
     */
    void print(String string);

    /**
     * Reports an error message to the client.
     *
     * @param s The error message to report.
     */
    void reportError(String s);

    /**
     * Updates the client view based on the new state received.
     *
     * @param state The updated state of the game.
     * @throws RemoteException If a network-related error occurs.
     */
    void update(State state) throws RemoteException;

    /**
     * Prints information about a card to the client's output.
     *
     * @param id         The ID of the card.
     * @param isbackSide True if the back side of the card is being printed, false otherwise.
     */
    void printCard(int id, boolean isbackSide);
}