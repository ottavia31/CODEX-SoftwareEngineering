package it.polimi.ingsw.network.DoneMessages;

import it.polimi.ingsw.controller.State;

/**
 * Represents a message indicating an update to the game state.
 * Extends {@link DoneMessage}, specifying the updated game state.
 */
public class UpdateGameStateMessage extends DoneMessage {

    /**
     * Constructs a new UpdateGameStateMessage with the specified game state.
     *
     * @param state the updated game state.
     */
    public UpdateGameStateMessage(State state) {
        super(ConfirmAction.GAME_STATE, state);
    }
}