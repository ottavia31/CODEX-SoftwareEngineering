package it.polimi.ingsw.model.cards;

import it.polimi.ingsw.model.Symbol;

import java.io.Serializable;
import java.util.Map;
/**
 * This class represents a PlayCard in the game. It extends the Card class and
 * contains additional properties such as isBackSide, color, corners, points, and id.
 */
public class PlayCard extends Card implements Serializable {
    private boolean isBackSide;
    private final Symbol color;
    private final Map<String, Symbol> corners;
    private final int points;
    private final int id;


    /**
     * Constructs a PlayCard with the specified id, color, corners, and points.
     */

    public PlayCard(int id, Symbol color, Map<String, Symbol> corners, int points) {
        this.isBackSide = false;
        this.color = color;
        this.corners = corners;
        this.points = points;
        this.id = id;
    }
    /**
     * Returns whether the card is flipped to its back side.
     */
    public boolean isBackSide() {
        return isBackSide;
    }

    /**
     * Returns the color of the card.
     */
    @Override
    public Symbol getColor() {
        return color;
    }
    /**
     * Returns the id of the card.
     */
    @Override
    public int getId() {
        return id;
    }

    /**
     * Returns the symbols at the corners of the card.
     */
    public Map<String, Symbol> getCorners() {
        return corners;
    }
    /**
     * Returns the points of the card.
     */
    public int getPoints() {
        return points;
    }
    /**
     * Flips the card to its other side.
     */
    public void flip() {
        this.isBackSide = !this.isBackSide;
    }
    /**
     * Sets whether the card is flipped to its back side.
     */
    public void setBackSide(boolean b) {
        this.isBackSide = b;
    }

    /**
     * Sets the back side status of the card.
     */
    public void setBack(Boolean isBack) {
        this.isBackSide = isBack;
    }
}
