package it.polimi.ingsw.model.exceptions;

/**
 * This exception is thrown when a card covers two corners of the same card.
 * However, this exception might be unnecessary because a card that covers two corners
 * of the same card will never have adjacent cards.
 * Therefore, this situation is handled by NoCardAdjacentException.
 * But this exception is kept to provide two different error messages.
 */
public class TwoCornersException extends Exception{
    /**
     * Constructs a new TwoCornersException with the specified detail message.
     *
     * @param message the detail message. The detail message is saved for
     *                later retrieval by the Throwable.getMessage() method.
     */
    public TwoCornersException(String message) {
        super(message);
    }
}