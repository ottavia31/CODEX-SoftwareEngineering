package it.polimi.ingsw.model;

import java.util.ArrayList;

/**
 * This class represents a chat between players in the game.
 */
public class Chat {
    private final String p1;
    private final String p2;
    private final ArrayList<String> chat;

    /**
     * Constructs a new Chat object.
     *
     * @param p1 the first player
     * @param p2 the second player
     * @param sender the sender of the first message
     * @param message the first message
     */
    public Chat(String p1, String p2, String sender, String message){
        this.p1 = p1;
        this.p2 = p2;
        this.chat = new ArrayList<>();
        this.chat.add(sender + ":" + " " + message);
    }

    /**
     * Adds a new message to the chat.
     *
     * @param sender the sender of the message
     * @param message the message
     */
    public void addMessage(String sender, String message){
        this.chat.add(sender + ":" + " " + message);
    }

    /**
     * Returns the chat history.
     *
     * @return an ArrayList containing the chat history
     */
    public ArrayList<String> getChat(){
        return this.chat;
    }

    /**
     * Returns the first player.
     *
     * @return a String representing the first player
     */
    public String getP1(){
        return this.p1;
    }

    /**
     * Returns the second player.
     *
     * @return a String representing the second player
     */
    public String getP2(){
        return this.p2;
    }
}