package it.polimi.ingsw.model.cards;

import it.polimi.ingsw.model.Symbol;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Map;
/**
 * This class represents a GoldCard in the game. It extends the PlayCard class and
 * contains additional attributes and methods specific to a GoldCard.
 */
public class GoldCard extends PlayCard implements Serializable {
    private final ArrayList<Symbol> conditionsToUse;
    private final Symbol goal;

    /**
     * Constructs a new GoldCard with the specified parameters.
     *
     * @param id The unique identifier of this card.
     * @param color The color of this card.
     * @param corners The symbols at the corners of this card.
     * @param points The points of this card.
     * @param conditionsToUse The conditions to use this card.
     * @param goal The goal symbol of this card.
     */
    public GoldCard(int id, Symbol color, Map<String, Symbol> corners, int points, ArrayList<Symbol> conditionsToUse, Symbol goal) {
        super(id, color, corners, points);
        this.conditionsToUse = conditionsToUse;
        this.goal = goal;
    }
    /**
     * Returns the conditions to use this card.
     *
     * @return The conditions to use this card.
     */
    public ArrayList<Symbol> getConditionsToUse() {
        return conditionsToUse;
    }

    /**
     * Returns the goal symbol of this card.
     *
     * @return The goal symbol of this card.
     */
    public Symbol getGoal() {
        return goal;
    }
}

