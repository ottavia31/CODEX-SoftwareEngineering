package it.polimi.ingsw.network.DoneMessages;

import it.polimi.ingsw.controller.State;
import it.polimi.ingsw.model.Symbol;
import java.util.ArrayList;

/**
 * Represents a message indicating the setup of the game.
 * Extends {@link DoneMessage}.
 */
public class UpdateSetupGameMessage extends DoneMessage {

    private final Symbol resourceTopCardColor;
    private final Symbol goldTopCardColor;
    private final ArrayList<Integer> facedUpCards;
    private final ArrayList<Integer> goals;
    private final String currentPlayer;
    private final ArrayList<String> players;

    /**
     * Constructs an UpdateSetupGameMessage object.
     *
     * @param state               the state associated with this message
     * @param currentPlayer       the current player in the game setup
     * @param players             the list of players in the game
     * @param resourceTopCardColor the top card color of the resource deck
     * @param goldTopCardColor     the top card color of the gold deck
     * @param facedUpCards         the list of faced-up cards
     * @param goals                the list of secret goal cards
     */
    public UpdateSetupGameMessage(State state, String currentPlayer, ArrayList<String> players, Symbol resourceTopCardColor, Symbol goldTopCardColor, ArrayList<Integer> facedUpCards, ArrayList<Integer> goals) {
        super(ConfirmAction.SETUP_GAME_CONFIRM, state);
        this.currentPlayer = currentPlayer;
        this.resourceTopCardColor = resourceTopCardColor;
        this.goldTopCardColor = goldTopCardColor;
        this.facedUpCards = facedUpCards;
        this.goals = goals;
        this.players = players;
    }

    /**
     * Retrieves the list of players in the game setup.
     *
     * @return the list of players
     */
    public ArrayList<String> getPlayers() {
        return this.players;
    }

    /**
     * Retrieves the top card color of the resource deck.
     *
     * @return the resource top card color
     */
    public Symbol getResourceTopCardColor() {
        return resourceTopCardColor;
    }

    /**
     * Retrieves the top card color of the gold deck.
     *
     * @return the gold top card color
     */
    public Symbol getGoldTopCardColor() {
        return goldTopCardColor;
    }

    /**
     * Retrieves the list of faced-up cards.
     *
     * @return the list of faced-up cards
     */
    public ArrayList<Integer> getFacedUpCards() {
        return facedUpCards;
    }

    /**
     * Retrieves the list of secret goal cards.
     *
     * @return the list of secret goal cards
     */
    public ArrayList<Integer> getGoals() {
        return goals;
    }

    /**
     * Retrieves the current player in the game setup.
     *
     * @return the current player
     */
    public String getCurrentPlayer() {
        return currentPlayer;
    }
}
