package it.polimi.ingsw.network.DoneMessages;

import it.polimi.ingsw.controller.State;

import java.util.ArrayList;

/**
 * Represents a message containing a chat history to be displayed to the client.
 * Extends {@link DoneMessage}, adding a list of messages to be shown.
 */
public class ShowChatMessage extends DoneMessage {

    private final ArrayList<String> messages; // The list of chat messages to be shown

    /**
     * Constructs a new ShowChatMessage with the specified game state and list of messages.
     *
     * @param state the updated game state after receiving the chat message.
     * @param messages the list of chat messages to be shown.
     */
    public ShowChatMessage(State state, ArrayList<String> messages) {
        super(ConfirmAction.SHOW_CHAT, state);
        this.messages = messages;
    }

    /**
     * Retrieves the list of messages to be shown in the chat.
     *
     * @return the list of chat messages.
     */
    public ArrayList<String> getMessages() {
        return messages;
    }
}
