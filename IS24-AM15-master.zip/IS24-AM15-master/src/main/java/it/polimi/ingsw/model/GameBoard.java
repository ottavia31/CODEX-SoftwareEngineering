package it.polimi.ingsw.model;

import it.polimi.ingsw.controller.State;
import it.polimi.ingsw.model.cards.*;
import it.polimi.ingsw.model.exceptions.DeckFinishedException;
import it.polimi.ingsw.model.exceptions.MoreThanThreeCardsException;
import it.polimi.ingsw.model.exceptions.NoCardException;

import java.io.Serializable;
import java.util.*;

/**
 * This class represents the game board in the game. It is a singleton class, meaning there can only be one instance of it.
 * It contains all the decks of cards, the list of players, and other game state information.
 */
public class GameBoard implements Serializable {
    private static GameBoard instance;
    private ResourceDeck resourceDeck;
    private GoldDeck goldDeck;
    private final StarterDeck starterDeck;
    private final GoalDeck goalDeck;
    private Boolean isStarted;
    private Boolean isLastTurn;
    private Integer numPlayers;
    private final ArrayList<Player> players;
    private Player currentPlayer;
    private final HashMap<String, Integer> scoreTrack;
    private ArrayList<PlayCard> facedUpCards;
    private ArrayList<GoalCard> commonGoals;
    private Player firstPlayer;
    private Boolean completingRound;
    private final ArrayList<PawnColor> availableColors = new ArrayList<>(Arrays.asList(PawnColor.RED, PawnColor.GREEN, PawnColor.BLUE, PawnColor.YELLOW));
    private State state;

    /**
     * Returns the single instance of the GameBoard class.
     * If the instance does not exist, it is created.
     * @return the single instance of the GameBoard class.
     */
    public static GameBoard getInstance() {
        if (instance == null) {
            instance = new GameBoard();
        }
        return instance;
    }
    /**
     * Adds a resource card to the resource deck.
     * @param id the id of the card.
     * @param color the color of the card.
     * @param ul the symbol in the upper left corner of the card.
     * @param dl the symbol in the lower left corner of the card.
     * @param ur the symbol in the upper right corner of the card.
     * @param dr the symbol in the lower right corner of the card.
     * @param points the points of the card.
     */
    public void addResourceCard(int id, Symbol color, Symbol ul, Symbol dl, Symbol ur, Symbol dr, int points) {
        Map<String, Symbol> corners = new HashMap<>();
        corners.put("UL", ul);
        corners.put("DL", dl);
        corners.put("UR", ur);
        corners.put("DR", dr);

        ResourceCard card = new ResourceCard(id, color, corners, points);
        resourceDeck.getCards().add(card);
    }
    /**
     * Adds a GoldCard to the goldDeck.
     * @param id The id of the card.
     * @param color The color of the card.
     * @param ul The symbol in the upper left corner of the card.
     * @param dl The symbol at the down left corner of the card.
     * @param ur The symbol in the upper right corner of the card.
     * @param dr The symbol at the down right corner of the card.
     * @param points The points of the card.
     * @param conditionsToUse The conditions to use the card.
     * @param specialSymbol The special symbol of the card.
     */
    private void addGoldCard(int id, Symbol color, Symbol ul, Symbol dl, Symbol ur, Symbol dr, int points, List<Symbol> conditionsToUse, Symbol specialSymbol) {
        Map<String, Symbol> corners = new HashMap<>();
        corners.put("UL", ul);
        corners.put("DL", dl);
        corners.put("UR", ur);
        corners.put("DR", dr);

        GoldCard card = new GoldCard(id,color, corners, points, new ArrayList<>(conditionsToUse), specialSymbol);
        goldDeck.getCards().add(card);
    }

    /**
     * Adds a StarterCard to the starterDeck.
     * @param id The id of the card.
     * @param ulFront The symbol in the upper left corner of the front of the card.
     * @param dlFront The symbol at the down left corner of the front of the card.
     * @param urFront The symbol in the upper right corner of the front of the card.
     * @param drFront The symbol at the down right corner of the front of the card.
     * @param ulBack The symbol in the upper left corner of the back of the card.
     * @param dlBack The symbol at the down left corner of the back of the card.
     * @param urBack The symbol in the upper right corner of the back of the card.
     * @param drBack The symbol at the down right corner of the back of the card.
     * @param frontSymbol The symbols at the front of the card.
     */
    private void addStarterCard(int id, Symbol ulFront, Symbol dlFront, Symbol urFront, Symbol drFront, Symbol ulBack, Symbol dlBack, Symbol urBack, Symbol drBack, List<Symbol> frontSymbol) {
        Map<String, Symbol> frontCorners = new HashMap<>();
        frontCorners.put("UL", ulFront);
        frontCorners.put("DL", dlFront);
        frontCorners.put("UR", urFront);
        frontCorners.put("DR", drFront);

        Map<String, Symbol> backCorners = new HashMap<>();
        backCorners.put("UL", ulBack);
        backCorners.put("DL", dlBack);
        backCorners.put("UR", urBack);
        backCorners.put("DR", drBack);

        StarterCard card = new StarterCard(id, frontCorners, backCorners, new ArrayList<>(frontSymbol));
        starterDeck.getCards().add(card);
    }
    /**
     * Adds a SymbolsGoalCard to the goalDeck.
     * @param id The id of the card.
     * @param points The points of the card.
     * @param symbols The symbols of the card.
     */
    private void addSymbolsGoalCard(int id, int points, ArrayList<Symbol> symbols) {
        SymbolsGoalCard card = new SymbolsGoalCard(id, points, symbols);
        goalDeck.getCards().add(card);
    }
    /**
     * Adds an ArrangementGoalCard to the goalDeck.
     * @param id The id of the card.
     * @param points The points of the card.
     * @param isDiagonal Whether the arrangement is diagonal.
     * @param color The color of the card.
     */
    private void addArrangementGoalCard(int id, int points, boolean isDiagonal, Symbol color) {
        ArrangementGoalCard card = new ArrangementGoalCard(id, points, isDiagonal, color);
        goalDeck.getCards().add(card);
    }
    /**
     * Gets the available colors.
     * @return The available colors.
     */
    public ArrayList<PawnColor> getAvailableColors() {
        return availableColors;
    }
    /**
     * Gets the state.
     * @return The state.
     */
    public State getState() {
        return state;
    }
    /**
     * Sets the state.
     * @param state The state.
     */
    public void setState(State state) {
        this.state = state;
    }
    /**
     * Returns the number of players.
     * @return the number of players
     */
    public Integer getNumPlayers() {
        return numPlayers;
    }
    /**
     * Returns the resource deck.
     * @return the resource deck
     */
    public ResourceDeck getResourceDeck() {
        return this.resourceDeck;
    }
    /**
     * Returns the gold deck.
     * @return the gold deck
     */
    public GoldDeck getGoldDeck() {return goldDeck;}
    /**
     * Returns the goal deck.
     * @return the goal deck
     */
    public GoalDeck getGoalDeck(){
        return goalDeck;
    }
    /**
     * Returns the starter deck.
     * @return the starter deck
     */
    public StarterDeck getStarterDeck() {return starterDeck;}
    /**
     * Returns the list of players.
     * @return the list of players
     */
    public ArrayList<Player> getPlayers() {
        return players;
    }
    /**
     * Returns the current player.
     * @return the current player
     */
    public Player getCurrentPlayer() {
        return currentPlayer;
    }
    /**
     * Returns the list of faced up cards.
     * @return the list of faced up cards
     */
    public ArrayList<PlayCard> getFacedUpCards() {
        return facedUpCards;
    }
    /**
     * Returns the list of common goal cards.
     * @return the list of common goal cards
     */
    public ArrayList<GoalCard> getCommonGoals() {return commonGoals;}
    /**
     * Sets the list of common goal cards.
     * @param commonGoals the new list of common goal cards
     */
    public void setCommonGoals(ArrayList<GoalCard> commonGoals) {
        this.commonGoals = commonGoals;
    }
    /**
     * Returns the first player.
     * @return the first player
     */
    public Player getFirstPlayer() {
        return firstPlayer;
    }
    /**
     * Returns whether the game is in the completing round state.
     * @return true if the game is in the completing round state, false otherwise
     */
    public Boolean getCompletingRound() {
        return completingRound;
    }
    /**
     * Sets whether the game is in the completing round state.
     * @param completingRound the new state
     */
    public void setCompletingRound(Boolean completingRound) {
        this.completingRound = completingRound;
    }
    /**
     * Sets the first player.
     * @param firstPlayer the new first player
     */
    public void setFirstPlayer(Player firstPlayer) {
        this.firstPlayer = firstPlayer;
    }
    /**
     * Sets the list of faced up cards.
     * @param facedUpCards the new list of faced up cards
     */
    public void setFacedUpCards(ArrayList<PlayCard> facedUpCards) {
        this.facedUpCards = facedUpCards;
    }
    /**
     * Sets the resource deck.
     * @param resourceDeck the new resource deck
     */
    public void setResourceDeck(ResourceDeck resourceDeck) {
        this.resourceDeck = resourceDeck;
    }
    /**
     * Sets the gold deck.
     * @param goldDeck the new gold deck
     */
    public void setGoldDeck(GoldDeck goldDeck) {
        this.goldDeck = goldDeck;
    }
    /**
     * Sets the current player.
     * @param currentPlayer the new current player
     */
    public void setCurrentPlayer(Player currentPlayer) {
        this.currentPlayer = currentPlayer;
    }
    /**
     * Sets the number of players.
     * @param numPlayers the new number of players
     */
    public void setNumPlayers(Integer numPlayers) {
        this.numPlayers = numPlayers;
    }
    /**
     * Sets whether the game has started.
     * @param isStarted the new state
     */
    public void setIsStarted(Boolean isStarted){this.isStarted = isStarted;}
    /**
     * Returns whether it is the last turn.
     * @return true if it is the last turn, false otherwise
     */
    public boolean getIsLastTurn() {return isLastTurn;}
    /**
     * Draws a face up card.
     * @param faceupcardIndex the index of the face up card to draw
     * @throws NoCardException if there is no card in the specified position
     * @throws MoreThanThreeCardsException if the player already has three cards
     */
    public void drawFaceUpCard(Integer faceupcardIndex) throws NoCardException, MoreThanThreeCardsException {
        if (faceupcardIndex < 0 || faceupcardIndex > 3) {
            throw new IllegalArgumentException("Index out of range: " + faceupcardIndex);
        }
        PlayCard drawnCard = facedUpCards.get(faceupcardIndex);
        // check if there's a card in this position
        if (drawnCard == null) {
            throw new NoCardException("No card in this position");
        }

        PlayCard newCard = null;
        //try to draw from the right deck, if the right deck is empty draw from the other deck
        try{
            if(faceupcardIndex == 0 || faceupcardIndex == 1) {
                newCard = resourceDeck.getTopCard();
            } else {
                newCard = goldDeck.getTopCard();
            }
        } catch (DeckFinishedException e) {
            //try to draw from the other deck, if the other deck is empty, and we are in the last turn, don't draw
            try {
                if (faceupcardIndex == 0 || faceupcardIndex == 1) {
                    newCard = resourceDeck.getTopCard();
                } else {
                    newCard = goldDeck.getTopCard();
                }
            } catch (DeckFinishedException ex) {
                if (isLastTurn) {
                    System.out.println("Both decks are finished, card not replaced");
                }
                else {
                    throw new NoCardException("No card to replace the drawn card");
                }
            }
        }

        facedUpCards.set(faceupcardIndex, newCard);
        if(this.currentPlayer.getPlayCards().size()==3){
            throw new MoreThanThreeCardsException("Non puoi pescare se hai già tre carte nel tuo mazzo!");
        }
        this.currentPlayer.getPlayCards().add(drawnCard);


    }
    /**
     * Returns whether both decks are finished.
     * @return true if both decks are finished, false otherwise
     */
    public Boolean bothDecksFinished(){
        return this.goldDeck.getCards().isEmpty() && this.resourceDeck.getCards().isEmpty();
    }
    /**
     * Returns the list of winners.
     * @return the list of winners
     */
    public List<Player> getWinner() {
        int max = 0, score, maxCommonGoals = 0;
        List<Player> winners = new ArrayList<>();

        for (Player player : players) {
            //aggiungo i punti dati dalla secret goal card
            score = player.getSecretGoalCard().finalGoalPoints(player);
            player.updateScore(score);

            //aggiungo i punti dati dalle due common goal cards
            int commonGoalScore = this.commonGoals.get(0).finalGoalPoints(player) + this.commonGoals.get(1).finalGoalPoints(player);
            player.updateScore(commonGoalScore);

            this.scoreTrack.put(player.getNickname(), player.getScore());

            if (player.getScore() > max) {
                max = player.getScore();
                maxCommonGoals = commonGoalScore;
                winners.clear();
                winners.add(player);
            } else if (player.getScore() == max) {
                if (commonGoalScore > maxCommonGoals) {
                    maxCommonGoals = commonGoalScore;
                    winners.clear();
                    winners.add(player);
                } else if (commonGoalScore == maxCommonGoals) {
                    winners.add(player);
                }
            }
        }

        return winners;
    }

    /**
     * Initializes the game board. It creates the decks of cards and shuffles them.
     */
    public GameBoard() {
        //initialize the game board
        this.isStarted = false;
        this.isLastTurn = false;
        this.numPlayers = 5;
        this.scoreTrack = new HashMap<>();
        this.facedUpCards = new ArrayList<>();
        this.commonGoals = new ArrayList<>();
        this.currentPlayer = null;
        this.firstPlayer = null;
        this.completingRound = false;
        this.players = new ArrayList<>();

        //creating Resource Deck cards
        this.resourceDeck = new ResourceDeck();

        addResourceCard(1,Symbol.RED, Symbol.RED, Symbol.RED, Symbol.EMPTY, null, 0);
        addResourceCard(2, Symbol.RED, Symbol.RED, null, Symbol.RED, Symbol.EMPTY, 0);
        addResourceCard(3, Symbol.RED, Symbol.EMPTY, Symbol.RED, null, Symbol.RED, 0);
        addResourceCard(4, Symbol.RED, null, Symbol.EMPTY, Symbol.RED, Symbol.RED, 0);
        addResourceCard(5, Symbol.RED, null, Symbol.GREEN, Symbol.FEATHER, Symbol.RED, 0);
        addResourceCard(6, Symbol.RED, Symbol.POTION, null, Symbol.RED, Symbol.BLUE, 0);
        addResourceCard(7, Symbol.RED, Symbol.RED, Symbol.PARCHMENT, Symbol.PURPLE, Symbol.EMPTY, 0);
        addResourceCard(8, Symbol.RED, Symbol.EMPTY, Symbol.EMPTY, Symbol.RED, null, 1);
        addResourceCard(9, Symbol.RED, Symbol.RED, Symbol.EMPTY, null, Symbol.EMPTY, 1);
        addResourceCard(10,Symbol.RED, null, Symbol.RED, Symbol.EMPTY, Symbol.EMPTY, 1);

        addResourceCard(11, Symbol.GREEN, Symbol.GREEN, Symbol.GREEN, Symbol.EMPTY, null, 0);
        addResourceCard(12, Symbol.GREEN, Symbol.GREEN, null, Symbol.GREEN, Symbol.EMPTY, 0);
        addResourceCard(13, Symbol.GREEN, Symbol.EMPTY, Symbol.GREEN, null, Symbol.GREEN, 0);
        addResourceCard(14, Symbol.GREEN, null, Symbol.EMPTY, Symbol.GREEN, Symbol.GREEN, 0);
        addResourceCard(15, Symbol.GREEN, null, Symbol.FEATHER, Symbol.PURPLE, Symbol.GREEN, 0);
        addResourceCard(16, Symbol.GREEN, Symbol.RED, null, Symbol.GREEN, Symbol.POTION, 0);
        addResourceCard(17, Symbol.GREEN, Symbol.PARCHMENT, Symbol.GREEN, null, Symbol.BLUE, 0);
        addResourceCard(18, Symbol.GREEN, Symbol.EMPTY, Symbol.GREEN, Symbol.EMPTY, null, 1);
        addResourceCard(19, Symbol.GREEN, Symbol.EMPTY, null, Symbol.EMPTY, Symbol.GREEN, 1);
        addResourceCard(20, Symbol.GREEN, null, Symbol.EMPTY, Symbol.GREEN, Symbol.EMPTY, 1);

        addResourceCard(21, Symbol.BLUE, Symbol.BLUE, Symbol.EMPTY, Symbol.BLUE, null, 0);
        addResourceCard(22, Symbol.BLUE, null, Symbol.BLUE, Symbol.EMPTY, Symbol.BLUE, 0);
        addResourceCard(23, Symbol.BLUE, Symbol.BLUE, Symbol.BLUE, null, Symbol.EMPTY, 0);
        addResourceCard(24, Symbol.BLUE, Symbol.EMPTY, null, Symbol.BLUE, Symbol.BLUE, 0);
        addResourceCard(25, Symbol.BLUE, null, Symbol.POTION, Symbol.PURPLE, Symbol.BLUE, 0);
        addResourceCard(26, Symbol.BLUE, Symbol.GREEN, null, Symbol.BLUE, Symbol.PARCHMENT, 0);
        addResourceCard(27, Symbol.BLUE, Symbol.FEATHER, Symbol.BLUE, null, Symbol.RED, 0);
        addResourceCard(28, Symbol.BLUE, null, Symbol.BLUE, Symbol.EMPTY, Symbol.EMPTY, 1);
        addResourceCard(29, Symbol.BLUE, Symbol.EMPTY, Symbol.EMPTY, null, Symbol.BLUE, 1);
        addResourceCard(30, Symbol.BLUE, Symbol.EMPTY, Symbol.EMPTY, Symbol.BLUE, null, 1);

        addResourceCard(31, Symbol.PURPLE, Symbol.PURPLE, Symbol.EMPTY, Symbol.PURPLE, null, 0);
        addResourceCard(32, Symbol.PURPLE, null, Symbol.PURPLE, Symbol.EMPTY, Symbol.PURPLE, 0);
        addResourceCard(33, Symbol.PURPLE, Symbol.PURPLE, Symbol.PURPLE, null, Symbol.EMPTY, 0);
        addResourceCard(34, Symbol.PURPLE, Symbol.EMPTY, null, Symbol.PURPLE, Symbol.PURPLE, 0);
        addResourceCard(35, Symbol.PURPLE, null, Symbol.BLUE, Symbol.FEATHER, Symbol.PURPLE, 0);
        addResourceCard(36, Symbol.PURPLE, Symbol.PARCHMENT, null, Symbol.PURPLE, Symbol.RED, 0);
        addResourceCard(37, Symbol.PURPLE, Symbol.PURPLE, Symbol.POTION, Symbol.GREEN, null, 0);
        addResourceCard(38, Symbol.PURPLE, Symbol.PURPLE, Symbol.EMPTY, null, Symbol.EMPTY, 1);
        addResourceCard(39, Symbol.PURPLE, Symbol.EMPTY, null, Symbol.EMPTY, Symbol.PURPLE, 1);
        addResourceCard(40, Symbol.PURPLE, null, Symbol.EMPTY, Symbol.PURPLE, Symbol.EMPTY, 1);

        //creating Gold Deck cards
        this.goldDeck = new GoldDeck();

        addGoldCard(41, Symbol.RED, null, Symbol.EMPTY, Symbol.EMPTY, Symbol.FEATHER, 1, Arrays.asList(Symbol.RED, Symbol.RED, Symbol.BLUE), Symbol.FEATHER);
        addGoldCard(42, Symbol.RED, Symbol.EMPTY,null, Symbol.POTION, Symbol.EMPTY, 1, Arrays.asList(Symbol.RED, Symbol.RED, Symbol.GREEN), Symbol.POTION);
        addGoldCard(43, Symbol.RED, Symbol.PARCHMENT, Symbol.EMPTY, Symbol.EMPTY, null, 1, Arrays.asList(Symbol.RED, Symbol.RED, Symbol.PURPLE), Symbol.PARCHMENT);
        addGoldCard(44, Symbol.RED, Symbol.EMPTY, null, Symbol.EMPTY, Symbol.EMPTY, 2, Arrays.asList(Symbol.RED, Symbol.RED, Symbol.RED, Symbol.BLUE), Symbol.CORNER);
        addGoldCard(45, Symbol.RED, Symbol.EMPTY, Symbol.EMPTY, Symbol.EMPTY, null, 2, Arrays.asList(Symbol.RED, Symbol.RED, Symbol.RED, Symbol.GREEN), Symbol.CORNER);
        addGoldCard(46, Symbol.RED, Symbol.EMPTY, Symbol.EMPTY, null, Symbol.EMPTY, 2, Arrays.asList(Symbol.RED, Symbol.RED, Symbol.RED, Symbol.PURPLE), Symbol.CORNER);
        addGoldCard(47, Symbol.RED, Symbol.EMPTY, Symbol.POTION, null, null, 3, Arrays.asList(Symbol.RED, Symbol.RED, Symbol.RED), null);
        addGoldCard(48, Symbol.RED, Symbol.FEATHER, null, Symbol.EMPTY, null, 3, Arrays.asList(Symbol.RED, Symbol.RED, Symbol.RED), null);
        addGoldCard(49, Symbol.RED, null, null, Symbol.PARCHMENT, Symbol.EMPTY, 3, Arrays.asList(Symbol.RED, Symbol.RED, Symbol.RED), null);
        addGoldCard(50, Symbol.RED, Symbol.EMPTY, Symbol.EMPTY, null, null, 5, Arrays.asList(Symbol.RED, Symbol.RED, Symbol.RED, Symbol.RED, Symbol.RED), null);

        addGoldCard(51, Symbol.GREEN, Symbol.FEATHER, Symbol.EMPTY, Symbol.EMPTY, null, 1, Arrays.asList(Symbol.GREEN, Symbol.GREEN, Symbol.PURPLE), Symbol.FEATHER);
        addGoldCard(52, Symbol.GREEN, Symbol.EMPTY, null, Symbol.PARCHMENT, Symbol.EMPTY, 1, Arrays.asList(Symbol.GREEN, Symbol.GREEN, Symbol.RED), Symbol.PARCHMENT);
        addGoldCard(53, Symbol.GREEN, Symbol.EMPTY, Symbol.POTION, null, Symbol.EMPTY, 1, Arrays.asList(Symbol.GREEN, Symbol.GREEN, Symbol.BLUE), Symbol.POTION);
        addGoldCard(54, Symbol.GREEN, null, Symbol.EMPTY, Symbol.EMPTY, Symbol.EMPTY, 2, Arrays.asList(Symbol.GREEN, Symbol.GREEN, Symbol.GREEN, Symbol.PURPLE), Symbol.CORNER);
        addGoldCard(55, Symbol.GREEN, Symbol.EMPTY, Symbol.EMPTY, Symbol.EMPTY, null, 2, Arrays.asList(Symbol.GREEN, Symbol.GREEN, Symbol. GREEN, Symbol.BLUE), Symbol.CORNER);
        addGoldCard(56, Symbol.GREEN, Symbol.EMPTY, Symbol.EMPTY, null, Symbol.EMPTY, 2, Arrays.asList(Symbol.GREEN, Symbol.GREEN, Symbol.GREEN, Symbol.RED), Symbol.CORNER);
        addGoldCard(57, Symbol.GREEN, Symbol.EMPTY, Symbol.FEATHER, null, null, 3, Arrays.asList(Symbol.GREEN, Symbol.GREEN, Symbol.GREEN), null);
        addGoldCard(58, Symbol.GREEN, Symbol.PARCHMENT, null, Symbol.EMPTY, null, 3, Arrays.asList(Symbol.GREEN, Symbol.GREEN, Symbol.GREEN), null);
        addGoldCard(59, Symbol.GREEN, null, null, Symbol.POTION, Symbol.EMPTY, 3, Arrays.asList(Symbol.GREEN, Symbol.GREEN, Symbol.GREEN), null);
        addGoldCard(60, Symbol.GREEN, Symbol.EMPTY, null, Symbol.EMPTY, null, 5, Arrays.asList(Symbol.GREEN, Symbol.GREEN, Symbol.GREEN, Symbol.GREEN, Symbol.GREEN), null);

        addGoldCard(61, Symbol.BLUE, Symbol.POTION, Symbol.EMPTY, Symbol.EMPTY, null, 1, Arrays.asList(Symbol.BLUE, Symbol.BLUE, Symbol.PURPLE), Symbol.POTION);
        addGoldCard(62, Symbol.BLUE, null, Symbol.EMPTY, Symbol.EMPTY, Symbol.PARCHMENT, 1, Arrays.asList(Symbol.BLUE, Symbol.BLUE, Symbol.GREEN), Symbol.PARCHMENT);
        addGoldCard(63, Symbol.BLUE, Symbol.EMPTY, Symbol.FEATHER, null, Symbol.EMPTY, 1, Arrays.asList(Symbol.BLUE, Symbol.BLUE, Symbol.RED), Symbol.FEATHER);
        addGoldCard(64, Symbol.BLUE, Symbol.EMPTY, null, Symbol.EMPTY, Symbol.EMPTY, 2, Arrays.asList(Symbol.BLUE, Symbol.BLUE, Symbol.BLUE, Symbol.PURPLE), Symbol.CORNER);
        addGoldCard(65, Symbol.BLUE, Symbol.EMPTY, Symbol.EMPTY, null, Symbol.EMPTY, 2, Arrays.asList(Symbol.BLUE, Symbol.BLUE, Symbol.BLUE, Symbol.RED), Symbol.CORNER);
        addGoldCard(66, Symbol.BLUE, null, Symbol.EMPTY, Symbol.EMPTY, Symbol.EMPTY, 2, Arrays.asList(Symbol.BLUE, Symbol.BLUE, Symbol.BLUE, Symbol.GREEN), Symbol.CORNER);
        addGoldCard(67, Symbol.BLUE, Symbol.EMPTY, Symbol.PARCHMENT, null, null, 3, Arrays.asList(Symbol.BLUE, Symbol.BLUE, Symbol.BLUE), null);
        addGoldCard(68, Symbol.BLUE, Symbol.EMPTY, null, Symbol.POTION, null, 3, Arrays.asList(Symbol.BLUE, Symbol.BLUE, Symbol.BLUE), null);
        addGoldCard(69, Symbol.BLUE, null, null, Symbol.EMPTY, Symbol.FEATHER, 3, Arrays.asList(Symbol.BLUE, Symbol.BLUE, Symbol.BLUE), null);
        addGoldCard(70, Symbol.BLUE, null, null, Symbol.EMPTY, Symbol.EMPTY, 5, Arrays.asList(Symbol.BLUE, Symbol.BLUE, Symbol.BLUE, Symbol.BLUE, Symbol.BLUE), null);

        addGoldCard(71, Symbol.PURPLE, Symbol.EMPTY, null, Symbol.FEATHER, Symbol.EMPTY, 1, Arrays.asList(Symbol.PURPLE, Symbol.PURPLE, Symbol.GREEN), Symbol.FEATHER);
        addGoldCard(72, Symbol.PURPLE, Symbol.EMPTY, Symbol.PARCHMENT, null, Symbol.EMPTY, 1, Arrays.asList(Symbol.PURPLE, Symbol.PURPLE, Symbol.BLUE), Symbol.PARCHMENT);
        addGoldCard(73, Symbol.PURPLE, null, Symbol.EMPTY, Symbol.EMPTY, Symbol.POTION, 1, Arrays.asList(Symbol.PURPLE, Symbol.PURPLE, Symbol.RED), Symbol.POTION);
        addGoldCard(74, Symbol.PURPLE, Symbol.EMPTY, null, Symbol.EMPTY, Symbol.EMPTY, 2, Arrays.asList(Symbol.PURPLE, Symbol.PURPLE, Symbol.PURPLE, Symbol.BLUE), Symbol.CORNER);
        addGoldCard(75, Symbol.PURPLE, Symbol.EMPTY, Symbol.EMPTY, Symbol.EMPTY, null, 2, Arrays.asList(Symbol.PURPLE, Symbol.PURPLE, Symbol.PURPLE, Symbol.GREEN), Symbol.CORNER);
        addGoldCard(76, Symbol.PURPLE, Symbol.EMPTY, Symbol.EMPTY, null, Symbol.EMPTY, 2, Arrays.asList(Symbol.PURPLE, Symbol.PURPLE, Symbol.PURPLE, Symbol.RED), Symbol.CORNER);
        addGoldCard(77, Symbol.PURPLE, Symbol.POTION, Symbol.EMPTY, null, null, 3, Arrays.asList(Symbol.PURPLE, Symbol.PURPLE, Symbol.PURPLE), null);
        addGoldCard(78, Symbol.PURPLE, Symbol.EMPTY, null, Symbol.PARCHMENT, null, 3, Arrays.asList(Symbol.PURPLE, Symbol.PURPLE, Symbol.PURPLE), null);
        addGoldCard(79, Symbol.PURPLE, null, Symbol.FEATHER, null, Symbol.EMPTY, 3, Arrays.asList(Symbol.PURPLE, Symbol.PURPLE, Symbol.PURPLE), null);
        addGoldCard(80, Symbol.PURPLE, Symbol.EMPTY, null, Symbol.EMPTY, null, 5, Arrays.asList(Symbol.PURPLE, Symbol.PURPLE, Symbol.PURPLE, Symbol.PURPLE, Symbol.PURPLE), null);

        //STARTER CARDS
        starterDeck = new StarterDeck();

        addStarterCard(81, Symbol.EMPTY, Symbol.PURPLE, Symbol.GREEN, Symbol.EMPTY, Symbol.RED, Symbol.PURPLE, Symbol.GREEN, Symbol.BLUE, List.of(Symbol.PURPLE));
        addStarterCard(82, Symbol.BLUE, Symbol.EMPTY, Symbol.EMPTY, Symbol.RED, Symbol.GREEN, Symbol.RED, Symbol.BLUE, Symbol.PURPLE, List.of(Symbol.RED));
        addStarterCard(83, Symbol.EMPTY, Symbol.EMPTY, Symbol.EMPTY, Symbol.EMPTY, Symbol.PURPLE, Symbol.RED, Symbol.BLUE, Symbol.GREEN, List.of(Symbol.GREEN, Symbol.RED));
        addStarterCard(84, Symbol.EMPTY, Symbol.EMPTY, Symbol.EMPTY, Symbol.EMPTY, Symbol.GREEN, Symbol.BLUE, Symbol.PURPLE, Symbol.RED, List.of(Symbol.BLUE, Symbol.PURPLE));
        addStarterCard(85, Symbol.EMPTY, null, Symbol.EMPTY, null, Symbol.PURPLE, Symbol.GREEN, Symbol.RED, Symbol.BLUE, List.of(Symbol.BLUE, Symbol.PURPLE,Symbol.GREEN));
        addStarterCard(86, Symbol.EMPTY, null, Symbol.EMPTY, null, Symbol.RED, Symbol.GREEN, Symbol.BLUE, Symbol.PURPLE, List.of(Symbol.GREEN, Symbol.BLUE, Symbol.RED));

        //GOALCARDS
        goalDeck = new GoalDeck();

        addArrangementGoalCard(87, 2, true, Symbol.RED);
        addArrangementGoalCard(88, 2, true, Symbol.GREEN);
        addArrangementGoalCard(89, 2, true, Symbol.BLUE);
        addArrangementGoalCard(90, 2, true, Symbol.PURPLE);
        addArrangementGoalCard(91, 3, false, Symbol.RED);
        addArrangementGoalCard(92, 3, false, Symbol.GREEN);
        addArrangementGoalCard(93, 3, false, Symbol.BLUE);
        addArrangementGoalCard(94, 3, false, Symbol.PURPLE);

        addSymbolsGoalCard(95, 2, new ArrayList<>(List.of(Symbol.RED, Symbol.RED, Symbol.RED)));
        addSymbolsGoalCard(96, 2, new ArrayList<>(List.of(Symbol.GREEN, Symbol.GREEN, Symbol.GREEN)));
        addSymbolsGoalCard(97, 2, new ArrayList<>(List.of(Symbol.BLUE, Symbol.BLUE, Symbol.BLUE)));
        addSymbolsGoalCard(98, 2, new ArrayList<>(List.of(Symbol.PURPLE, Symbol.PURPLE, Symbol.PURPLE)));
        addSymbolsGoalCard(99, 3, new ArrayList<>(List.of(Symbol.FEATHER, Symbol.POTION, Symbol.PARCHMENT)));
        addSymbolsGoalCard(100, 2, new ArrayList<>(List.of(Symbol.FEATHER, Symbol.FEATHER)));
        addSymbolsGoalCard(101, 2, new ArrayList<>(List.of(Symbol.POTION, Symbol.POTION)));
        addSymbolsGoalCard(102, 2, new ArrayList<>(List.of(Symbol.PARCHMENT, Symbol.PARCHMENT)));
    }

    public void isLastTurn(boolean b) {
        this.isLastTurn = b;
    }

}

