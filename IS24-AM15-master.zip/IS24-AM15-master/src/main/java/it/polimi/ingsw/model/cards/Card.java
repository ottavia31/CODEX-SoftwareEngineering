package it.polimi.ingsw.model.cards;

import it.polimi.ingsw.model.Symbol;

import java.util.Map;

/**
 * This abstract class represents a generic Card in the game.
 */
public abstract class Card {
    int id;
    /**
     * This method is used to get the corners of the card.
     * @return A map representing the corners of the card.
     */
    public abstract Map<String, Symbol> getCorners();
    /**
     * This method is used to flip the card.
     */
    public abstract void flip();
    /**
     * This method is used to get the color of the card.
     * @return The color of the card.
     */
    public abstract Symbol getColor();
    /**
     * This method is used to get the front symbols of the card.
     * @return A list of symbols representing the front symbols of the card.
     */
    public abstract boolean isBackSide();
    /**
     * This method is used to get the id of the card.
     * @return The id of the card.
     */
    public int getId() {
        return id;
    }


}
