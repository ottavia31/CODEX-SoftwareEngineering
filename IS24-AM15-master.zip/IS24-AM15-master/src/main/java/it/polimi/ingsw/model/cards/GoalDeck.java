package it.polimi.ingsw.model.cards;

import it.polimi.ingsw.model.exceptions.DeckFinishedException;

import java.util.ArrayList;
import java.util.List;
/**
 * This class represents a deck of GoalCards in the game.
 */
public class GoalDeck  {
        private ArrayList<GoalCard> cards = new ArrayList<GoalCard>();
        public GoalDeck() {
            super();
            this.cards = new ArrayList<>(); // Initialize the cards field
        }
        /**
         * Returns the top card of the deck (the last card in the list) and removes it from the deck.
         * If the deck is empty, it throws a DeckFinishedException.
         *
         * @return the top card of the deck
         * @throws DeckFinishedException if the deck is empty
         */
        public GoalCard getTopCard() throws DeckFinishedException {
            if (cards.isEmpty() || cards.getLast() == null) {
                throw new DeckFinishedException("Deck is empty");
            }
            else {
                GoalCard curr = cards.getLast();
                cards.removeLast();
                return curr;
            }
        }
        /**
         * Returns the color of the top card of the deck.
         *
         * @return the color of the top card of the deck
         */
    public GoalCard getGoalCardById(int id) {
        for (GoalCard card : cards) {
            if (card.getId() == id) {
                return card;
            }
        }
        return null;
    }

    /**
     * Returns the list of cards in the deck.
     * @return the list of cards in the deck
     */
    public List<GoalCard> getCards() {
        return cards;
    }
}
