package it.polimi.ingsw.controller;


/**
 * This enum represents the various states that the game can be in during its lifecycle.
 */
public enum State {
    /**
     * The first state of the game.
     * No players have been added yet.
     */
    STARTED,
    /**
     * The state when the first player has been added.
     * The game is ready to accept the number of players.
     */
    FIRST_PLAYER_ADDED,
    /**
     * The state when the number of players has been set.
     * The game is ready to accept the players.
     */
    NUM_SETTED,
    /**
     * The state when all players have been added.
     * The game is ready to accept the pawns.
     */
    PLAYER_ADDED,
    /**
     * The state when all players have setted their pawns.
     * The game is ready to accept the secret goals.
     */
    ALL_PAWNS_SETTED,
    /**
     * The state when all players have setted their secret goals.
     * The game is ready to accept the starter cards.
     */
    ALL_SECRET_GOALS_SETTED,
    /**
     * The state when all players have setted their starter cards.
     * The game is ready to be setted.
     */
    STARTER_CARD_PLAYED,
    /**
     * The state when the game has been setted.
     * The game is ready to start.
     */
    GAME_SETTED,
    /**
     * The state when one player has thrown a card.
     * The game is ready to accept the card to be drawn.
     */
    THROWN,
    /**
     * The state when the card has been drawn.
     * The game is ready to accept the card to be played by the next player.
     */
    DRAWN,
    /**
     * The state when one player has reached 20 points and
     * the last turn has been completed.
     * The game is ready to calculate the points.
     */
    LAST_TURN_COMPLETED,
    /**
     * The state when the points have been calculated.
     * The game is ready to end.
     */
    POINTS_CALCULATED,
    /**
     * Lo stato quando tutti i giocatori sono stati aggiunti.
     */
    ALL_PLAYERS_ADDED,
    /**
     * The state when the game is over.
     */
    END_GAME
}