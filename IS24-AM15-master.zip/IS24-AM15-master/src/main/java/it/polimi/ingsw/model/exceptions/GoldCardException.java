package it.polimi.ingsw.model.exceptions;
/**
 * This class represents a custom exception that is thrown when there is an issue related to a Gold Card in the game.
 */
public class GoldCardException extends Exception {
    /**
     * Constructs a new GoldCardException with the specified detail message.
     *
     * @param message the detail message. The detail message is saved for later retrieval by the Throwable.getMessage() method.
     */
    public GoldCardException(String message) {
        super(message);
    }
}