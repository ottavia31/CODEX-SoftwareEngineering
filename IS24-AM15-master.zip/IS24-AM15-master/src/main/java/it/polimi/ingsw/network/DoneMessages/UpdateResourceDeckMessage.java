package it.polimi.ingsw.network.DoneMessages;

import it.polimi.ingsw.controller.State;
import it.polimi.ingsw.model.Symbol;

/**
 * Represents a message indicating an update to the resource deck with a specific color.
 * Extends {@link DoneMessage}.
 */
public class UpdateResourceDeckMessage extends DoneMessage {

    private final Symbol color;

    /**
     * Constructs an UpdateResourceDeckMessage object.
     *
     * @param state the state associated with this message
     * @param color the color of the resource deck that has been updated
     */
    public UpdateResourceDeckMessage(State state, Symbol color) {
        super(ConfirmAction.RESOURCE_DECK_UPDATE, state);
        this.color = color;
    }

    /**
     * Retrieves the color of the resource deck that has been updated.
     *
     * @return the color of the updated resource deck
     */
    public Symbol getColor() {
        return color;
    }
}
