package it.polimi.ingsw.network.DoneMessages;

import it.polimi.ingsw.controller.State;
import it.polimi.ingsw.model.PawnColor;

/**
 * Represents a message indicating the update of the chosen pawn color by a player.
 * Extends {@link DoneMessage}, specifying the chosen pawn color, player nickname, and associated game state.
 */
public class UpdatePawnColorMessage extends DoneMessage {

    private PawnColor color;
    private String nickname;

    /**
     * Constructs a new UpdatePawnColorMessage with the specified game state, chosen pawn color, and player nickname.
     *
     * @param state the state associated with the update of the chosen pawn color.
     * @param color the chosen pawn color.
     * @param nickname the nickname of the player who chose the pawn color.
     */
    public UpdatePawnColorMessage(State state, PawnColor color, String nickname) {
        super(ConfirmAction.CHOOSEN_PAWN, state);
        this.color = color;
        this.nickname = nickname;
    }

    /**
     * Retrieves the chosen pawn color.
     *
     * @return the chosen pawn color.
     */
    public PawnColor getColor() {
        return color;
    }

    /**
     * Retrieves the nickname of the player who chose the pawn color.
     *
     * @return the nickname of the player.
     */
    public String getNickname() {
        return nickname;
    }
}
