package it.polimi.ingsw.model.exceptions;

/**
 * This class represents a custom exception that is thrown when an operation
 * is performed on a card that does not exist or is not available.
 */
public class NoCardException extends Exception {

    /**
     * Constructs a new NoCardException with the specified detail message.
     *
     * @param message the detail message. The detail message is saved for
     *                later retrieval by the Throwable.getMessage() method.
     */
    public NoCardException(String message) {
        super(message);
    }
}