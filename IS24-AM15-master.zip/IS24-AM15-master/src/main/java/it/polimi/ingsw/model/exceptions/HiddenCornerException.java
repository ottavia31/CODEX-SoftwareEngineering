package it.polimi.ingsw.model.exceptions;

/**
 * This class represents a custom exception that is thrown when a card is attempted to be placed on a hidden corner.
 */
public class HiddenCornerException extends Exception{

    /**
     * Constructs a new HiddenCornerException with the specified detail message.
     *
     * @param message the detail message. The detail message is saved for later retrieval by the Throwable.getMessage() method.
     */
    public HiddenCornerException(String message) {
        super(message);
    }
}