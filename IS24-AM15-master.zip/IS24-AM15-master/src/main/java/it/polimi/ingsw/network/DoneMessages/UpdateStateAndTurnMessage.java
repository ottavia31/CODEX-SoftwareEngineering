package it.polimi.ingsw.network.DoneMessages;

import it.polimi.ingsw.controller.State;
import it.polimi.ingsw.network.DoneMessages.ConfirmAction;

/**
 * Represents a message indicating the update of the game state and current turn player.
 * Extends {@link DoneMessage}.
 */
public class UpdateStateAndTurnMessage extends DoneMessage {

    private String player;

    /**
     * Constructs an UpdateStateAndTurnMessage object.
     *
     * @param state  the state associated with this message
     * @param player the player whose turn it is in the updated game state
     */
    public UpdateStateAndTurnMessage(State state, String player) {
        super(ConfirmAction.TURN_STATE_UPDATE, state);
        this.player = player;
    }

    /**
     * Retrieves the player whose turn it is in the updated game state.
     *
     * @return the player's nickname
     */
    public String getPlayer() {
        return this.player;
    }
}
