package it.polimi.ingsw.network.DoneMessages;

import it.polimi.ingsw.controller.State;
import it.polimi.ingsw.network.DoneMessages.ConfirmAction;

/**
 * Represents a message indicating a card has been removed from a player's personal deck.
 * Extends {@link DoneMessage}, specifying the card ID that was removed.
 */
public class UpdateCardRemoved extends DoneMessage {

    private int card;

    /**
     * Constructs a new UpdateCardRemoved message with the specified game state and card ID.
     *
     * @param state the updated game state after the card removal.
     * @param card the ID of the card removed from the personal deck.
     */
    public UpdateCardRemoved(State state, int card) {
        super(ConfirmAction.REMOVED_FROM_PERSONAL_DECK, state);
        this.card = card;
    }

    /**
     * Retrieves the ID of the card that was removed from the personal deck.
     *
     * @return the ID of the removed card.
     */
    public int getCard() {
        return this.card;
    }
}