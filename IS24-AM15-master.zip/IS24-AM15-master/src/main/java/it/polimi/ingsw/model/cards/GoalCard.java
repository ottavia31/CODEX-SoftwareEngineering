package it.polimi.ingsw.model.cards;
import it.polimi.ingsw.model.Player;

import java.io.Serializable;

/**
 * This class represents a Goal Card in the game.
 * Each Goal Card has an id and a point value.
 */
public class GoalCard implements Serializable {
    private static final long serialVersionUID = 1L;
    private final int points;
    private final int id;
    /**
     * Constructs a GoalCard with the specified id and points.
     * @param id the id of the GoalCard
     * @param points the points of the GoalCard
     */
    public GoalCard(int id, int points) {
        this.points = points;
        this.id = id;
    }
    /**
     * Returns the points of the GoalCard.
     * @return the points of the GoalCard
     */
    public int getPoints() {
        return points;
    }
    /**
     * Returns the id of the GoalCard.
     * @return the id of the GoalCard
     */
    public int finalGoalPoints(Player player){
        int finalPoints = 0;
        return finalPoints;
    }
    /**
     * Returns the id of the GoalCard.
     * @return the id of the GoalCard
     */
    public int getId() {
        return id;
    }

}
